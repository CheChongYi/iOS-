//
//  FlowerViewController.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/3.
//  Copyright © 2015年 a. All rights reserved.
//

#import "FlowerViewController.h"
#import "MBProgressHUD.h"
@interface FlowerViewController ()<UIWebViewDelegate,MBProgressHUDDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation FlowerViewController{
    MBProgressHUD *HUD;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self creatHUD];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    self.navigationItem.title=@"创维55寸";
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],UITextAttributeTextColor, nil]];
    UIBarButtonItem *leftItem=[[UIBarButtonItem alloc]initWithTitle:@"< " style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    leftItem.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=leftItem;
    NSURL *url=[NSURL URLWithString:@"http://gz.jiehun.com.cn/m/dajiadian/59201/product/78846.html"];
    NSURLRequest *request=[NSURLRequest requestWithURL:url];
    [self.webView loadRequest:request];
    UIScrollView *scrollView=(UIScrollView *)[[_webView subviews]objectAtIndex:0];
    scrollView.bounces=NO;
    scrollView.showsHorizontalScrollIndicator=NO;
    scrollView.showsVerticalScrollIndicator=NO;
}
-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)creatHUD
{
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    HUD.labelText = @"加载中...";
    //黑化背景
    HUD.dimBackground = NO;
    HUD.delegate = self;
}
-(void)webViewDidStartLoad:(UIWebView *)webView{
    [HUD show:YES];
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    [HUD hide:YES];
}
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
    [alertView show];
    [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)     {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
