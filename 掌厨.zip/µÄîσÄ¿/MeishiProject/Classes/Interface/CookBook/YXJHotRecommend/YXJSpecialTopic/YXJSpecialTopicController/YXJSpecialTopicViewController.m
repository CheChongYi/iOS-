//
//  YXJSpecialTopicViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/19.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJSpecialTopicViewController.h"
#import "Header.h"



@interface YXJSpecialTopicViewController ()<UIWebViewDelegate>
{
    UIActivityIndicatorView *m_activity;
}

@end

@implementation YXJSpecialTopicViewController
//
//- (void)viewDidLoad
//{
//    [super viewDidLoad];
//    
//    [self setNavigationItem];
//    
//    NSURL *url = [NSURL URLWithString:@"http://h5.izhangchu.com/index.php?g=web&m=topic_view_min&a=index&topic_id=111"];
//    UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, screenHeight)];
//    NSURLRequest *request = [NSURLRequest requestWithURL:url];
//    [webView loadRequest:request];
//    [self.view addSubview:webView];
//    webView.delegate = self;
//    [self createButton];
//
//}
//
//
//
//
//- (void)setNavigationItem
//{
//    self.title = @"一个烤箱 一百道美味";
//    //取消自带的返回按钮，添加自定义返回按钮
//    [self.navigationItem setHidesBackButton:YES];
//    //设置导航栏标题的字体大小和颜色
//    [self.navigationController.navigationBar setTitleTextAttributes:
//     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
//       NSForegroundColorAttributeName:[UIColor whiteColor]}];
//}
//
//
//- (void)createButton
//{
//    UIButton *returnBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//    returnBtn.frame = CGRectMake(0, 65, 50, 50);
//    returnBtn.alpha = 0.05;
//    [returnBtn setBackgroundImage:[UIImage imageNamed:@"return.png"] forState:UIControlStateNormal];
//    [returnBtn addTarget:self action:@selector(popView) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:returnBtn];
//}
//
//
//- (void)popView
//{
//    [self.navigationController popToRootViewControllerAnimated:YES];
//}
//
//
////视图将要出现时调用(//加载数据的时候显示菊花)
//- (void)viewWillAppear:(BOOL)animated
//{
//    m_activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
//    m_activity.center = CGPointMake(screenWidth/2, screenHeight/2);
//    m_activity.color = [UIColor blackColor];
//    [self.view addSubview:m_activity];
//    [m_activity startAnimating];
//}
//
//
//
//#pragma mark - webViewDelegate
//- (void)webViewDidFinishLoad:(UIWebView *)webView
//{
//    [m_activity stopAnimating];
//}



@end
