//
//  bendipaisheManager.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/14.
//  Copyright © 2015年 a. All rights reserved.
//

#import "bendipaisheManager.h"
#import "AFNetworking.h"
#import "bendiModel.h"
NSString *bendipaisheManagerRefreshNotify= @"bendipaisheManagerRefreshNotify";
static bendipaisheManager *manager=nil;
@implementation bendipaisheManager
+(instancetype)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager=[[[self class]alloc]init];
        }
    });
    return manager;
}
-(void)loadInternetData{
    [self loadbendipaishesData];
}
-(void)loadbendipaishesData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:bendiUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"list"];
        for (NSDictionary *dic in array) {
            bendiModel *model=[[bendiModel alloc]init];
            model.img_url=dic[@"img_url"];
            model.mall_price=dic[@"mall_price"];
             NSDictionary *dics=dic[@"store"];
            model.store_name=dics[@"store_name"];
            if (!_bendiModels) {
                _bendiModels=[NSMutableArray array];
            }
            [self.bendiModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:bendipaisheManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
@end
