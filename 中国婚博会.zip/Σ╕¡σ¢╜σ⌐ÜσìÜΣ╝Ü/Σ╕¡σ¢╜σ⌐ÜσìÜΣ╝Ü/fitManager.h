//
//  fitManager.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/2.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>
extern NSString *fitManagerRefreshNotify;
@interface fitManager : NSObject
@property(nonatomic,strong)NSMutableArray *fitADModels;
@property(nonatomic,strong)NSMutableArray *shangpinNameModels;
@property(nonatomic,strong)NSMutableArray *actModels;

+(instancetype)shareInstance;
- (void)loadInternetData;
@end
