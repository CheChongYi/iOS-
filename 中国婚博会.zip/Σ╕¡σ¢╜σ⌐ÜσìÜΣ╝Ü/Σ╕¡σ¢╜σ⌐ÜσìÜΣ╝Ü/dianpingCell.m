//
//  dianpingCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import "dianpingCell.h"
#import "DianPingModel.h"
#import "UIImageView+WebCache.h"
@implementation dianpingCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithDianPingModels:(NSArray *)DianPingModels{
    DianPingModel *model=DianPingModels[0];
    [_iconView sd_setImageWithURL:[NSURL URLWithString:model.avatar]];
    _usernameLabel.text=model.uname;
    _useaddressLabel.text=model.source;
    _concentLabel.text=model.content;
    [_imageView1 sd_setImageWithURL:[NSURL URLWithString:model.origin]];
}
@end
