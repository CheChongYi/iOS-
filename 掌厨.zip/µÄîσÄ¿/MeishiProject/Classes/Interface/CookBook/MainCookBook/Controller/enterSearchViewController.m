//
//  enterSearchViewController.m
//  MeishiProject
//
//  Created by Yang on 15/12/10.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "enterSearchViewController.h"
#import "YXJClickImage1Controller.h"
#import "enterSearchModel.h"
#import "AFNetworking.h"
#import "Header.h"
#import "enterSearchCell.h"
@import MediaPlayer;


@interface enterSearchViewController ()<UITableViewDataSource,UITableViewDelegate>


@property (nonatomic, strong) UITableView *m_enterSearchTableView;

@property (nonatomic, strong) NSMutableArray *m_enterSearchArray;

@property (nonatomic, copy) NSString *video;

@end


@implementation enterSearchViewController




- (void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = NO;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setNavigationItem];
    [self createTableView];
    [self createRequest];

}



- (void)setNavigationItem
{
    self.title = @"为你找到";
    //取消自带的返回按钮，添加自定义返回按钮
    [self.navigationItem setHidesBackButton:YES];
    UIBarButtonItem *returnBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"returnButton.png"] style:UIBarButtonItemStyleDone target:self action:@selector(popViewController)];
    returnBtn.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = returnBtn;
    //设置导航栏标题的字体大小和颜色
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
}


- (void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)createTableView
{
  
    self.m_enterSearchTableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStyleGrouped];
    self.m_enterSearchTableView.delegate = self;
    self.m_enterSearchTableView.dataSource = self;
    [self.view addSubview:self.m_enterSearchTableView];
}



- (NSMutableArray *)m_enterSearchArray
{
    if (_m_enterSearchArray == nil)
    {
        _m_enterSearchArray = [NSMutableArray array];
    }
    return _m_enterSearchArray;
}



- (void)createRequest
{
    NSString *str = @"http://api.izhangchu.com/";
    NSDictionary *dic = @{@"appVersion":@"4.0.2",
                          @"sysVersion":@"9.1",
                          @"devModel":@"iPhone",
                          @"methodName":@"SearchDishes",
                          @"page":@"1",
                          @"keyword":self.m_searchResult
                         };
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:str parameters:dic success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSDictionary *dic1 = responseObject[@"data"];
        NSArray *arr1 = dic1[@"data"];
        for (NSDictionary *dic2 in arr1) {
            enterSearchModel *model  = [[enterSearchModel alloc] init];
             model.m_title = dic2[@"title"];
             model.m_dishes_id = dic2[@"dishes_id"];
             model.m_description = dic2[@"description"];
             model.m_video = dic2[@"video"];
             model.m_video1 = dic2[@"video1"];
             model.m_image = dic2[@"image"];
             model.m_hard_level = dic2[@"hard_level"];
             model.m_cookie = dic2[@"cookie"];
             model.m_taste = dic2[@"taste"];
            [self.m_enterSearchArray addObject:model];
        }
        
        [self.m_enterSearchTableView reloadData];

    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}




#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    YXJClickImage1Controller *enterClickImage1VC = [[YXJClickImage1Controller alloc] init];
    enterSearchModel *model = self.m_enterSearchArray[indexPath.row];
    enterClickImage1VC.m_dishesId = model.m_dishes_id;
    enterClickImage1VC.m_video = model.m_video;
    enterClickImage1VC.m_video1 = model.m_video1;
    enterClickImage1VC.m_headImageString = model.m_image;
    enterClickImage1VC.m_title = model.m_title;
    enterClickImage1VC.m_content = model.m_description;
    enterClickImage1VC.m_cooking_time = model.m_cookie;
    enterClickImage1VC.m_hard_level = model.m_hard_level;
    enterClickImage1VC.m_taste = model.m_taste;
    [self.navigationController pushViewController:enterClickImage1VC animated:YES];
}




#pragma mark - UITableViewDelegate 返回行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 180;
}




- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.m_enterSearchArray.count;
}



#pragma mark - UITableViewDataSource
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    enterSearchCell *cell = [enterSearchCell cellWithTabelView:tableView];
    enterSearchModel *model1 = self.m_enterSearchArray[indexPath.row];
    cell.m_model = model1;
    
    self.video = model1.m_video;
    UIButton *playVideoBtn = (UIButton *)[cell viewWithTag:1115];
    [playVideoBtn addTarget:self action:@selector(playVideo) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
  
}



//播放视频
- (void)playVideo
{
    NSURL *url = [NSURL URLWithString:self.video];
    MPMoviePlayerViewController *playVC = [[MPMoviePlayerViewController alloc] initWithContentURL:url];
    [self presentViewController:playVC animated:YES completion:nil];
}


@end
