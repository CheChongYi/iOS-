//
//  YXJBakeCell.h
//  MeishiProject
//
//  Created by Yang on 15/11/16.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>


@class YXJBakeModel;
@class YXJBakeCell;

@protocol YXJBakeCellDelegate <NSObject>
//点击视频协议的方法
- (void)yxjBakeCellDidClickVideo:(YXJBakeCell *)cell;

@end


@interface YXJBakeCell : UITableViewCell


@property (nonatomic, strong) YXJBakeModel *m_bakeModel;

+ (instancetype)cellWithTableView:(UITableView *)tableView;


@property (nonatomic, weak) id<YXJBakeCellDelegate>delegate;



@end
