//
//  couponCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import "couponCell.h"
#import "couponModel.h"
#import "UIImageView+WebCache.h"
@implementation couponCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithcouponModels:(NSArray *)couponModels{
    for (int i=0; i<2;i++) {
        UIImageView *iconView=(UIImageView *)[self viewWithTag:10+i];
        UIImageView *imgView=(UIImageView *)[self viewWithTag:11+i];
        couponModel *model=couponModels[i];
        [iconView sd_setImageWithURL:[NSURL URLWithString:model.imgurl]];
        [imgView sd_setImageWithURL:[NSURL URLWithString:model.imgurl]];
    }
}
@end
