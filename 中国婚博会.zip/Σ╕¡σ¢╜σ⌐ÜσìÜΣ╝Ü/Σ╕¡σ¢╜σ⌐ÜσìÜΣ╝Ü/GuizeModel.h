//
//  GuizeModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/11.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GuizeModel : NSObject
@property(nonatomic,strong)NSString *idesc;
@property(nonatomic,strong)NSString *imgurl;
@end
