//
//  actCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/2.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface actCell : UITableViewCell
-(void)configCellWithactModels:(NSArray *)actModels cellForRowAtIndexPath:(NSIndexPath *)indexPath;
@end
