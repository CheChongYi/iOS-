//
//  CityController.h
//  中国婚博会
//
//  Created by Admin on 15/11/6.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ChangeValue <NSObject>
@required
-(void)changeValue:(NSString *)text;
@end
@interface CityController : UIViewController
@property(nonatomic,retain)id<ChangeValue>delegate;
@end
