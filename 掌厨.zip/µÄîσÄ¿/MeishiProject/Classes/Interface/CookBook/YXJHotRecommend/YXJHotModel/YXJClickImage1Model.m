//
//  YXJClickImage1Model.m
//  MeishiProject
//
//  Created by Yang on 15/11/26.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJClickImage1Model.h"

@implementation YXJClickImage1Model

@end
