//
//  DsjLineLayout.h
//  UICollectionViewDemo
//
//  Created by DSJ on 15/11/7.
//  Copyright © 2015年 aoyolo.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DsjLineLayout : UICollectionViewFlowLayout

@end
