//
//  HaiMaModel.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/4.
//  Copyright © 2015年 a. All rights reserved.
//

#import "HaiMaModel.h"

@implementation HaiMaModel

@end
