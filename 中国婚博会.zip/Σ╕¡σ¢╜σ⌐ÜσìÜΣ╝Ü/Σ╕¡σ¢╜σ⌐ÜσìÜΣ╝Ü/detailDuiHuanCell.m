//
//  detailDuiHuanCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/12.
//  Copyright © 2015年 a. All rights reserved.
//

#import "detailDuiHuanCell.h"
#import "detailModel.h"
@implementation detailDuiHuanCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithdetailModels:(NSArray *)detailModels{
    detailModel *model=detailModels[0];
    _jifenLabel.text=[NSString stringWithFormat:@"我的积分：%@",model.exchanged_num];
    _marry_numLabel.text=[NSString stringWithFormat:@"我的婚戒：%@",model.discount];
    _needjifenLabel.text=[NSString stringWithFormat:@"所需普通积分：%@",model.exchange_score];
    _needmarryLabel.text=[NSString stringWithFormat:@"所需婚戒：%@",model.exchange_creative];
}
@end
