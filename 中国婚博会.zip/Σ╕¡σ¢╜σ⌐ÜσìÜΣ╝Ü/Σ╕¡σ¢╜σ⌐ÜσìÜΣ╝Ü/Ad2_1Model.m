//
//  Ad2Model.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/29.
//  Copyright © 2015年 a. All rights reserved.
//

#import "Ad2_1Model.h"

@implementation Ad2_1Model

@end
