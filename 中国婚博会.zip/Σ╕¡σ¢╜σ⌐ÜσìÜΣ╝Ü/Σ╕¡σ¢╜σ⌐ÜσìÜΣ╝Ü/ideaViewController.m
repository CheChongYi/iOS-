//
//  ideaViewController.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/16.
//  Copyright © 2015年 a. All rights reserved.
//

#import "ideaViewController.h"

@interface ideaViewController ()

@end

@implementation ideaViewController{
    UIButton *_btn1;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    self.navigationItem.title=@"意见反馈";
    UIBarButtonItem *leftBtn=[[UIBarButtonItem alloc]initWithTitle:@"<" style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    leftBtn.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=leftBtn;
    UIBarButtonItem *rightBtn=[[UIBarButtonItem alloc]initWithTitle:@"发送" style:UIBarButtonItemStyleDone target:self action:@selector(send)];
    rightBtn.tintColor=[UIColor whiteColor];
    self.navigationItem.rightBarButtonItem=rightBtn;
}
-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)send{
    UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"发送完成！谢谢您的意见，我们会尽力做得最好！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    [alertView show];
    sleep(1);
    [self.navigationController popViewControllerAnimated:YES];
}
@end
