//
//  FoodClassModel.h
//  MeishiProject
//
//  Created by Yang on 15/11/9.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface FoodClassModel : NSObject


@property (nonatomic, copy) NSString *image;

@property (nonatomic,copy) NSString *series_name;

@property (nonatomic,copy) NSString *play;

@property (nonatomic,copy) NSString *tag;

@property (nonatomic,strong) NSNumber *episode_sum;

@property (nonatomic, copy) NSNumber *episode;

@property (nonatomic, copy) NSString *banner_picture;

@property (nonatomic, copy) NSString *m_series_id;




@end
