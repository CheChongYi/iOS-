//
//  actModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/2.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface actModel : NSObject
@property(nonatomic,strong)NSString *img_url;
@end
