//
//  HotCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/7.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "HotCell.h"
#import "UIImageView+WebCache.h"
#import "CookBookModel.h"



@interface HotCell ()

@property (weak, nonatomic) IBOutlet UIImageView *HotImage;
@property (weak, nonatomic) IBOutlet UIButton *m_btnPlay;
@property (weak, nonatomic) IBOutlet UILabel *hotTitle;
@property (weak, nonatomic) IBOutlet UILabel *hotDescription;
@property (weak, nonatomic) IBOutlet UILabel *playCount;

- (IBAction)clickTap:(UITapGestureRecognizer *)tap;

@end

@implementation HotCell



+ (instancetype)cellWithTabelView: (UITableView *)tabelView
{
    static NSString *ID = @"ce";
    HotCell *cell = [tabelView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle]loadNibNamed:@"HotCell" owner:self options:nil]firstObject];
    }
    return cell;
}


- (void)setHotModel:(CookBookModel *)hotModel
{
    _hotModel = hotModel;
    self.hotTitle.text = hotModel.hotTitle;
    self.hotDescription.text = hotModel.hotDescription;
    self.playCount.text = [NSString stringWithFormat:@"%@个人做过",_hotModel.hotPlay];
    [self.HotImage sd_setImageWithURL:[NSURL URLWithString:hotModel.hotImage]];
}

//点击视频
- (IBAction)btnPlayClick:(UIButton *)btn
{

    if ([self.delegate respondsToSelector:@selector(hotCellDidClickPlay:)])
    {
        //self表示hotModel的所有模型数据
        [self.delegate hotCellDidClickPlay:self];
    }
}


//点击图片
- (IBAction)clickTap:(UITapGestureRecognizer *)tap
{
    if ([self.delegate respondsToSelector:@selector(hotCellDidClickImage:)])
    {
      [self.delegate hotCellDidClickImage:self];
    }
}


@end
