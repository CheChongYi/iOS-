//
//  NewModel.h
//  MeishiProject
//
//  Created by Yang on 15/11/8.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewModel : NSObject


@property (nonatomic, copy) NSString *newsTitle;

@property (nonatomic, copy) NSString *newsDescription;

@property (nonatomic, copy) NSString *newsImage;

@property (nonatomic, copy) NSString *newsPlay;

@property (nonatomic, copy) NSString *newsVideo;

@property (nonatomic, copy) NSString *newsVideo1;

@property (nonatomic, copy) NSString *newsDishes_id;

@property (nonatomic, copy) NSString *newsContent;




@end
