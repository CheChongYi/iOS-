//
//  FoodClassCell.h
//  MeishiProject
//
//  Created by Yang on 15/11/9.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>


@class FoodClassModel;

@interface FoodClassCell : UITableViewCell

@property (nonatomic, assign) NSInteger idx;

@property (nonatomic, strong) FoodClassModel *foodClassModel;

+ (instancetype)cellWithTabelView: (UITableView *)tabelView;

@end
