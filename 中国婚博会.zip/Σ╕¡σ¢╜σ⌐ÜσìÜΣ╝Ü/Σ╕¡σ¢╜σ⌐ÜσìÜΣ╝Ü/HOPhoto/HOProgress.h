//
//  HOProgress.h
//  HOPhotoView
//
//  Created by Chris on 15/8/6.
//  Copyright (c) 2015年 www.aoyolo.com 艾悠乐iOS学院. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HOProgress : UIView

- (void)setProgress:(float)progress;

@end
