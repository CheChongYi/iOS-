//
//  buyCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/7.
//  Copyright © 2015年 a. All rights reserved.
//

#import "buyCell.h"
#import "buyModel.h"
#import "UIImageView+WebCache.h"

@implementation buyCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithbuyModels:(NSArray *)buyModels{
    for (int i=0; i<2; i++) {
        UILabel *titleLabel=(UILabel *)[self viewWithTag:10+i];
        UILabel *titleLabel2=(UILabel *)[self viewWithTag:20+i];
        UIImageView *imageView=(UIImageView *)[self viewWithTag:30+i];
        
        buyModel *model=buyModels[i];
        titleLabel.text=model.title;
        titleLabel2.text=model.title2;
        [imageView sd_setImageWithURL:[NSURL URLWithString:model.imgUrl]];
    }
}
@end
