//
//  Ad2Model.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/29.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Ad2_1Model : NSObject
@property(nonatomic,strong)NSString *imgurl;
@end
