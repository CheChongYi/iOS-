//
//  findManager.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>
extern NSString *findManagerRefreshNotify;
@interface findManager : NSObject
@property(nonatomic,strong)NSMutableArray *celebrationModels;
@property(nonatomic,strong)NSMutableArray *quanModels;
@property(nonatomic,strong)NSMutableArray *hunlixingshiModels;
@property(nonatomic,strong)NSMutableArray *hunlizhusediaoModels;
@property(nonatomic,strong)NSMutableArray *gongsiModels;
@property(nonatomic,strong)NSMutableArray *guidsModels;

+(instancetype)shareInstance;
- (void)loadInternetData;
@end
