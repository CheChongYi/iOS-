//
//  AdoneModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/7.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AdoneModel : NSObject
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *link;
@end
