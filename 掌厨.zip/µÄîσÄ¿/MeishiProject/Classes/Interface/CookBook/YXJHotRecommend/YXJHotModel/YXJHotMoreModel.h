//
//  YXJHotMoreModel.h
//  MeishiProject
//
//  Created by Yang on 15/11/19.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface YXJHotMoreModel : NSObject
/**
 *   热门更多里面的热门
 */
@property (nonatomic, copy) NSString *m_hotMoreHotImage;

@property (nonatomic, copy) NSString *m_hotMoreHotTitle;

@property (nonatomic, copy) NSString *m_hotMoreHotDescription;

@property (nonatomic, copy) NSString *m_hotMoreHotVideo;

@property (nonatomic, copy) NSString *m_hotMoreHotVideo1;

@property (nonatomic, copy) NSString *m_hotMoreHotContent;

@property (nonatomic, copy) NSString * m_id;

/**
 *  热门更多里面的新品
 */
@property (nonatomic, copy) NSString *m_hotMoreNewDescription;

@property (nonatomic, copy) NSString *m_hotMoreNewTitle;

@property (nonatomic, copy) NSString *m_hotMoreNewImage;

@property (nonatomic, copy) NSString *m_hotMoreNewVideo;

@property (nonatomic, copy) NSString *m_hotMoreNewContent;

@property (nonatomic, copy) NSString *m_hotMoreNewId;



@end
