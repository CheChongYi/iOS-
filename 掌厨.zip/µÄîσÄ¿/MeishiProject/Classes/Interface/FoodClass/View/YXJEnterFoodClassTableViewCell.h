//
//  YXJEnterFoodClassTableViewCell.h
//  MeishiProject
//
//  Created by Yang on 15/12/5.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>

@class enterFoodClassModel;

@interface YXJEnterFoodClassTableViewCell : UITableViewCell


+ (instancetype)enterFoodClassTableViewCell:(UITableView *)UITableView;

@property (nonatomic, strong) enterFoodClassModel *m_model;


@end
