//
//  getTicketViewController.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/19.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface getTicketViewController : UIViewController
- (void)configCellWithgetTicketWEBModels:(NSArray *)getTicketWEBModels;
@end
