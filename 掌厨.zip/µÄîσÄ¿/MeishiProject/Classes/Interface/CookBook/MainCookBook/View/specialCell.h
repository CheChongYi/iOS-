//
//  specialCell.h
//  MeishiProject
//
//  Created by Yang on 15/11/12.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>


@class specialCell;

@protocol specialCellDelegate <NSObject>

- (void)specialCell:(specialCell *)cell didClickIndex:(NSInteger)index;

@end

@interface specialCell : UITableViewCell


@property (nonatomic, weak) id<specialCellDelegate>delegate;

@property (nonatomic, strong) NSMutableArray *specialCellArray;

+ (instancetype)cellWithTabelView: (UITableView *)tabelView;




@end
