//
//  MTNetManager.h
//  中国婚博会
//
//  Created by Admin on 15/11/5.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>
extern NSString *MTNetManagerRefreshNotify;
@interface HomeNetManager : NSObject<UIAlertViewDelegate>
@property(nonatomic,strong)NSMutableArray *AdModels;
@property(nonatomic,strong)NSMutableArray *buttonModels;
@property(nonatomic,strong)NSMutableArray *AdoneModels;
@property(nonatomic,strong)NSMutableArray *timeModels;
@property(nonatomic,strong)NSMutableArray *weekModels;
@property(nonatomic,strong)NSMutableArray *buyModels;
@property(nonatomic,strong)NSMutableArray *ActivityModels;
@property(nonatomic,strong)NSMutableArray *loveModels;
@property(nonatomic,strong)NSMutableArray *searchModels;
@property(nonatomic,strong)NSMutableArray *Ad2Models;
@property(nonatomic,strong)NSMutableArray *baliModels;

+(instancetype)shareInstance;
- (void)loadInternetData;
@end
