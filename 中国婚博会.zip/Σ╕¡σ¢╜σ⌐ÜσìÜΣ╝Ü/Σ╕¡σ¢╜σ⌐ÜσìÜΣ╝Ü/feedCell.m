//
//  feedCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/5.
//  Copyright © 2015年 a. All rights reserved.
//

#import "feedCell.h"

@implementation feedCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
