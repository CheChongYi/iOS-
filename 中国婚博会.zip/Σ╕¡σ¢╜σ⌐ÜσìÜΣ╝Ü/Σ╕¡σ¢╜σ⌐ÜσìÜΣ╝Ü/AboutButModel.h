//
//  AboutButModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/10.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AboutButModel : NSObject
@property(nonatomic,strong)NSString *imgurl;
@property(nonatomic,strong)NSString *banben;
@property(nonatomic,strong)NSString *title;
@end
