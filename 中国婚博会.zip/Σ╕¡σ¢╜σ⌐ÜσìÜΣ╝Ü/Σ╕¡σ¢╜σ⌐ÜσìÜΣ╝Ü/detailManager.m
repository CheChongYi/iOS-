//
//  detailManager.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/12.
//  Copyright © 2015年 a. All rights reserved.
//

#import "detailManager.h"
#import "AFNetworking.h"
#import "detailModel.h"
NSString *detailManagerRefreshNotify= @"detailManagerRefreshNotify";
static detailManager *manager=nil;
@implementation detailManager
+(instancetype)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager=[[[self class]alloc]init];
        }
    });
    return manager;
}
-(void)loadInternetData{
    [self loadDetailData];
}
-(void)loadDetailData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:detailUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSDictionary *dics=dic[@"gift"];
        detailModel *model=[[detailModel alloc]init];
        model.img_url=dics[@"img_url"];
        model.gift_name=dics[@"gift_name"];
        model.total_num=dics[@"total_num"];
        model.left_num=dics[@"left_num"];
        model.exchange_creative=dics[@"exchange_creative"];
        model.exchange_score=dics[@"exchange_score"];
        model.exchanged_num=dics[@"exchanged_num"];
        model.discount=dics[@"discount"];
        model.end_time=dics[@"end_time"];
        
        NSArray *array=dics[@"content"];
        NSDictionary *contentDic=array[1];
        NSDictionary *middleDic=contentDic[@"middle"];
        model.url=middleDic[@"url"];
        
        NSDictionary *contentDic2=array[2];
        model.content=contentDic2[@"content"];
    
        NSDictionary *dt=dic[@"store"];
        model.store_name=dt[@"store_name"];
        model.logo=dt[@"logo"];
        if (!_detailModels) {
            _detailModels=[NSMutableArray array];
        }
        [self.detailModels addObject:model];
        [[NSNotificationCenter defaultCenter]postNotificationName:detailManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
        [alertView show];
        [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
    }];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)
    {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
