//
//  YXJClickImage1View.h
//  MeishiProject
//
//  Created by Yang on 15/11/26.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>




@interface YXJClickImage1View : UIView


@property (weak, nonatomic) IBOutlet UIImageView *m_headerImage;

@property (weak, nonatomic) IBOutlet UILabel *m_heaferTitle;

@property (weak, nonatomic) IBOutlet UILabel *m_headerContent;

@property (weak, nonatomic) IBOutlet UILabel *m_headerCookTime;

@property (weak, nonatomic) IBOutlet UILabel *m_headerHard;

@property (weak, nonatomic) IBOutlet UILabel *m_taste;


+ (instancetype)yxjClickImage1View;



@end
