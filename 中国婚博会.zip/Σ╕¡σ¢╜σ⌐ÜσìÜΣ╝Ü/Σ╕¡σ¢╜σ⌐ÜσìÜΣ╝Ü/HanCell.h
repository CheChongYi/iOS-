//
//  HanCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/14.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HanCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
-(void)configCellWithHanModels:(NSArray *)HanModels cellForRowAtIndexPath:(NSIndexPath *)indexPath;
@end
