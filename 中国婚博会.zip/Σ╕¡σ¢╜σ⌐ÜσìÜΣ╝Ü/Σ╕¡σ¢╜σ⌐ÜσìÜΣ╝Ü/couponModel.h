//
//  couponModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/30.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface couponModel : NSObject
@property(nonatomic,strong)NSString *imgurl;
@end
