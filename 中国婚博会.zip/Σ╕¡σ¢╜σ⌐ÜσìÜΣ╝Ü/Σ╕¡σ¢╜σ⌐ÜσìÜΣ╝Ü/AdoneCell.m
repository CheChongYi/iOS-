//
//  AdoneCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/7.
//  Copyright © 2015年 a. All rights reserved.
//

#import "AdoneCell.h"
#import "AdoneModel.h"
@implementation AdoneCell

- (void)awakeFromNib {
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithAdoneModels:(NSArray *)AdoneModels{
    for (int i=0; i<1; i++) {
        _label=(UILabel *)[self viewWithTag:10+i];
        AdoneModel *model=AdoneModels[i];
        _label.text=model.title;
        CGRect frame=_label.frame;
        frame.origin.x=20;
        _label.frame=frame;
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:8.8f];
        [UIView setAnimationCurve:UIViewAnimationCurveLinear];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationRepeatAutoreverses:NO];
        [UIView setAnimationRepeatCount:INFINITY];
        frame=_label.frame;
        frame.origin.x=80;
        _label.frame=frame;
        [UIView commitAnimations];
      }
}
@end

