//
//  freeManager.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import "freeManager.h"
#import "AFNetworking.h"

#import "freeModel.h"
NSString *freeManagerRefreshNotify= @"freeManagerRefreshNotify";
static freeManager *manager=nil;
@implementation freeManager
+(instancetype)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager=[[[self class]alloc]init];
        }
    });
    return manager;
}
-(void)loadInternetData{
    [self loadfreeData];
}
-(void)loadfreeData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:freeUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        freeModel *model=[[freeModel alloc]init];
        model.activity_title=dic[@"activity_title"];
        model.start_time=dic[@"start_time"];
        model.end_time=dic[@"end_time"];
        NSArray *array=dic[@"content"];
        NSDictionary *contentDic=array[0];
        model.content=contentDic[@"content"];
        
        NSDictionary *originDic=array[1];
        NSDictionary *Dic=originDic[@"origin"];
        model.url=Dic[@"url"];
        
        NSDictionary *contentDic2=array[2];
        model.content2=contentDic2[@"content"];
        NSLog(@"%@",model.content2);
        
        NSDictionary *originDic2=array[3];
        NSDictionary *Dics=originDic2[@"origin"];
        model.url2=Dics[@"url"];
        NSLog(@"%@",model.url2);
        
        NSDictionary *originDic3=array[4];
        NSDictionary *Dict=originDic3[@"origin"];
        model.url3=Dict[@"url"];
        NSLog(@"%@",model.url3);
        
        NSDictionary *contentDic3=array[5];
        model.content3=contentDic3[@"content"];
        NSLog(@"%@",model.content3);
        if (!_freeModels) {
            _freeModels=[NSMutableArray array];
        }
        [self.freeModels addObject:model];
        [[NSNotificationCenter defaultCenter]postNotificationName:freeManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
        [alertView show];
        [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
    }];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)     {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
