//
//  enterSearchCell.m
//  MeishiProject
//
//  Created by Yang on 15/12/10.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "enterSearchCell.h"
#import "UIImageView+WebCache.h"
#import "enterSearchModel.h"


@interface enterSearchCell ()

@property (weak, nonatomic) IBOutlet UIImageView *m_image;
@property (weak, nonatomic) IBOutlet UILabel *m_title;
@property (weak, nonatomic) IBOutlet UILabel *m_desc;
@property (weak, nonatomic) IBOutlet UILabel *m_label1;
@property (weak, nonatomic) IBOutlet UILabel *m_label2;
@property (weak, nonatomic) IBOutlet UILabel *m_label3;

@end

@implementation enterSearchCell


+ (instancetype)cellWithTabelView: (UITableView *)tabelView;
{
    static NSString *ID = @"ce";
    enterSearchCell *cell = [tabelView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"enterSearchCell" owner:nil options:nil]firstObject];
    }
    return cell;
}



- (void)setM_model:(enterSearchModel *)m_model
{
    _m_model = m_model;
    
    self.m_title.text = _m_model.m_title;
    self.m_desc.text = _m_model.m_description;
    self.m_label1.text = _m_model.m_hard_level;
    self.m_label2.text = _m_model.m_taste;
    self.m_label3.text = _m_model.m_cookie;
    [self.m_image sd_setImageWithURL:[NSURL URLWithString:_m_model.m_image]];
}

@end
