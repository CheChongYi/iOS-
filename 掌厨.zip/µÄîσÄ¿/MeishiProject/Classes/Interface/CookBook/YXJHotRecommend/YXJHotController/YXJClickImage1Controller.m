//
//  YXJClickImage1Controller.m
//  MeishiProject
//
//  Created by Yang on 15/11/26.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJClickImage1Controller.h"
#import "YXJClickImage1View.h"
#import "YXJClickImage1Model.h"
#import "YXJClickImage1Cell.h"
#import "UIImageView+WebCache.h"
#import "AFNetworking.h"
#import "Header.h"
@import  MediaPlayer;



@interface YXJClickImage1Controller ()<UITableViewDataSource, UITableViewDelegate>
{
    NSInteger count;
    NSInteger caiMingCount;
}
@property (nonatomic, assign) NSInteger m_i;
/**
 *  制作步骤video
 */
@property (nonatomic, strong) NSString *m_stepVideo;
@property (nonatomic, strong) UITableView *m_clickImage1TaleView;
@property (nonatomic, strong) NSMutableArray *m_clickImage1Array;
@property (nonatomic, strong) NSMutableArray *m_materialArray;
@property (nonatomic, strong) NSMutableArray *m_footArray;
@property (nonatomic, strong) NSMutableArray *m_commonSenseArray;
@property (nonatomic, strong) NSMutableArray *m_xiangKeArray;
/**
 *   自定义的一个view
 */
@property (nonatomic, strong) YXJClickImage1View *m_view;
/**
 *  cell头部的滑动条
 */
@property (nonatomic, strong) UIView *m_slideView;
/**
 *  m_cell就是YXJClickImage1Cell,只是设为全局变量
 */
@property (nonatomic, strong) YXJClickImage1Cell *m_cell;


@end


@implementation YXJClickImage1Controller

//视图将要出现时,隐藏导航栏
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = YES;
    //视图布满顶部屏幕(包括状态栏)
    self.automaticallyAdjustsScrollViewInsets = NO;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self createTableView];
    [self createReturnButton];
    [self createPracticeDataRequest];
    [self loadHeaderData];
    [self createMaterialDataRequest];
    [self createCommonSenseDataRequest];
    [self createXiangKeDataRequest];
}



//创建返回按钮
- (void)createReturnButton
{
    UIButton *returnBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    returnBtn.frame = CGRectMake(0, 20, 50, 50);
    [returnBtn setBackgroundImage:[UIImage imageNamed:@"return.png"] forState:UIControlStateNormal];
    [returnBtn addTarget:self action:@selector(popView) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:returnBtn];
}


- (void)popView
{
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)createTableView
{
    self.m_clickImage1TaleView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    self.m_clickImage1TaleView.dataSource = self;
    self.m_clickImage1TaleView.delegate = self;
    [self.view addSubview:self.m_clickImage1TaleView];
    
    
    YXJClickImage1View *view = [YXJClickImage1View yxjClickImage1View];
    UIButton *playVideoBtn = (UIButton *)[view viewWithTag:1111];
    UIButton *playVideoBtn2 = (UIButton *)[view viewWithTag:1112];
    UIButton *playVideoBtn3 = (UIButton *)[view viewWithTag:1113];
    [playVideoBtn addTarget:self action:@selector(yxjClickImage1ViewDidClickVideo) forControlEvents:UIControlEventTouchUpInside];
    [playVideoBtn2 addTarget:self action:@selector(yxjClickImage1ViewDidClickVideo) forControlEvents:UIControlEventTouchUpInside];
    [playVideoBtn3 addTarget:self action:@selector(yxjClickImage1ViewDidClickVideo3) forControlEvents:UIControlEventTouchUpInside];
    //设为全局变量
    self.m_view = view;
    self.m_clickImage1TaleView.tableHeaderView = self.m_view;
}



#pragma mark -进入热门图片1的(头部)数据加载
- (void)loadHeaderData
{
    NSURL *url = [NSURL URLWithString: self.m_headImageString];
    [self.m_view.m_headerImage sd_setImageWithURL: url];
    self.m_view.m_heaferTitle.text = self.m_title;
    self.m_view.m_headerContent.text = self.m_content;
    self.m_view.m_headerHard.text = self.m_hard_level;
    self.m_view.m_headerCookTime.text = self.m_cooking_time;
    self.m_view.m_taste.text = self.m_taste;
}



//播放视频(进入热门)
- (void)yxjClickImage1ViewDidClickVideo
{
    NSURL *url = [NSURL URLWithString:self.m_video];
    MPMoviePlayerViewController *play = [[MPMoviePlayerViewController alloc] initWithContentURL:url];
    [self presentViewController:play animated:YES completion:nil];
}



- (void)yxjClickImage1ViewDidClickVideo3
{
    NSURL *url2 = [NSURL URLWithString:self.m_video1];
    MPMoviePlayerViewController *play2 = [[MPMoviePlayerViewController alloc] initWithContentURL:url2];
    [self presentViewController:play2 animated:YES completion:nil];
}


- (NSMutableArray *)m_clickImage1Array
{
    if (_m_clickImage1Array == nil)
    {
        _m_clickImage1Array = [NSMutableArray array];
    }
    return _m_clickImage1Array;
}



- (NSMutableArray *)m_materialArray
{
    if (_m_materialArray == nil)
    {
        _m_materialArray = [NSMutableArray array];
    }
    return _m_materialArray;
}



- (NSMutableArray *)m_commonSenseArray
{
    if (_m_commonSenseArray == nil)
    {
        _m_commonSenseArray = [NSMutableArray array];
    }
    return _m_commonSenseArray;
}




- (NSMutableArray *)m_xiangKeArray
{
    if (_m_xiangKeArray == nil)
    {
        _m_xiangKeArray = [NSMutableArray array];
    }
    return _m_xiangKeArray;
}




- (NSMutableArray *)m_footArray
{
    if (_m_footArray == nil)
    {
        _m_footArray = [NSMutableArray array];
    }
    return _m_footArray;
}



//点击热门图片1进入之后的(做法)数据请求
- (void)createPracticeDataRequest
{
    NSString *temp = [NSString stringWithFormat:@"http://api.izhangchu.com/?appVersion=4.0.2&sysVersion=9.1&devModel=iPhone&dishes_id=%@&methodName=DishesView&user_id=0&token=0&version=4.02",self.m_dishesId];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:temp parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSDictionary *dic1 = responseObject[@"data"];
        
        self.m_view.m_headerHard.text = dic1[@"hard_level"];
        self.m_view.m_headerCookTime.text = dic1[@"cooke_time"];
        self.m_view.m_taste.text = dic1[@"taste"];
        
        NSArray *arr1 = dic1[@"step"];
        for (NSDictionary *dic2 in arr1) {
            YXJClickImage1Model *model = [[YXJClickImage1Model alloc] init];
            model.m_practiceNumber = dic2[@"dishes_step_order"];
            model.m_practiceDesc = dic2[@"dishes_step_desc"];
            model.m_practiceImage = dic2[@"dishes_step_image"];
            [self.m_clickImage1Array addObject:model];
        }
        [self.m_clickImage1TaleView reloadData];
        
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}



//点击热门图片1进入之后的(食材)数据请求
- (void)createMaterialDataRequest
{
    NSString *temp = [NSString stringWithFormat:@"http://api.izhangchu.com/?appVersion=4.0.2&sysVersion=9.1&devModel=iPhone&dishes_id=%@&methodName=DishesMaterial&user_id=0&token=0&version=4.02", self.m_dishesId];
     AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:temp parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSDictionary *dic = responseObject[@"data"];
        YXJClickImage1Model *materialmodel = [[YXJClickImage1Model alloc] init];
        materialmodel.m_material_image =dic[@"material_image"];
        NSArray *arr1 = dic[@"material"];
        count = arr1.count;
        for (NSDictionary *dic2 in arr1) {
             YXJClickImage1Model *materialmodel1 = [[YXJClickImage1Model alloc] init];
            materialmodel1.m_material_name = dic2[@"material_name"];
            materialmodel1.m_material_weight = dic2[@"material_weight"];
            caiMingCount ++;
            [self.m_materialArray addObject:materialmodel];
            [self.m_materialArray addObject:materialmodel1];
        }
        NSArray *arr2 = dic[@"spices"];
        for (NSDictionary *dic3 in arr2) {
            YXJClickImage1Model *materialmodel2 = [[YXJClickImage1Model alloc] init];
            materialmodel2.m_footImage = dic3[@"image"];
            materialmodel2.m_footTitle = dic3[@"title"];
            [self.m_footArray addObject:materialmodel2];
        }
        [self.m_clickImage1TaleView reloadData];
        
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
    
}



//点击热门图片1进入之后的(相关常识)数据请求
- (void)createCommonSenseDataRequest
{
    NSString *temp = [NSString stringWithFormat:@"http://api.izhangchu.com/?appVersion=4.0.2&sysVersion=9.1&devModel=iPhone&dishes_id=%@&methodName=DishesCommensense&user_id=0&token=0&version=4.02",self.m_dishesId];
     AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:temp parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSDictionary *dic = responseObject[@"data"];
        YXJClickImage1Model *model3 = [[YXJClickImage1Model alloc] init];
        model3.m_commonSenseTitle = dic[@"nutrition_analysis"];
        model3.m_commonSenseDisc = dic[@"production_direction"];
        model3.m_commonSenseImage = dic[@"image"];
        [self.m_commonSenseArray addObject:model3];
        [self.m_clickImage1TaleView reloadData];
       }
         failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
    
}



//点击热门图片1进入之后的(相宜相克)数据请求
- (void)createXiangKeDataRequest
{
    NSString *temp = [NSString stringWithFormat:@"http://api.izhangchu.com/?appVersion=4.0.2&sysVersion=9.1&devModel=iPhone&dishes_id=%@&methodName=DishesSuitable&user_id=0&token=0&version=4.02",self.m_dishesId];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:temp parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSDictionary *dic = responseObject[@"data"];
        NSDictionary *dic1 = dic[@"material"];
        YXJClickImage1Model *model = [[YXJClickImage1Model alloc] init];
        model.m_xiangkeHeaderImage = dic1[@"image"];
        model.m_xiangKeMainName = dic1[@"material_name"];
        [self.m_xiangKeArray addObject:model];
        NSArray *arr = dic1[@"suitable_with"];
        for (NSDictionary *dic2 in arr)
        {
            YXJClickImage1Model *model1 = [[YXJClickImage1Model alloc] init];
            model1.m_xiangKeImage1 = dic2[@"image"];
            model1.m_xiangKeName1 = dic2[@"material_name"];
            model1.m_xiangKeDesc1 = dic2[@"suitable_desc"];
            [self.m_xiangKeArray addObject:model1];
        }
        NSArray *arr1 = dic1[@"suitable_not_with"];
        for (NSDictionary *dic3 in arr1)
        {
            YXJClickImage1Model *model2 = [[YXJClickImage1Model alloc] init];
            model2.m_xiangKeImage1 = dic3[@"image"];
            model2.m_xiangKeName1 = dic3[@"material_name"];
            model2.m_xiangKeDesc1 = dic3[@"suitable_desc"];
            [self.m_xiangKeArray addObject:model2];
        }
          [self.m_clickImage1TaleView reloadData];
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}




#pragma mark - UITableViewDelegate
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *backgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 45)];
   
    NSArray *titleArray = @[@"做法",@"食材",@"相关常识",@"相宜相克"];
    CGFloat labelW = screenWidth / 4;
    [titleArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(idx * labelW, 0, labelW, 45)];
        label.text = obj;
        label.tag = idx;
        label.textAlignment = NSTextAlignmentCenter;
        label.userInteractionEnabled = YES;
        [backgroundView addSubview:label];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapSetContentOfSet:)];
        [label addGestureRecognizer:tap];
    }];
    //头部的滑动条
    if (self.m_slideView == nil) /////////////////////1
    {
    self.m_slideView = [[UIView alloc] initWithFrame:CGRectMake(0, 45-5, labelW, 5)];
    self.m_slideView.backgroundColor = [UIColor orangeColor];
    }
    [backgroundView addSubview:self.m_slideView];

    UIView *fenGeView1  = [[UIView alloc] initWithFrame:CGRectMake(0, 5, screenWidth, 5)];
    fenGeView1.alpha = 0.3;
    fenGeView1.backgroundColor = [UIColor grayColor];
    [backgroundView addSubview:fenGeView1];
    
    UIView *fenGeView2  = [[UIView alloc] initWithFrame:CGRectMake(0, 45, screenWidth, 10)];
    fenGeView2.alpha = 0.3;
    fenGeView2.backgroundColor = [UIColor grayColor];
    [backgroundView addSubview:fenGeView2];
    
    for (int i = 1; i<4; i++)
    {
     UIView *jianGeView = [[UIView alloc] initWithFrame:CGRectMake(i*screenWidth/4 , 15, 1, 20)];
     jianGeView.alpha = 0.4;
     jianGeView.backgroundColor = [UIColor grayColor];
     [backgroundView addSubview:jianGeView];
    }
    return backgroundView;
}


- (void)tapSetContentOfSet:(UITapGestureRecognizer *)tap
{
    NSInteger i = tap.view.tag;
    self.m_i = i;
    [self.m_clickImage1TaleView reloadData];/////////////////2
    //滑动条滑动的动画效果
    [UIView animateWithDuration:0.3 animations:^{
    //scroll偏移量
    [self.m_cell setScrollViewX:i*screenWidth];
    //滑动条滑动范围
    self.m_slideView.frame = CGRectMake(i * screenWidth/4, 45-5, screenWidth/4, 5);
    }];
  
}





- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.m_i == 1)
    {
        return 2000;
    }
    else if (self.m_i == 2)/////////////4
    {
        return 600;
    }
    else if (self.m_i == 3)
    {
        return 580;
    }
    return 2100;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 60;
}


#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    YXJClickImage1Cell *cell = [YXJClickImage1Cell yxjClickImage1Cell:tableView];
    // 把当前控制器创建的m_slideView传到自定义的cell中去(也就是m_slideView1属性变量)
    cell.m_slideView1 = self.m_slideView;
    //把cell设为全局变量
    self.m_cell = cell;
    if (_m_clickImage1Array != nil)
    {
        cell.m_practiceArray = self.m_clickImage1Array;
    }

    cell.m_1xiangKeArray = self.m_xiangKeArray;
    if (_m_materialArray) {
        cell.count = count;
        cell.m_caiMingCount = caiMingCount;
        cell.m_1materialArray = self.m_materialArray;
    }
    
    cell.m_1commonSenseArray = self.m_commonSenseArray;
    cell.m_footArr = self.m_footArray;
    [self.m_cell setScrollViewX:self.m_i*screenWidth]; //////////////////5
    
    return cell;
}



@end
