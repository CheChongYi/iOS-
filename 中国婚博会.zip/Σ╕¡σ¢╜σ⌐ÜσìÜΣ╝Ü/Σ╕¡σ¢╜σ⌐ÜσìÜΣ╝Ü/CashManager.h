//
//  CashManager.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>
extern NSString *CashManagerRefreshNotify;
@interface CashManager : NSObject
@property(nonatomic,strong)NSMutableArray *hotelModels;
@property(nonatomic,strong)NSMutableArray *Ad2Models;

+(instancetype)shareInstance;
-(void)loadInternetData;
@end
