//
//  YXJEnterFoodClassTableViewCell.m
//  MeishiProject
//
//  Created by Yang on 15/12/5.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJEnterFoodClassTableViewCell.h"
#import "UIImageView+WebCache.h"
#import "enterFoodClassModel.h"

@interface YXJEnterFoodClassTableViewCell ()

@property (weak, nonatomic) IBOutlet UIImageView *m_image;
@property (weak, nonatomic) IBOutlet UILabel *m_name;
@property (weak, nonatomic) IBOutlet UILabel *m_content;
@property (weak, nonatomic) IBOutlet UILabel *m_time;


@end

@implementation YXJEnterFoodClassTableViewCell


+ (instancetype)enterFoodClassTableViewCell:(UITableView *)tableView
{
    static NSString *ID = @"ce";
    YXJEnterFoodClassTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: ID];
    if (cell == nil)
    {
    cell = [[[NSBundle mainBundle] loadNibNamed:@"YXJEnterFoodClassTableViewCell" owner:self options:nil
                ]firstObject];
    }
    return cell;
}




- (void)setM_model:(enterFoodClassModel *)m_model
{
    _m_model = m_model;
    self.m_name.text = _m_model.m_nick;
    self.m_content.text = _m_model.m_content;
    self.m_time.text = _m_model.m_create_time;
    [self.m_image sd_setImageWithURL:[NSURL URLWithString:_m_model.m_head_img]];
}


@end
