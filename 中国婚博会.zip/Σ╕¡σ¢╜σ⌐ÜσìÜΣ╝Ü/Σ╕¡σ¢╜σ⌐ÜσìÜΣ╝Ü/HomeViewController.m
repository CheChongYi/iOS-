//
//  HomeViewController.m
//  中国婚博会
//
//  Created by Admin on 15/11/5.
//  Copyright © 2015年 a. All rights reserved.
//

#import "HomeViewController.h"
#import "CityController.h"
#import "HomeNetManager.h"

#import "AdModel.h"
#import "ButtonCell.h"
#import "AdoneCell.h"
#import "timeCell.h"
#import "weekCell.h"
#import "buyCell.h"
#import "ActivityCell.h"
#import "loveCell.h"

#import "RightViewController.h"
#import "CityController.h"
#import "searchViewController.h"
#import "noticeViewController.h"
#import "personalViewController.h"
#import "marrayNetController.h"

#import "UIImageView+WebCache.h"
#import "MJRefresh.h"
#import "KxMenu.h"

#import "wedViewController.h"
#import "photoViewController.h"
#import "choseViewController.h"
#import "RingController.h"
#import "findViewController.h"
#import "giftController.h"
#import "tourController.h"
#import "fitController.h"
#import "timeController.h"

#import "EyeViewController.h"
#import "chatViewController.h"
#import "fuliViewController.h"
#import "JinViewController.h"
#import "dizhonghaiController.h"
#import "tianshiViewController.h"
#import "FlowerViewController.h"
#import "pujiViewController.h"
#import "loveController.h"
#import "LoveWebController.h"

#import "hunshaController.h"
#import "HaiMaController.h"
#import "freeController.h"
#import "HaiMaController.h"
#import "AD2NETController.h"
#import "baliController.h"
@interface HomeViewController ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)UIPageControl *pageCtl;
@property(nonatomic,strong)UILabel *label;
@end

@implementation HomeViewController{
    NSArray *heights;
    UIButton *_btn1;
    BOOL Tend;
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    UIView *smallView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 100)];
    
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    
     heights=@[@(165),@(60),@(160),@(245),@(200),@(40),@(160),@(650)];
    
    _btn1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _btn1.frame = CGRectMake(290,20, 100, 50);
    [_btn1 setImage:[UIImage imageNamed:@"a02"] forState:UIControlStateNormal];
    _btn1.tintColor=[UIColor whiteColor];
    [_btn1 addTarget:self action:@selector(showMenu:) forControlEvents:UIControlEventTouchUpInside];
    [smallView addSubview:_btn1];
    
    UISearchBar *searchBar=[[UISearchBar alloc]initWithFrame:CGRectMake(80,30, 230, 30)];
    
    searchBar.layer.cornerRadius=18;
    
    searchBar.layer.masksToBounds=YES;
    
    searchBar.placeholder=@"输入商家或商品名称";
    
    searchBar.alpha=0.5;
    
    [smallView addSubview:searchBar];
    
    UIButton *button2=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    button2.frame=CGRectMake(80, 30, 230, 30);
    [button2 addTarget:self action:@selector(danji) forControlEvents:UIControlEventTouchUpInside];
    [smallView addSubview:button2];
    
    [self.navigationItem.titleView sizeToFit];
    
    self.navigationItem.titleView=smallView;
    
    UIButton *button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    button.frame=CGRectMake(0, 20, 80, 50);
    button.tintColor=[UIColor whiteColor];
    [button setTitle:nil forState:UIControlStateNormal];
    [button addTarget:self action:@selector(getcity) forControlEvents:UIControlEventTouchUpInside];
    [smallView addSubview:button];
    
    _label=[[UILabel alloc]initWithFrame:CGRectMake(10, 20, 80, 50)];
    _label.text=@"城市 ∨";
    _label.font=[UIFont systemFontOfSize:16];
    _label.textColor=[UIColor whiteColor];
    [smallView addSubview:_label];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(notify:) name:MTNetManagerRefreshNotify object:nil];
    
    [[HomeNetManager shareInstance]loadInternetData];
    MJRefreshGifHeader *header=[MJRefreshGifHeader headerWithRefreshingBlock:^{
        [self.tableView reloadData];
        [self.tableView.header endRefreshing];
    }];
    NSArray *images=@[[UIImage imageNamed:@"pullto_center_icon"]];
    
    [header setImages:images forState:MJRefreshStateRefreshing];

    self.tableView.header=header;
    
    [self registerCell];
}

- (void)notify:(NSNotification *)note
{
    NSInteger section = [note.object integerValue];
    if (section==10) {
        [self _initHeaderView];
        return;
    }
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.tableView.header endRefreshing];
}

-(void)registerCell{
    [self.tableView registerNib:[UINib nibWithNibName:@"ButtonCell" bundle:nil] forCellReuseIdentifier:@"ButtonCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"timeCell" bundle:nil] forCellReuseIdentifier:@"timeCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"AdoneCell" bundle:nil] forCellReuseIdentifier:@"AdoneCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"weekCell" bundle:nil] forCellReuseIdentifier:@"weekCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"buyCell" bundle:nil] forCellReuseIdentifier:@"buyCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"ActivityCell" bundle:nil] forCellReuseIdentifier:@"ActivityCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"loveCell" bundle:nil] forCellReuseIdentifier:@"loveCell"];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 8;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==6) {
        return 3;
    }
    return 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        ButtonCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ButtonCell"];
        UIButton *button=(UIButton *)[cell viewWithTag:30];
        [button addTarget:self action:@selector(wed) forControlEvents:UIControlEventTouchDown];
        UIButton *button2=(UIButton *)[cell viewWithTag:31];
        [button2 addTarget:self action:@selector(photo) forControlEvents:UIControlEventTouchDown];
        UIButton *button3=(UIButton *)[cell viewWithTag:32];
        [button3 addTarget:self action:@selector(chose) forControlEvents:UIControlEventTouchDown];
        UIButton *button4=(UIButton *)[cell viewWithTag:33];
        [button4 addTarget:self action:@selector(ring) forControlEvents:UIControlEventTouchDown];
        UIButton *button5=(UIButton *)[cell viewWithTag:34];
        [button5 addTarget:self action:@selector(celebration) forControlEvents:UIControlEventTouchDown];
        UIButton *button6=(UIButton *)[cell viewWithTag:35];
        [button6 addTarget:self action:@selector(gift)  forControlEvents:UIControlEventTouchDown];
        UIButton *button7=(UIButton *)[cell viewWithTag:36];
        [button7 addTarget:self action:@selector(tour)  forControlEvents:UIControlEventTouchDown];
        UIButton *button8=(UIButton *)[cell viewWithTag:37];
        [button8 addTarget:self action:@selector(fit)  forControlEvents:UIControlEventTouchDown];
        [cell configCellWithbuttonModels:[HomeNetManager shareInstance].buttonModels];
        return cell;
    }
    else if (indexPath.section==1){
        AdoneCell *cell=[tableView dequeueReusableCellWithIdentifier:@"AdoneCell"];
        [cell configCellWithAdoneModels:[HomeNetManager shareInstance].Ad2Models];
        return cell;
    }
    else if(indexPath.section==2){
        timeCell *cell=[tableView dequeueReusableCellWithIdentifier:@"timeCell"];
            [cell configCellWithtimeModels:[HomeNetManager shareInstance].timeModels];
        return cell;
    }
    else if(indexPath.section==3){
        weekCell *cell=[tableView dequeueReusableCellWithIdentifier:@"weekCell"];
     [cell configCellWithweekModels:[HomeNetManager shareInstance].weekModels];
        for (int i=0; i<4; i++) {
            UIButton *button=(UIButton *)[cell viewWithTag:i];
            button.tag=i;
            UITapGestureRecognizer *Tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(Tap:)];
            [button addGestureRecognizer:Tap];
        }
        return cell;
    }
    else if(indexPath.section==4){
        buyCell *cell=[tableView dequeueReusableCellWithIdentifier:@"buyCell"];
            [cell configCellWithbuyModels:[HomeNetManager shareInstance].buyModels];
        for (int i=0; i<[HomeNetManager shareInstance].buyModels.count; i++) {
            UIButton *button=(UIButton *)[cell viewWithTag:i];
            button.tag=i;
            UITapGestureRecognizer *taps=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(taps:)];
            [button addGestureRecognizer:taps];
        }
        return cell;
    }
    else if (indexPath.section==5){
        static NSString *cellIdentifier=@"cell";
        UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.textLabel.text=@"您可能感兴趣的活动";
        return cell;
    }
    else if(indexPath.section==6){
        ActivityCell *cell=[tableView dequeueReusableCellWithIdentifier:@"ActivityCell"];
            [cell configCellWithActivityModels:[HomeNetManager shareInstance].ActivityModels cellForRowAtIndexPath:indexPath];
        return cell;
    }
    else{
        loveCell *cell=[tableView dequeueReusableCellWithIdentifier:@"loveCell"];
            [cell configCellWithloveModels:[HomeNetManager shareInstance].loveModels];
        for (int i=0; i<7; i++) {
            UIButton *button=(UIButton *)[cell viewWithTag:50+i];
            [button addTarget:self action:@selector(haima) forControlEvents:UIControlEventTouchDown];
//            UITapGestureRecognizer *taps=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(ts:)];
//            [button addGestureRecognizer:taps];
        }
        return cell;
    }
}
-(void)haima{
    HaiMaController *haimaCtl=[[HaiMaController alloc]init];
    [haimaCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:haimaCtl animated:YES];
}
//-(void)ts:(UITapGestureRecognizer *)tap{
//    NSInteger i = tap.view.tag;
//    if (i==0) {
//        baliController *baliCtl=[[baliController alloc]init];
//        [baliCtl setHidesBottomBarWhenPushed:YES];
//        [self.navigationController pushViewController:baliCtl animated:YES];
//    }
//    if (i==2) {
//        HaiMaController *haimaCtl=[[HaiMaController alloc]init];
//        [haimaCtl setHidesBottomBarWhenPushed:YES];
//        [self.navigationController pushViewController:haimaCtl animated:YES];
//    }
//}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [heights[indexPath.section]doubleValue];
}

-(void)getcity{
    CityController *cityCtl=[[CityController alloc]init];
    cityCtl.delegate=self;
    [self.navigationController pushViewController:cityCtl animated:YES];
}
-(void)changeValue:(NSString *)text{
    _label.text=text;
}
-(void)_initHeaderView
{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 120)];
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 120)];
    _scrollView.contentSize = CGSizeMake(ScreenWidth*[HomeNetManager shareInstance].AdModels.count, headerView.frame.size.height);
    _scrollView.delegate = self;
    _scrollView.pagingEnabled=YES;
    //    _scrollview.bounces = NO;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.scrollEnabled = YES;     //是否可以触摸滚动视图 默认可以
    _pageCtl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, 90,  ScreenWidth, 30)];
    _pageCtl.pageIndicatorTintColor = [UIColor grayColor];
    _pageCtl.currentPageIndicatorTintColor = RGBColor(237, 103, 97);
    _pageCtl.backgroundColor = [UIColor clearColor];
    _pageCtl.numberOfPages = [HomeNetManager shareInstance].AdModels.count;
    [_pageCtl addTarget:self action:@selector(changeValues:) forControlEvents:UIControlEventAllEvents];
    for (int i = 0; i < [HomeNetManager shareInstance].AdModels.count; i++)
    {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(ScreenWidth*i, 0, ScreenWidth, _scrollView.frame.size.height)];
        AdModel *model = [HomeNetManager shareInstance].AdModels[i];
        [imageView sd_setImageWithURL:[NSURL URLWithString:model.imgUrl]];
        imageView.tag = i;
        UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapUpClik:)];
        imageView.userInteractionEnabled=YES;
        [imageView addGestureRecognizer:tap];
        
        imageView.userInteractionEnabled = YES;
        [_scrollView addSubview:imageView];
    }
    self.tableView.tableHeaderView = headerView;
    [headerView addSubview:_scrollView];
    [headerView addSubview:_pageCtl];
    //添加计时器timer
    [NSTimer scheduledTimerWithTimeInterval:4 target:self selector:@selector(handleMaxShowTimer) userInfo: nil repeats:YES];
}
//实现计时器
- (void)handleMaxShowTimer{
    ++_pageCtl.currentPage;
    if(Tend)
    {
        [_scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
        _pageCtl.currentPage=0;
    }else
    {
        [_scrollView setContentOffset:CGPointMake(_pageCtl.currentPage*ScreenWidth, 0) animated:YES];
    }
    if (_pageCtl.currentPage==_pageCtl.numberOfPages-1)
    {
        Tend=YES;
    }
    else
    {
        Tend=NO;
    }
}
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    NSInteger page = _scrollView.contentOffset.x/_scrollView.frame.size.width;
    _pageCtl.currentPage = page;
}
- (void)changeValues:(UIPageControl *)pageControl
{
    int page=_scrollView.contentOffset.x/ScreenWidth;
    pageControl.currentPage=page;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    int page=_scrollView.contentOffset.x/ScreenWidth;
    _pageCtl.currentPage=page;
}
-(void)danji{
    searchViewController *searchCtl=[[searchViewController alloc]init];
    [self presentViewController:searchCtl animated:YES completion:nil];
}
- (void) viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    _btn1.frame = CGRectMake(290, 20, 100, 50);
}
- (void)showMenu:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      
      [KxMenuItem menuItem:@"我的通信"
                     image:[UIImage imageNamed:@"my_notice_icon"]
                    target:self
                    action:@selector(pushMenuItem:)],
      
      [KxMenuItem menuItem:@"我的私信"
                     image:[UIImage imageNamed:@"my_personal_letter_icon"]
                    target:self
                    action:@selector(pushMenuItem2:)],
      ];
    
    KxMenuItem *first = menuItems[0];
    first.foreColor = [UIColor colorWithRed:47/255.0f green:112/255.0f blue:225/255.0f alpha:1.0];
    first.alignment = NSTextAlignmentCenter;
    
    [KxMenu showMenuInView:self.view
                  fromRect:sender.frame
                 menuItems:menuItems];
}

- (void) pushMenuItem:(id)sender
{
    noticeViewController *noCtl=[[noticeViewController alloc]init];
    [self.navigationController pushViewController:noCtl animated:YES];
}
- (void) pushMenuItem2:(id)sender
{
    personalViewController *personalCtl=[[personalViewController alloc]init];
    [self.navigationController pushViewController:personalCtl animated:YES];
}
-(void)wed{
    wedViewController *wedCtl=[[wedViewController alloc]init];
    [wedCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:wedCtl animated:YES];
}
-(void)photo{
    photoViewController *photoCtl=[[photoViewController alloc]init];
    [photoCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:photoCtl animated:YES];
}
-(void)chose{
    choseViewController *choseCtl=[[choseViewController alloc]init];
    [choseCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:choseCtl animated:YES];
}
-(void)ring{
    RingController *ringCtl=[[RingController alloc]init];
    [ringCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:ringCtl animated:YES];
}
-(void)celebration{
    findViewController *findCtl=[[findViewController alloc]init];
    [findCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:findCtl animated:YES];
}
-(void)gift{
    giftController *giftCtl=[[giftController alloc]init];
    [giftCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:giftCtl animated:YES];
}
-(void)tour{
    tourController *tourCtl=[[tourController alloc]init];
    [tourCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:tourCtl animated:YES];
}
-(void)fit{
    fitController *fitCtl=[[fitController alloc]init];
    [fitCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:fitCtl animated:YES];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==1) {
        AD2NETController *ad2Ctl=[[AD2NETController alloc]init];
        [ad2Ctl setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:ad2Ctl animated:YES];
    }
    else if(indexPath.section==2){
        timeController *timeCtl=[[timeController alloc]init];
        [timeCtl setHidesBottomBarWhenPushed:YES];
         [self.navigationController pushViewController:timeCtl animated:YES];
    }
    else if (indexPath.section==6) {
        if (indexPath.row==0) {
            loveController *loveCtl=[[loveController alloc]init];
            [loveCtl setHidesBottomBarWhenPushed:YES];
            [self.navigationController pushViewController:loveCtl animated:YES];
        }
        else if(indexPath.row==1){
            LoveWebController *loveCtl=[[LoveWebController alloc]init];
            [loveCtl setHidesBottomBarWhenPushed:YES];
            [self.navigationController pushViewController:loveCtl animated:YES];
        }
        else{
            freeController *freeCtl=[[freeController alloc]init];
            [freeCtl setHidesBottomBarWhenPushed:YES];
            [self.navigationController pushViewController:freeCtl animated:YES];
        }
    }
//    else if (indexPath.section==7){
//                HaiMaController *haimaCtl=[[HaiMaController alloc]init];
//                [haimaCtl setHidesBottomBarWhenPushed:YES];
//                [self.navigationController pushViewController:haimaCtl animated:YES];
//    }
}
- (void)tapUpClik:(UITapGestureRecognizer *)tap
{
    NSInteger i = tap.view.tag;
    if (i == 0) {
        chatViewController *chatCtl=[[chatViewController alloc]init];
        [chatCtl setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:chatCtl animated:YES];
    }
    else if (i == 1)
    {
        fuliViewController *fuliCtl=[[fuliViewController alloc]init];
        [fuliCtl setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:fuliCtl animated:YES];
    }
    else if (i == 2)
    {
        EyeViewController *eyeCtl=[[EyeViewController alloc]init];
        [eyeCtl setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:eyeCtl animated:YES];
    }
    else
    {
        marrayNetController *marryCtl=[[marrayNetController alloc]init];
        [marryCtl setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:marryCtl animated:YES];
    }
}
-(void)danji2{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)Tap:(UITapGestureRecognizer *)tap{
    NSInteger i=tap.view.tag;
    switch (i) {
        case 1:{
            JinViewController *jinCtl=[[JinViewController alloc]init];
            [jinCtl setHidesBottomBarWhenPushed:YES];
            [self.navigationController pushViewController:jinCtl animated:YES];
        }
        break;
        case 2:{
            dizhonghaiController *dzhCtl=[[dizhonghaiController alloc]init];
            [dzhCtl setHidesBottomBarWhenPushed:YES];
            [self.navigationController pushViewController:dzhCtl animated:YES];
        }
            break;
        case 3:{
            tianshiViewController *tsCtl=[[tianshiViewController alloc]init];
            [tsCtl setHidesBottomBarWhenPushed:YES];
            [self.navigationController pushViewController:tsCtl animated:YES];
        }
            break;
            default:
            break;
    }
}
-(void)taps:(UITapGestureRecognizer *)tap{
    NSInteger i=tap.view.tag;
    if (i==1) {
        hunshaController *hunshaCtl=[[hunshaController alloc]init];
        [hunshaCtl setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:hunshaCtl animated:YES];
    }
    else{
        FlowerViewController *flowerCtl=[[FlowerViewController alloc]init];
        [flowerCtl setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:flowerCtl animated:YES];
    }
}
@end
