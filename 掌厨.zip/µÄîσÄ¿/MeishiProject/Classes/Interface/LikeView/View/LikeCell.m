//
//  LikeCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/8.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "LikeCell.h"
#import "UIImageView+WebCache.h"
#import "LIkeModel.h"
#import "LikeViewController.h"


@interface LikeCell ()

@property (weak, nonatomic) IBOutlet UIImageView *likeImage;
@property (weak, nonatomic) IBOutlet UILabel *likeMainTitle;
@property (weak, nonatomic) IBOutlet UILabel *likeDeputytitle;
- (IBAction)likePlayVideo:(id)sender;

@end

@implementation LikeCell

+ (instancetype)cellWithTabelView: (UITableView *)tabelView
{
    static NSString *ID = @"ce";
    LikeCell *cell = [tabelView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"LikeCell" owner:self options:nil]firstObject];
    }
    return cell;
}


- (void)setLikeModel2:(LIkeModel *)likeModel2
{
    _likeModel2 = likeModel2;
    self.likeMainTitle.text = likeModel2.liketitle;
    self.likeDeputytitle.text = likeModel2.likedescription;
    [self.likeImage  sd_setImageWithURL:[NSURL URLWithString:likeModel2.likeimage]];
}


- (IBAction)likePlayVideo:(id)sender
{
    if ([self.delegate respondsToSelector:@selector(likeCellDidClickPlay:)])
    {
        [self.delegate likeCellDidClickPlay:self];
    }
}
@end
