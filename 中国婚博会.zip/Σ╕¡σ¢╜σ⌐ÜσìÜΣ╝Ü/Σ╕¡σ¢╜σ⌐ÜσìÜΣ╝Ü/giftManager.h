//
//  giftManager.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>
extern NSString *giftManagerRefreshNotify;
@interface giftManager : NSObject
@property(nonatomic,strong)NSMutableArray *tehuiModels;
@property(nonatomic,strong)NSMutableArray *xianJinModels;
@property(nonatomic,strong)NSMutableArray *shangpinleibie2Models;
@property(nonatomic,strong)NSMutableArray *mouthModels;

+(instancetype)shareInstance;
- (void)loadInternetData;
@end
