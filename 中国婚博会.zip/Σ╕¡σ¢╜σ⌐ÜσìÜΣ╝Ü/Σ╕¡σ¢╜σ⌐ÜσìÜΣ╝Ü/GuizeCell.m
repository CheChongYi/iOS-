//
//  GuizeCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/11.
//  Copyright © 2015年 a. All rights reserved.
//

#import "GuizeCell.h"
#import "GuizeModel.h"
#import "UIImageView+WebCache.h"
@implementation GuizeCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithGuizeModels:(NSArray *)GuizeModels cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    GuizeModel *model=GuizeModels[indexPath.row];
    [self.iconView sd_setImageWithURL:[NSURL URLWithString:model.imgurl]];
    self.ideacText.text=model.idesc;
}
@end
