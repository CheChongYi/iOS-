//
//  rangKingModel.h
//  MeishiProject
//
//  Created by Yang on 15/12/3.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface rangKingModel : NSObject


@property (nonatomic, copy) NSString *m_rangKingID;

@property (nonatomic, copy) NSString *m_rangKingTitle;

@property (nonatomic, copy) NSString *m_rangKingImage;

@property (nonatomic, copy) NSString *m_rangKingVideo;

@property (nonatomic, copy) NSString *m_rangKingVideo1;

@property (nonatomic, copy) NSString *m_rangKingContent;





@end
