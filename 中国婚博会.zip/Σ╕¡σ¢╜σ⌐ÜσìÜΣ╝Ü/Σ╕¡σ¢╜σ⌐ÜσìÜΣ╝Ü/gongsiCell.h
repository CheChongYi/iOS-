//
//  gongsiCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface gongsiCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
-(void)configCellWithgongsiModels:(NSArray *)gongsiModels cellForRowAtIndexPath:(NSIndexPath *)indexPath;
@end
