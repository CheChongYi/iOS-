//
//  buttonModel.h
//  中国婚博会
//
//  Created by Admin on 15/11/6.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface buttonModel : NSObject
@property(nonatomic,strong)NSString *imgUrl;
@property(nonatomic,strong)NSString *title;
//@property(nonatomic,strong)NSString *link;
@end
