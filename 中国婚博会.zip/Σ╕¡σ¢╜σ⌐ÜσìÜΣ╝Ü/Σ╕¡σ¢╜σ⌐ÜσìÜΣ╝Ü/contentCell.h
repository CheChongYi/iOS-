//
//  contentCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/9.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface contentCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIWebView *webView;
-(void)configCellWithcontentModels:(NSArray *)contentModels;
@end
