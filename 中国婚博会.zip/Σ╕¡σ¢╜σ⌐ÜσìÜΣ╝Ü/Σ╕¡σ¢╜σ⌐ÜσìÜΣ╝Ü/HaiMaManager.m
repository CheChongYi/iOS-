//
//  HaiMaManager.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/4.
//  Copyright © 2015年 a. All rights reserved.
//

#import "HaiMaManager.h"
#import "AFNetworking.h"
#import "HaiMaModel.h"
#import "HaiMaNameModel.h"
#import "rec_attrsModel.h"
#import "HaiMaLogoModel.h"
#import "ShopsModel.h"
#import "CanShuModel.h"
#import "TuWenModel.h"
#import "XiaoFeiModel.h"
NSString *HaiMaManagerRefreshNotify= @"HaiMaManagerRefreshNotify";
static HaiMaManager *manager=nil;
@implementation HaiMaManager
+(instancetype)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager=[[[self class]alloc]init];
        }
    });
    return manager;
}
-(void)loadInternetData{
    [self loadHaiMaAdData];
    [self loadHaiMaNameData];
    [self loadLogoData];
    [self loadShopsData];
    [self loadCanShuData];
    [self loadTuWenData];
}
-(void)loadHaiMaAdData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:HaiMaUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        HaiMaModel *model=[[HaiMaModel alloc]init];
        model.imgArray=dic[@"imgs"];
        if (!_HaiMaModels) {
            _HaiMaModels=[NSMutableArray array];
        }
        [self.HaiMaModels addObject:model];
        [[NSNotificationCenter defaultCenter]postNotificationName:HaiMaManagerRefreshNotify object:@(10)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
        [alertView show];
        [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
    }];
}
-(void)loadHaiMaNameData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:HaiMaUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        HaiMaNameModel *model=[[HaiMaNameModel alloc]init];
        model.product_name=dic[@"product_name"];
        model.mall_price=dic[@"mall_price"];
        if (!_HaiMaNameModels) {
            _HaiMaNameModels=[NSMutableArray array];
        }
        [self.HaiMaNameModels addObject:model];
        [[NSNotificationCenter defaultCenter]postNotificationName:HaiMaManagerRefreshNotify object:@(0)];
    
        NSDictionary *dict=dic[@"rec_attrs"];
        NSArray *arr=dict[@"data"];
        for (NSDictionary *dt in arr) {
            rec_attrsModel *model=[[rec_attrsModel alloc]init];
            model.name=dt[@"name"];
            model.value=dt[@"value"];
            if (!_rec_attrsModels) {
                _rec_attrsModels=[NSMutableArray array];
            }
            [self.rec_attrsModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:HaiMaManagerRefreshNotify object:@(3)];
        
        NSArray *array2=dic[@"xiaobao_text"];
        for (NSDictionary *dic in array2) {
            XiaoFeiModel *model=[[XiaoFeiModel alloc]init];
            model.icon=dic[@"icon"];
            model.text=dic[@"text"];
            NSLog(@"%@",model.text);
            if (!_XiaoFeiModels) {
                _XiaoFeiModels=[NSMutableArray array];
            }
            [self.XiaoFeiModels addObject:model];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadLogoData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:HaiMaLogoUrl parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        HaiMaLogoModel *model=[[HaiMaLogoModel alloc]init];
        model.store_name=dic[@"store_name"];
        model.logo=dic[@"logo"];
        model.address=dic[@"address"];
        model.tel=dic[@"tel"];
        model.branch_num=dic[@"branch_num"];
        model.product_num=dic[@"product_num"];
        model.album_num=dic[@"album_num"];
        if (!_HaiMaLogoModels) {
            _HaiMaLogoModels=[NSMutableArray array];
        }
        [self.HaiMaLogoModels addObject:model];
        [[NSNotificationCenter defaultCenter]postNotificationName:HaiMaManagerRefreshNotify object:@(1)];
        [[NSNotificationCenter defaultCenter]postNotificationName:HaiMaManagerRefreshNotify object:@(5)];
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}
-(void)loadShopsData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:HaiMaShopUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *array=responseObject[@"data"];
        for (NSDictionary *dic in array) {
            ShopsModel *model=[[ShopsModel alloc]init];
            model.product_name=dic[@"product_name"];
            model.img_url=dic[@"img_url"];
            model.mall_price=dic[@"mall_price"];
            model.market_price=dic[@"market_price"];
            if (!_ShopsModels) {
                _ShopsModels=[NSMutableArray array];
            }
            [self.ShopsModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:HaiMaManagerRefreshNotify object:@(9)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadCanShuData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:HaiMaCanShuUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *array=responseObject[@"data"];
        for (NSDictionary *dic in array) {
            CanShuModel *model=[[CanShuModel alloc]init];
            model.title=dic[@"title"];
            NSArray *arr=dic[@"data"];
            for (NSDictionary *dict in arr) {
                model.name=dict[@"name"];
                model.value=dict[@"value"];
            }
            if (!_CanShuModels) {
                _CanShuModels=[NSMutableArray array];
            }
            [self.CanShuModels addObject:model];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadTuWenData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:HaiMaTuWenUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"content"];

        for (NSDictionary *dic in array) {
            TuWenModel *model=[[TuWenModel alloc]init];
            model.title=dic[@"title"];
            
            NSArray *arr=dic[@"data"];
            NSDictionary *middleDic = arr[0];
            model.imgurl = middleDic[@"middle"][@"url"];
            
            NSDictionary *contentKeyDic = arr[1];
            model.contents = contentKeyDic[@"content"];
            if (!_TuWenModels) {
                _TuWenModels=[NSMutableArray array];
            }
            [self.TuWenModels addObject:model];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)     {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
