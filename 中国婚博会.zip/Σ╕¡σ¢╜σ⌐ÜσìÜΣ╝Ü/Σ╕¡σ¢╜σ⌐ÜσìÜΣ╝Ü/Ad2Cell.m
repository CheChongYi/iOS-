//
//  Ad2Cell.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import "Ad2Cell.h"
#import "storeModel.h"
#import "UIImageView+WebCache.h"
@implementation Ad2Cell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
- (void)configCellWithAd2Models:(NSArray *)Ad2Models cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    for (int i=0; i<20; i++) {
        storeModel *model=Ad2Models[indexPath.row];
        [self.imgView sd_setImageWithURL:[NSURL URLWithString:model.imgurl]];
        self.titleLabel.text=model.title;
        self.priceLabel.text=[NSString stringWithFormat:@"￥%@",model.price];
        self.totalLabel.text=[NSString stringWithFormat:@"本期剩余%@份",model.total];
        self.applyLabel.text=[NSString stringWithFormat:@"已有%@人申请",model.apply];
    }
}
@end
