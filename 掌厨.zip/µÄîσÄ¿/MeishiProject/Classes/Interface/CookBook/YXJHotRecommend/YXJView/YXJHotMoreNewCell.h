//
//  YXJHotMoreNewCell.h
//  MeishiProject
//
//  Created by Yang on 15/11/20.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>


@class YXJHotMoreModel;
@class YXJHotMoreNewCell;

@protocol YXJHotMoreNewCellDelegate <NSObject>

- (void)yxjHotMoreNewCellDidClickPlay:(YXJHotMoreNewCell *)cell;

@end

@interface YXJHotMoreNewCell : UITableViewCell


@property (nonatomic, strong) YXJHotMoreModel *m_hotNewModel;

+ (instancetype)cellWithTableView:(UITableView *)tableView;

@property (nonatomic, weak) id<YXJHotMoreNewCellDelegate>delegate;


@end
