//
//  guijuCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import "guijuCell.h"
#import "guijuModel.h"

@implementation guijuCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithguijuModels:(NSArray *)guijuModels{
    guijuModel *model=guijuModels[0];
    _titleLabel.text=model.title;
}
@end
