//
//  hunlizhusediaoModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface hunlizhusediaoModel : NSObject
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *img_url;
@end
