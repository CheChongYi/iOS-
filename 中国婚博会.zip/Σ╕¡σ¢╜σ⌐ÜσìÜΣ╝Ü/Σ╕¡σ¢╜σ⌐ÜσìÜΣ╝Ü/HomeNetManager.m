//
//  MTNetManager.m
//  中国婚博会
//
//  Created by Admin on 15/11/5.
//  Copyright © 2015年 a. All rights reserved.
//

#import "HomeNetManager.h"
#import "AFNetworking.h"

#import "AdModel.h"
#import "buttonModel.h"
#import "AdoneModel.h"
#import "timeModel.h"
#import "weekModel.h"
#import "buyModel.h"
#import "ActivityModel.h"
#import "loveModel.h"
#import "searchModel.h"
#import "Ad2_1Model.h"
#import "Ad2Model.h"
#import "baliModel.h"
NSString *MTNetManagerRefreshNotify = @"MTNetManagerRefreshNotify";

static HomeNetManager *manager=nil;
@implementation HomeNetManager
+(instancetype)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager=[[[self class]alloc]init];
        }
    });
    return manager;
}

-(void)loadInternetData{
    [self loadAdData];
    [self loadbuttonData];
    [self loadtimeData];
    [self loadweekData];
    [self loadbuyData];
    [self loadActivityData];
    [self loadloveData];
    [self loadAd2Data];
    [self loadBaLiData];
}
-(void)loadAdData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:URL1 parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"banner"];
        for (NSDictionary *dic in array) {
            AdModel *model=[[AdModel alloc]init];
            model.imgUrl=dic[@"img_url"];
            if (!_AdModels) {
                _AdModels=[NSMutableArray array];
            }
            [self.AdModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:MTNetManagerRefreshNotify object:@(10)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
        [alertView show];
        [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
    }];
}

-(void)loadbuttonData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:URL1 parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"category"];
        for (NSDictionary *dic in array) {
            buttonModel *model=[[buttonModel alloc]init];
            model.title=dic[@"title"];
            model.imgUrl=dic[@"img_url"];
//            model.link=dic[@"link"];
            if (!_buttonModels) {
                _buttonModels=[NSMutableArray array];
            }
            [self.buttonModels addObject:model];
    }
              [[NSNotificationCenter defaultCenter]postNotificationName:MTNetManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    }];
}
-(void)loadAd2Data{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:URL2 parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"broadcast"];
        for (NSDictionary *dic in array) {
            Ad2Model *model=[[Ad2Model alloc]init];
            model.title=dic[@"title"];
            if (!_Ad2Models) {
                _Ad2Models=[NSMutableArray array];
            }
            [self.Ad2Models addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:MTNetManagerRefreshNotify object:@(1)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadtimeData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:URL2 parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"limit_activity"];
        for (NSDictionary *dic in array) {
            timeModel *model=[[timeModel alloc]init];
            model.title=dic[@"title"];
            model.imgUrl=dic[@"img_url"];
            model.title2=dic[@"idesc"];
            NSDictionary *dict=dic[@"extra"];
            model.extra=dict[@"beginDate"];
            model.extra2=dict[@"endDate"];
            if (!_timeModels) {
                _timeModels=[NSMutableArray array];
            }
            [self.timeModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:MTNetManagerRefreshNotify object:@(2)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    }];
}
-(void)loadweekData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:URL1 parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSDictionary *dics=dic[@"benzhoutuijian"];
        NSArray *array=dics[@"data"];
        for (NSDictionary *dic in array) {
            weekModel *model=[[weekModel alloc]init];
            model.title=dic[@"title"];
            model.title2=dic[@"idesc"];
            model.imgUrl=dic[@"img_url"];
            model.link=dic[@"link"];
            NSLog(@"%@",model.link);
            if (!_weekModels) {
                _weekModels=[NSMutableArray array];
            }
            [self.weekModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:MTNetManagerRefreshNotify object:@(3)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    }];
}

-(void)loadbuyData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:URL1 parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSDictionary *dics=dic[@"remendinggou"];
        NSArray *array=dics[@"data"];

        for (NSDictionary *dic in array) {
            buyModel *model=[[buyModel alloc]init];
            model.title=dic[@"title"];
            model.title2=dic[@"idesc"];
            model.imgUrl=dic[@"img_url"];
            if (!_buyModels) {
                _buyModels=[NSMutableArray array];
            }
            [self.buyModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:MTNetManagerRefreshNotify object:@(4)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    }];
}

-(void)loadActivityData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:URL1 parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"guess_huodong"];
        for (NSDictionary *dic in array) {
            ActivityModel *model=[[ActivityModel alloc]init];
            model.title=dic[@"title"];
            model.imgUrl=dic[@"img_url"];
            NSDictionary *dics=dic[@"store"];
            model.storeName=dics[@"store_name"];
            model.logo=dics[@"logo"];
            if (!_ActivityModels) {
                _ActivityModels=[NSMutableArray array];
            }
            [self.ActivityModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:MTNetManagerRefreshNotify object:@(5)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    }];
}

-(void)loadloveData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:URL1 parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"guess_product"];
        for (NSDictionary *dic in array) {
            loveModel *model=[[loveModel alloc]init];
            model.title=dic[@"title"];
            model.imgUrl=dic[@"img_url"];
            model.price=dic[@"mall_price"];
            NSDictionary *dics=dic[@"store"];
            model.storeName=dics[@"store_name"];
            if (!_loveModels) {
                _loveModels=[NSMutableArray array];
            }
            [self.loveModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:MTNetManagerRefreshNotify object:@(6)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    }];
}
-(void)loadBaLiData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:baliUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        baliModel *model=[[baliModel alloc]init];
        model.product_name=dic[@"product_name"];
        model.mall_price=dic[@"mall_price"];
        model.market_price=dic[@"market_price"];
        model.imgs=dic[@"imgs"];
        if (!_baliModels) {
            _baliModels=[NSMutableArray array];
        }
        [self.baliModels addObject:model];
        [[NSNotificationCenter defaultCenter]postNotificationName:MTNetManagerRefreshNotify object:@(7)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)     {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
