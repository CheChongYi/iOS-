//
//  YXJEnterMoreModel.m
//  MeishiProject
//
//  Created by Yang on 15/11/24.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJEnterMoreModel.h"

@implementation YXJEnterMoreModel

@end
