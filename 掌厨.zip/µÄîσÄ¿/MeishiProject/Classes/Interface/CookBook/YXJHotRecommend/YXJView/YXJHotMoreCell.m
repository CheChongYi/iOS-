//
//  YXJHotMoreCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/19.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJHotMoreCell.h"
#import "UIImageView+WebCache.h"
#import "YXJHotMoreModel.h"
#import "YXJHotMoreViewController.h"
#import "Header.h"



@interface YXJHotMoreCell ()

@property (weak, nonatomic) IBOutlet UIImageView *m_image;
@property (weak, nonatomic) IBOutlet UILabel *m_titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *m_descriptionLabel;
- (IBAction)m_clickPlay:(id)sender;


@end

@implementation YXJHotMoreCell


+ (instancetype)cellWithTabelView: (UITableView *)tabelView
{
    static NSString *ID = @"ce";
    YXJHotMoreCell *cell = [tabelView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"YXJHotMoreCell" owner:nil options:nil]firstObject];
    }
    return cell;
}



- (void)setM_hotMoreModel:(YXJHotMoreModel *)m_hotMoreModel
{
    _m_hotMoreModel = m_hotMoreModel;
    self.m_titleLabel.text = _m_hotMoreModel.m_hotMoreHotTitle;
    self.m_descriptionLabel.text = _m_hotMoreModel.m_hotMoreHotDescription;
    [self.m_image sd_setImageWithURL:[NSURL URLWithString:_m_hotMoreModel.m_hotMoreHotImage]];
    
}





- (IBAction)m_clickPlay:(id)sender
{
    if ([self.delegate respondsToSelector:@selector(yxjHotMoreCellDidClickVideo:)])
    {
        [self.delegate yxjHotMoreCellDidClickVideo:self];
    }
}
@end
