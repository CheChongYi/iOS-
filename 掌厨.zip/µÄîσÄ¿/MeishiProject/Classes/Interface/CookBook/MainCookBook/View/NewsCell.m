//
//  NewsCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/8.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "NewsCell.h"
#import "UIImageView+WebCache.h"
#import "NewModel.h"



@interface NewsCell ()

@property (weak, nonatomic) IBOutlet UIImageView *newsImage;
@property (weak, nonatomic) IBOutlet UILabel *newsTitle;
@property (weak, nonatomic) IBOutlet UILabel *newsDescription;
@property (weak, nonatomic) IBOutlet UILabel *newsPlay;
- (IBAction)newsPlayVideo:(id)sender;

@end


@implementation NewsCell

+ (instancetype)cellWithTabelView:(UITableView *)tableView
{
    static NSString *ID = @"ce";
    NewsCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle]loadNibNamed:@"NewsCell" owner:self options:nil]firstObject];
    }
    return cell;
}


- (void)setModel:(NewModel *)Model
{
    _Model = Model;
    self.newsTitle.text = Model.newsTitle;
    self.newsDescription.text = Model.newsDescription;
    self.newsPlay.text = [NSString stringWithFormat:@"%@人做过",Model.newsPlay];
    [self.newsImage sd_setImageWithURL:[NSURL URLWithString:Model.newsImage]];
    
}



- (IBAction)newsPlayVideo:(id)sender
{
    if ([self.delegate respondsToSelector:@selector(newsCellDidClickPlay:)])
    {
        [self.delegate newsCellDidClickPlay:self];
    }
}
@end
