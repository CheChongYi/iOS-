//
//  hunlizhusediaoCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import "hunlizhusediaoCell.h"
#import "hunlizhusediaoModel.h"
#import "UIImageView+WebCache.h"
@implementation hunlizhusediaoCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithhunlizhusediaoModels:(NSArray *)hunlizhusediaoModels{
    for (int i=0; i<5; i++) {
        UIImageView *iconView=(UIImageView *)[self viewWithTag:20+i];
        hunlizhusediaoModel *model=hunlizhusediaoModels[i];
        [iconView sd_setImageWithURL:[NSURL URLWithString:model.img_url]];
    }
    
    
}
@end
