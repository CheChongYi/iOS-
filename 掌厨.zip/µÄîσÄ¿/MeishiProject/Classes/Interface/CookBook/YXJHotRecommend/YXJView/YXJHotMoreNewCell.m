//
//  YXJHotMoreNewCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/20.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJHotMoreNewCell.h"
#import "UIImageView+WebCache.h"
#import "YXJHotMoreModel.h"
#import "YXJHotMoreViewController.h"



@interface YXJHotMoreNewCell ()

@property (weak, nonatomic) IBOutlet UIImageView *m_newImage;
@property (weak, nonatomic) IBOutlet UILabel *m_titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *m_descriptionLabel;
- (IBAction)m_video:(id)sender;

@end

@implementation YXJHotMoreNewCell


+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *ID = @"ce";
    YXJHotMoreNewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"YXJHotMoreNewCell" owner:self options:nil]firstObject];
    }
    return cell;
}



- (void)setM_hotNewModel:(YXJHotMoreModel *)m_hotNewModel
{
    _m_hotNewModel = m_hotNewModel;
    self.m_titleLabel.text = _m_hotNewModel.m_hotMoreNewTitle;
    self.m_descriptionLabel.text = _m_hotNewModel.m_hotMoreNewDescription;
    [self.m_newImage sd_setImageWithURL:[NSURL URLWithString:_m_hotNewModel.m_hotMoreNewImage]];
}



- (IBAction)m_video:(id)sender
{
    if ([self.delegate respondsToSelector:@selector(yxjHotMoreNewCellDidClickPlay:)])
    {
        [self.delegate yxjHotMoreNewCellDidClickPlay:self];
    }
}
@end
