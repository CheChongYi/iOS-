//
//  giftController.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import "giftController.h"
#import "giftManager.h"
#import "MJRefresh.h"
#import "UIImageView+WebCache.h"
#import "tehuiModel.h"

#import "xianJinCell.h"
#import "shangpinleibie2Cell.h"
#import "monthCell.h"
@interface giftController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation giftController{
    NSArray *heights;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    self.navigationItem.title=@"结婚百货";
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],UITextAttributeTextColor, nil]];
    UIBarButtonItem *leftItem=[[UIBarButtonItem alloc]initWithTitle:@"< " style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    leftItem.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=leftItem;
    
    [[giftManager shareInstance]loadInternetData];
    MJRefreshGifHeader *header=[MJRefreshGifHeader headerWithRefreshingBlock:^{
        [self.tableView reloadData];
        [self.tableView.header endRefreshing];
    }];
    NSArray *images=@[[UIImage imageNamed:@"pullto_center_icon"]];
    
    [header setImages:images forState:MJRefreshStateRefreshing];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(notify:) name:giftManagerRefreshNotify object:nil];
    [self registerCell];
    self.tableView.header=header;
    heights=@[@(70),@(40),@(200),@(50),@(100)];
}
-(void)registerCell{
    [self.tableView registerNib:[UINib nibWithNibName:@"xianJinCell" bundle:nil] forCellReuseIdentifier:@"xianJinCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"shangpinleibie2Cell" bundle:nil] forCellReuseIdentifier:@"shangpinleibie2Cell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"monthCell" bundle:nil] forCellReuseIdentifier:@"monthCell"];
}
-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)notify:(NSNotification *)note
{
    NSInteger section = [note.object integerValue];
    if (section==10) {
        [self _initHeaderView];
        return;
    }
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.tableView.header endRefreshing];
}
-(void)_initHeaderView
{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 120)];
    for (int i = 0; i < [giftManager shareInstance].tehuiModels.count; i++)
    {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(ScreenWidth*i, 0, ScreenWidth, headerView.frame.size.height)];
        tehuiModel *model = [giftManager shareInstance].tehuiModels[i];
        [imageView sd_setImageWithURL:[NSURL URLWithString:model.imgurl]];
        imageView.tag = i;
        imageView.userInteractionEnabled = YES;
        [headerView addSubview:imageView];
    }
    self.tableView.tableHeaderView = headerView;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 5;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==4) {
        return 4;
    }
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
    xianJinCell *cell=[tableView dequeueReusableCellWithIdentifier:@"xianJinCell"];
        [cell configCellWithxianJinModels:[giftManager shareInstance].xianJinModels];
        return cell;
    }
    else if(indexPath.section==1){
        static NSString *cellIdentifier=@"cell";
        UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.textLabel.text=@"商品类别";
        return cell;
    }
    else if(indexPath.section==2){
        shangpinleibie2Cell *cell=[tableView dequeueReusableCellWithIdentifier:@"shangpinleibie2Cell"];
        [cell configCellWithshangpinleibie2Models:[giftManager shareInstance].shangpinleibie2Models];
        return cell;
    }
    else if(indexPath.section==3){
        static NSString *cellIdentifier=@"cell";
        UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.textLabel.text=@"商家口碑";
        UIButton *button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.frame=CGRectMake(320, 0,50, 50);
        [button setTitle:@"更多" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchDown];
        [cell addSubview:button];
        return cell;
    }
    else{
        monthCell *cell=[tableView dequeueReusableCellWithIdentifier:@"monthCell"];
        [cell configCellWithmonthModels:[giftManager shareInstance].mouthModels cellForRowAtIndexPath:indexPath];
        return cell;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [heights[indexPath.section]doubleValue];
}
@end
