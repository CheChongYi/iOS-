//
//  YXJHotMoreViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/19.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJHotMoreViewController.h"
#import "YXJClickImage1Controller.h"
#import "YXJClickImage1View.h"
#import "Header.h"
#import "AFNetworking.h"
#import "YXJHotMoreModel.h"
#import "YXJHotMoreCell.h"
#import "YXJHotMoreNewCell.h"
@import MediaPlayer;
#import "MJRefresh.h"



@interface YXJHotMoreViewController ()<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,YXJHotMoreCellDelegate,YXJHotMoreNewCellDelegate>
{
    NSInteger m_page;
}

@property(nonatomic,strong) UIScrollView *m_scrollView;

@property (nonatomic, strong) UIView *m_slideView;

@property (nonatomic, strong) UITableView *m_oneTableView;

@property (nonatomic, strong) UITableView *m_TwoTableView;

@property (nonatomic, strong) NSMutableArray *m_oneArray;

@property (nonatomic, strong) NSMutableArray *m_twoArray;
/**
 *  热门和新品的tag值
 */
@property (nonatomic, assign) NSInteger m_choseIndex;



@end

@implementation YXJHotMoreViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setNavigationItem];
    [self createScrollView];
    [self createTopView];
    //热门下拉刷新
    [self xiala];
    //新品下拉刷新
    [self newsXiala];

}



- (void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = NO;
}



- (void)setNavigationItem
{
    //取消自带的返回按钮，添加自定义返回按钮
    [self.navigationItem setHidesBackButton:YES];
    UIBarButtonItem *returnBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"returnButton.png"] style:UIBarButtonItemStyleDone target:self action:@selector(popViewController)];
    returnBtn.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = returnBtn;
}



- (void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)createScrollView
{
    //当前控制器自动适应ScrollView
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    self.m_scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0,0, screenWidth, screenHeight)];
    self.m_scrollView.pagingEnabled = YES;
    self.m_scrollView.contentSize = CGSizeMake(screenWidth*2,0);
    self.m_scrollView.delegate = self;
    [self.view addSubview:self.m_scrollView];
    
    self.m_oneTableView = [[UITableView alloc] initWithFrame:CGRectMake(0,64, screenWidth,screenHeight) style:UITableViewStylePlain];
    self.m_oneTableView.delegate = self;
    self.m_oneTableView.dataSource = self;
    //取消TableViewd的行线
    self.m_oneTableView.separatorStyle = NO;
    [self.m_scrollView addSubview:self.m_oneTableView];
    
   //下拉刷新(热门)
    MJRefreshGifHeader *header = [MJRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(xiala)];
    // 设置刷新图片
     NSArray *arr = @[[UIImage imageNamed:@"refurbish1.png"],[UIImage imageNamed:@"refurbish2.png"]];
    [header setImages:arr forState:MJRefreshStateRefreshing];
    self.m_oneTableView.header = header;
    
   //上拉加载
    MJRefreshAutoGifFooter *footer = [MJRefreshAutoGifFooter footerWithRefreshingTarget:self refreshingAction:@selector(shangla)];
    // 设置刷新图片
  NSArray *arr1 = @[[UIImage imageNamed:@"refurbish1.png"],[UIImage imageNamed:@"refurbish2.png"]];
    [footer setImages:arr1 forState:MJRefreshStateRefreshing];
   // 设置尾部
    self.m_oneTableView.footer = footer;
    
    
    self.m_TwoTableView = [[UITableView alloc] initWithFrame:CGRectMake(screenWidth, 64, screenWidth,screenHeight) style:UITableViewStylePlain];
    self.m_TwoTableView.delegate = self;
    self.m_TwoTableView.dataSource = self;
     //取消TableViewd的行线 
    self.m_TwoTableView.separatorStyle = NO;
    [self.m_scrollView addSubview:self.m_TwoTableView];
    //新品下拉刷新
    MJRefreshGifHeader *newsHeader = [MJRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(newsXiala)];
    NSArray *newsArr1 = @[[UIImage imageNamed:@"refurbish1.png"],[UIImage imageNamed:@"refurbish2.png"]];
    [newsHeader setImages:newsArr1 forState:MJRefreshStateRefreshing];
    self.m_TwoTableView.header = newsHeader;
    //新品上拉加载
    MJRefreshAutoGifFooter *newsFooter = [MJRefreshAutoGifFooter footerWithRefreshingTarget:self refreshingAction:@selector(newsShangla)];
    NSArray *newsArr2 = @[[UIImage imageNamed:@"refurbish1.png"],[UIImage imageNamed:@"refurbish2.png"]];
    [newsHeader setImages:newsArr2 forState:MJRefreshStateRefreshing];
    self.m_TwoTableView.footer = newsFooter;
    
}



- (void)createTopView
{
    UIView *topView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 140, 40)];
    self.navigationItem.titleView = topView;
    
    UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 70, 40)];
    label1.text = @"热门";
    label1.textColor = [UIColor whiteColor];
    //设置文本内容居中
    label1.textAlignment = NSTextAlignmentCenter;
    label1.tag = 0;
    //只要添加手势userInteractionEnabled属性必须是yes
    label1.userInteractionEnabled = YES;
    [topView addSubview:label1];
    //添加手势
    UITapGestureRecognizer *label1Tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(label1TapSlidingRange:)];
    [label1 addGestureRecognizer:label1Tap];
    
    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(70, 0, 70, 40)];
    label2.text = @"新品";
    label2.textColor = [UIColor whiteColor];
    label2.textAlignment = NSTextAlignmentCenter;
    label2.tag = 1;
    label2.userInteractionEnabled = YES;
    [topView addSubview:label2];
    UITapGestureRecognizer *label2Tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(label2TapSlidingRange:)];
    [label2 addGestureRecognizer:label2Tap];
    
    
    self.m_slideView = [[UIView alloc] initWithFrame:CGRectMake(0, 35, 70, 5)];
    self.m_slideView.backgroundColor = [UIColor whiteColor];
    [topView addSubview:self.m_slideView];
    
}


//设置scrollView的偏移量
- (void)label1TapSlidingRange:(UITapGestureRecognizer *)tap
{
    NSInteger i = tap.view.tag;
    self.m_choseIndex = i;
    [self.m_scrollView setContentOffset:CGPointMake(i*screenWidth, 0) animated:YES];
}


- (void)label2TapSlidingRange:(UITapGestureRecognizer *)tap
{
    NSInteger i = tap.view.tag;
    self.m_choseIndex = i;
    [self.m_scrollView setContentOffset:CGPointMake(i*screenWidth, 0) animated:YES];
    
}


#pragma mark - UIScrollViewDelegate
// 手势滑动视图减速完成后调用方法
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
   
    [UIView animateWithDuration:0.3 animations:^{
        NSInteger i = self.m_scrollView.contentOffset.x/screenWidth;
        self.m_slideView.frame = CGRectMake(i*70, 35, 70, 5);
    }];
}


//点击手势视图完成后调用方法
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    [UIView animateWithDuration:0.3 animations:^{
        NSInteger i = self.m_scrollView.contentOffset.x/screenWidth;
        self.m_slideView.frame = CGRectMake(i*70, 35, 70, 5);
    }];
    
}




- (NSMutableArray *)m_oneArray
{
    if (_m_oneArray == nil)
    {
        _m_oneArray = [NSMutableArray array];
    }
    return _m_oneArray;
}




//下拉刷新
- (void)xiala
{
    m_page = 1;
    [self createOneTableViewReaquestWithPage:m_page];
}



//上拉加载
- (void)shangla
{
    m_page++;
    [self createOneTableViewReaquestWithPage:m_page];
}



//热门更多里面的热门界面请求
- (void)createOneTableViewReaquestWithPage:(NSInteger)page;
{
    NSString *strUrl = [NSString stringWithFormat:@"http://api.izhangchu.com/?methodName=HomeMore&page=%ld&type=1",page];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:strUrl parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        //下拉刷新时首先清空所有数组数据
        if (page == 1)
        {
            [self.m_oneArray removeAllObjects];
        }
        NSDictionary *dic = responseObject[@"data"];
        NSArray *arr = dic[@"data"];
        for (NSDictionary *dic2 in arr) {
            YXJHotMoreModel *model = [[YXJHotMoreModel alloc] init];
            model.m_hotMoreHotImage = dic2[@"image"];
            model.m_hotMoreHotTitle = dic2[@"title"];
            model.m_hotMoreHotDescription = dic2[@"description"];
            model.m_hotMoreHotVideo = dic2[@"video"];
            model.m_hotMoreHotVideo1 = dic2[@"video1"];
            model.m_hotMoreHotContent = dic2[@"content"];
            model.m_id = dic2[@"id"];
            [self.m_oneArray addObject:model];
        }
        [self.m_oneTableView reloadData];
        //刷新结束
        [self.m_oneTableView.header endRefreshing];
        [self.m_oneTableView.footer endRefreshing];
        
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}




#pragma mark - UITableViewDelegate(初始化控制器并且把模型数据传给YXJClickImage1Controller)
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.m_choseIndex == 0)
    {
        YXJHotMoreModel *model4 = self.m_oneArray[indexPath.row];
        YXJClickImage1Controller *clickImage = [[YXJClickImage1Controller alloc] init];
        [clickImage setHidesBottomBarWhenPushed:YES];
        clickImage.m_dishesId = model4.m_id;
        clickImage.m_headImageString = model4.m_hotMoreHotImage;
        clickImage.m_title = model4.m_hotMoreHotTitle;
        clickImage.m_content = model4.m_hotMoreHotContent;
        clickImage.m_video = model4.m_hotMoreHotVideo;
        clickImage.m_video1 = model4.m_hotMoreHotVideo1;
        [self.navigationController pushViewController:clickImage animated:YES];
    }
    else
    {
        YXJHotMoreModel *model5 = self.m_twoArray[indexPath.row];
        YXJClickImage1Controller *clickImage1 = [[YXJClickImage1Controller alloc] init];
        [clickImage1 setHidesBottomBarWhenPushed:YES];
        clickImage1.m_dishesId = model5.m_hotMoreNewId;
        clickImage1.m_headImageString = model5.m_hotMoreNewImage;
        clickImage1.m_title = model5.m_hotMoreNewTitle;
        clickImage1.m_content = model5.m_hotMoreNewContent;
        clickImage1.m_video = model5.m_hotMoreNewVideo;
        [self.navigationController pushViewController:clickImage1 animated:YES];
    }
    

}



- (NSMutableArray *)m_twoArray
{
    if (_m_twoArray == nil)
    {
        _m_twoArray = [NSMutableArray array];
    }
    return _m_twoArray;
}



//(新品)下拉刷新
- (void)newsXiala
{
    m_page = 1;
    [self createTwoTableViewReaquest:m_page];
}


//(新品)上拉加载
- (void)newsShangla
{
    m_page++;
    [self createTwoTableViewReaquest:m_page];
}



//热门更多里面的新品界面请求
- (void)createTwoTableViewReaquest:(NSInteger)page;
{
    NSString *newsUrl = [NSString stringWithFormat:@"http://api.izhangchu.com/?methodName=HomeMore&page=%ld&size=6&type=2&user_id=0",page];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:newsUrl parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        //下拉刷新时清空数组
        if (page == 1) {
            [self.m_twoArray removeAllObjects];
        }
        
        NSDictionary *dic1 = responseObject[@"data"];
        NSArray *arr = dic1[@"data"];
        for (NSDictionary *dic2 in arr) {
            YXJHotMoreModel *model = [[YXJHotMoreModel alloc] init];
            model.m_hotMoreNewImage = dic2[@"image"];
            model.m_hotMoreNewTitle = dic2[@"title"];
            model.m_hotMoreNewDescription = dic2[@"description"];
            model.m_hotMoreNewVideo = dic2[@"video"];
            model.m_hotMoreNewContent = dic2[@"content"];
            model.m_hotMoreNewId = dic2[@"id"];
            [self.m_twoArray addObject:model];
        }
        [self.m_TwoTableView reloadData];
        [self.m_TwoTableView.header endRefreshing];
        [self.m_TwoTableView.footer endRefreshing];
        
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}




#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.m_oneTableView)
    {
            return 200;
    }
    else if (tableView == self.m_TwoTableView)
    {
        return 200;
    }
    return 100;

}




#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.m_oneTableView)
    {
         return self.m_oneArray.count;
    }
   
   else if (tableView == self.m_TwoTableView)
   {
       return self.m_twoArray.count;
   }
    return 1;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.m_oneTableView)
    {
        YXJHotMoreCell *cell = [YXJHotMoreCell cellWithTabelView:tableView];
        if (_m_oneArray != nil)
        {
            YXJHotMoreModel *model = self.m_oneArray[indexPath.row];
            cell.m_hotMoreModel =model;
        }
        cell.delegate = self;
        return cell;
    }
     else if (tableView == self.m_TwoTableView)
    {
        YXJHotMoreNewCell *cell = [YXJHotMoreNewCell cellWithTableView:tableView];
        if (_m_twoArray != nil)
        {
            YXJHotMoreModel *model1 = self.m_twoArray[indexPath.row];
            cell.m_hotNewModel = model1;
        }
        cell.delegate = self;
       return cell;
    }
   
    return nil;
}



//点击热门更多里面的热门播放视频
#pragma mark - YXJHotMoreCellDelegate
- (void)yxjHotMoreCellDidClickVideo:(YXJHotMoreCell *)cell
{
    NSURL *url = [NSURL URLWithString:cell.m_hotMoreModel.m_hotMoreHotVideo];
    MPMoviePlayerViewController *play = [[MPMoviePlayerViewController alloc]initWithContentURL:url];
    [self presentViewController:play animated:YES completion:nil];
}


//点击热门更多里面的新品播放视频
#pragma mark - YXJHotMoreNewCellDelegate
- (void)yxjHotMoreNewCellDidClickPlay:(YXJHotMoreNewCell *)cell
{
    NSURL *url = [NSURL URLWithString:cell.m_hotNewModel.m_hotMoreNewVideo];
    MPMoviePlayerViewController *playVC = [[MPMoviePlayerViewController alloc] initWithContentURL:url];
    [self presentViewController:playVC animated:YES completion:nil];
}

@end
