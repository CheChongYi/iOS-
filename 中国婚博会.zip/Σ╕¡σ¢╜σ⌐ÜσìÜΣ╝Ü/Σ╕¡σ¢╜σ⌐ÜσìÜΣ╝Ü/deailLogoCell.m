//
//  deailLogoCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/12.
//  Copyright © 2015年 a. All rights reserved.
//

#import "deailLogoCell.h"
#import "UIImageView+WebCache.h"
#import "detailModel.h"
@implementation deailLogoCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithdetailModels:(NSArray *)detailModels{
    detailModel *model=detailModels[0];
    [_iconView sd_setImageWithURL:[NSURL URLWithString:model.logo]];
    _titleLabel.text=model.store_name;
}
@end
