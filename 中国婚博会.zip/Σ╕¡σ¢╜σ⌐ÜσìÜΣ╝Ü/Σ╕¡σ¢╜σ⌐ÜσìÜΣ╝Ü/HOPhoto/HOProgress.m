//
//  HOProgress.m
//  HOPhotoView
//
//  Created by Chris on 15/8/6.
//  Copyright (c) 2015年 www.aoyolo.com 艾悠乐iOS学院. All rights reserved.
//

#import "HOProgress.h"

@implementation HOProgress
{
    UIBezierPath *_progressPath;
    float _progress;
    CGRect fm;
}

// Only override drawRect: if you perform custom drawing.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    fm = rect;
    //创建进度条背景
    [[UIColor grayColor]setStroke];
    UIBezierPath *bgPath = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(2, 2, rect.size.width-4, rect.size.height - 4)];
    bgPath.lineWidth = 3;
    [bgPath stroke];
    [self updateProgress:_progress];
    
}

- (void)updateProgress:(float)progress
{
    [[UIColor whiteColor]setStroke];
    //创建显示当前进度的进度条
    _progressPath = [UIBezierPath bezierPathWithArcCenter:CGPointMake(fm.size.width/2, fm.size.height/2) radius:fm.size.width/2-2 startAngle:(-M_PI_2) endAngle:(2*M_PI*progress) clockwise:YES];
    _progressPath.lineWidth = 3;
    [_progressPath stroke];
}

- (void)setProgress:(float)progress
{
    _progress = progress;
    [self setNeedsDisplay];
}

@end
