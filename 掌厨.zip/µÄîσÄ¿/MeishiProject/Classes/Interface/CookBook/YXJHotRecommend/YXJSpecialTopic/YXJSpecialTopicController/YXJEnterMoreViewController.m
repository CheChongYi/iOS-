//
//  YXJEnterMoreViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/24.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJEnterMoreViewController.h"
#import "YXJTwoSpecialViewController.h"
#import "YXJEnterMoreModel.h"
#import "YXJEnterMoreCell.h"
#import "AFNetworking.h"
#import "Header.h"
#import "MJRefresh.h"

@interface YXJEnterMoreViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSInteger m_page;
    UIActivityIndicatorView *_m_activity;
}

@property (nonatomic, strong) UITableView *m_tabelView;
@property (nonatomic, strong) NSMutableArray *m_array;


@end

@implementation YXJEnterMoreViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self createTableView];
    [self moreXiala];
    [self setNavigationItem];

}




//加载数据的时候显示菊花(视图将要出现)
- (void)viewWillAppear:(BOOL)animated
{
    _m_activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    _m_activity.center = CGPointMake(screenWidth/2, screenHeight/2);
    _m_activity.color = [UIColor blackColor];
    [self.view addSubview:_m_activity];
    [_m_activity startAnimating];
}

//视图已经出现,停止菊花效果
- (void)viewDidAppear:(BOOL)animated
{
    [_m_activity stopAnimating];
}




- (void)setNavigationItem
{
    self.title = @"专题列表";
    //取消自带的返回按钮，添加自定义返回按钮
    [self.navigationItem setHidesBackButton:YES];
    UIBarButtonItem *returnBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"returnButton.png"] style:UIBarButtonItemStyleDone target:self action:@selector(popViewController)];
    returnBtn.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = returnBtn;
    //设置导航栏标题的字体大小和颜色
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
}



- (void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)createTableView
{
    self.m_tabelView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    self.m_tabelView.delegate = self;
    self.m_tabelView.dataSource = self;
    //隐藏单元格间隔线
    self.m_tabelView.separatorStyle = NO;
    [self.view addSubview:self.m_tabelView];
    
    MJRefreshGifHeader *moreHeader = [MJRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(moreXiala)];
     NSArray *moreArr1 = @[[UIImage imageNamed:@"refurbish1.png"],[UIImage imageNamed:@"refurbish2.png"]];
    [moreHeader setImages:moreArr1 forState:MJRefreshStateRefreshing];
    self.m_tabelView.header = moreHeader;
    
    MJRefreshAutoGifFooter *moreFooter = [MJRefreshAutoGifFooter footerWithRefreshingTarget:self refreshingAction:@selector(moreShangla)];
    NSArray *moreArr2 = @[[UIImage imageNamed:@"refurbish1.png"],[UIImage imageNamed:@"refurbish2.png"]];
    [moreFooter setImages:moreArr2 forState:MJRefreshStateRefreshing];
    self.m_tabelView.footer = moreFooter;
}



- (NSMutableArray *)m_array
{
    if (_m_array == nil)
    {
        _m_array = [NSMutableArray array];
    }
    return _m_array;
}



- (void)moreXiala
{
    m_page = 1;
    [self createRequest:m_page];
}


- (void)moreShangla
{
    m_page++;
    [self createRequest:m_page];
}

- (void)createRequest:(NSInteger)page;
{
    NSString *url = [NSString stringWithFormat:@"http://api.izhangchu.com/?appVersion=4.0.2&sysVersion=9.1&devModel=iPhone&methodName=TopicList&page=%ld",page];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        if (page == 1) {
            [self.m_array removeAllObjects];
        }
        NSDictionary *dic1 = responseObject[@"data"];
        NSArray *arr1 = dic1[@"data"];
        for (NSDictionary *dic2 in arr1)
        {
            YXJEnterMoreModel *model = [[YXJEnterMoreModel alloc] init];
            model.m_enterMoreTitle = dic2[@"title"];
            model.m_enterMoreDescription = dic2[@"description"];
            model.m_enterMoreImage = dic2[@"image"];
            model.m_enterMoreID = dic2[@"id"];
            [self.m_array addObject:model];
        }
        [self.m_tabelView reloadData];
        [self.m_tabelView.header endRefreshing];
        [self.m_tabelView.footer endRefreshing];
   
        
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
    
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    YXJTwoSpecialViewController *twoVC = [[YXJTwoSpecialViewController alloc] init];
    [self.navigationController pushViewController:twoVC animated:YES];
    YXJEnterMoreModel *model = self.m_array[indexPath.row];
    twoVC.ID = model.m_enterMoreID;
    twoVC.topTitle = model.m_enterMoreTitle;
}




#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 250;
}



#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.m_array.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    YXJEnterMoreCell *cell = [YXJEnterMoreCell cellWithTableView:tableView];
    YXJEnterMoreModel *model = self.m_array[indexPath.row];
    cell.m_moreModel = model;
    return cell;
}


@end
