//
//  MyTabBarController.m
//  MeishiProject
//
//  Created by Yang on 15/11/2.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "MyTabBarController.h"
#import "CookBookViewController.h"
#import "LikeViewController.h"
#import "FoodClassViewController.h"
#import "MeViewController.h"
#import "Header.h"



@interface m_MyTabBarController ()


@end

@implementation m_MyTabBarController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self loadViewController];

}


- (void)loadViewController
{
    //开始界面停留时间
    [NSThread sleepForTimeInterval:1];
    //设置tabBar字体颜色
    [self.tabBar setTintColor:RGBColor(255, 122, 68)];
    
    CookBookViewController *cookVC = [[CookBookViewController alloc]init];
    UINavigationController *Nav1 = [[UINavigationController alloc]initWithRootViewController:cookVC];
    Nav1.tabBarItem.title = @"食谱";
    Nav1.tabBarItem.image = [[UIImage imageNamed:@"CookBookA"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    Nav1.tabBarItem.imageInsets = UIEdgeInsetsMake(2, 0, 0, 0);
    //设置图标有颜色
    Nav1.tabBarItem.selectedImage = [[UIImage imageNamed:@"CookBookA-1"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    [self addChildViewController:Nav1];
    
    LikeViewController *likeVC = [[LikeViewController alloc]init];
    UINavigationController *Nav2 = [[UINavigationController alloc]initWithRootViewController:likeVC];
    likeVC.title = @"喜欢";
    Nav2.tabBarItem.image = [[UIImage imageNamed:@"LikeA"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    Nav2.tabBarItem.selectedImage = [[UIImage imageNamed:@"LikeB"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    Nav2.tabBarItem.imageInsets = UIEdgeInsetsMake(2, 0, 0, 0);
    [self addChildViewController:Nav2];
    
    FoodClassViewController *foodClassVC = [[FoodClassViewController alloc]init];
    UINavigationController *Nav3 = [[UINavigationController alloc]initWithRootViewController:foodClassVC];
    foodClassVC.title = @"食课";
    Nav3.tabBarItem.image = [[UIImage imageNamed:@"FoodClassA"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    Nav3.tabBarItem.selectedImage = [[UIImage imageNamed:@"FoodClassB"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    Nav3.tabBarItem.imageInsets = UIEdgeInsetsMake(2, 0, 0, 0);
    [self addChildViewController:Nav3];
    
    MeViewController *meVC = [[MeViewController alloc]init];
    UINavigationController *Nav4 = [[UINavigationController alloc]initWithRootViewController:meVC];
    meVC.title = @"我的";
    Nav4.tabBarItem.image = [[UIImage imageNamed:@"MeA"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    Nav4.tabBarItem.selectedImage = [[UIImage imageNamed:@"MeB"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    Nav4.tabBarItem.imageInsets = UIEdgeInsetsMake(2, 0, 0, 0);
    [self addChildViewController:Nav4];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
