//
//  hunlixingshiCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import "hunlixingshiCell.h"
#import "hunlixingshiModel.h"
#import "UIImageView+WebCache.h"
@implementation hunlixingshiCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithhunlixingshiModels:(NSArray *)hunlixingshiModels{
    for (int i=0; i<3; i++) {
        UILabel *titleLable=(UILabel *)[self viewWithTag:10+i];
        UILabel *ideacLable=(UILabel *)[self viewWithTag:20+i];
        UIImageView *imageView=(UIImageView *)[self viewWithTag:30+i];
        hunlixingshiModel *model=hunlixingshiModels[i];
        titleLable.text=model.title;
        ideacLable.text=model.idesc;
        [imageView sd_setImageWithURL:[NSURL URLWithString:model.img_url]];
    }
}
@end
