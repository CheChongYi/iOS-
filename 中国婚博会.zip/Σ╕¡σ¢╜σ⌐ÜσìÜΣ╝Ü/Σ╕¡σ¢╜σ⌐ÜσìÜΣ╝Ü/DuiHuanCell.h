//
//  DuiHuanCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/11.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DuiHuanCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *gift_name;
@property (weak, nonatomic) IBOutlet UILabel *total_num;
@property (weak, nonatomic) IBOutlet UILabel *left_num;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

-(void)configCellWithDuiHuanModels:(NSArray *)DuiHuanModels cellForRowAtIndexPath:(NSIndexPath *)indexPath;

@end
