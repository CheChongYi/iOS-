//
//  enterSearchModel.h
//  MeishiProject
//
//  Created by Yang on 15/12/10.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface enterSearchModel : NSObject


@property (nonatomic, copy) NSString *m_image;

@property (nonatomic, copy) NSString *m_video;

@property (nonatomic, copy) NSString *m_video1;

@property (nonatomic, copy) NSString *m_dishes_id;

@property (nonatomic, copy) NSString *m_title;

@property (nonatomic, copy) NSString *m_description;

@property (nonatomic, copy) NSString *m_hard_level;

@property (nonatomic, copy) NSString *m_taste;

@property (nonatomic, copy) NSString *m_cookie;

@end
