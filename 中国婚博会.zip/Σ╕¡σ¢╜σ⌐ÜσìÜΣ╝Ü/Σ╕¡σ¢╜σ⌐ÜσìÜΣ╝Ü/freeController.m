//
//  freeController.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import "freeController.h"
#import "freeManager.h"
#import "freeModel.h"

#import "freeCell.h"
@interface freeController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation freeController{
    NSArray *heights;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    self.navigationItem.title=@"活动详情";
    
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],UITextAttributeTextColor, nil]];
    
    UIBarButtonItem *leftItem=[[UIBarButtonItem alloc]initWithTitle:@"< " style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    leftItem.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=leftItem;
    [[freeManager shareInstance]loadInternetData];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(notify:) name:freeManagerRefreshNotify object:nil];
    heights=@[@(1500)];
    [self registerCell];
}
-(void)registerCell{
    [self.tableView registerNib:[UINib nibWithNibName:@"freeCell" bundle:nil] forCellReuseIdentifier:@"freeCell"];
}
- (void)notify:(NSNotification *)note
{
    NSInteger section = [note.object integerValue];
    if (section==0) {
     [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationAutomatic];   
    }
}

-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    freeCell *cell=[tableView dequeueReusableCellWithIdentifier:@"freeCell"];
    [cell configCellWithfreeModels:[freeManager shareInstance].freeModels];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [heights[indexPath.section]doubleValue];
}
@end
