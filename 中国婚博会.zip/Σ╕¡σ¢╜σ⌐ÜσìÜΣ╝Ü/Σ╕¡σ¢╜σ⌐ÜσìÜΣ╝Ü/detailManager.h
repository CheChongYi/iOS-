//
//  detailManager.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/12.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>
extern NSString *detailManagerRefreshNotify;
@interface detailManager : NSObject
@property(nonatomic,strong)NSMutableArray *detailModels;

+(instancetype)shareInstance;
- (void)loadInternetData;
@end
