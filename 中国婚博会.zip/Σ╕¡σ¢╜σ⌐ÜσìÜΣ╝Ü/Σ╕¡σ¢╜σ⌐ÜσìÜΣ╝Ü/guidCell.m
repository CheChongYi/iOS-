//
//  guidCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/30.
//  Copyright © 2015年 a. All rights reserved.
//

#import "guidCell.h"
#import "guidModel.h"
#import "UIImageView+WebCache.h"
@implementation guidCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithguidModels:(NSArray *)guidModels cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    for (int i=0;i<2; i++) {
        guidModel *model=guidModels[indexPath.row];
        _titleLabel.text=model.article_title;
    }
}
@end
