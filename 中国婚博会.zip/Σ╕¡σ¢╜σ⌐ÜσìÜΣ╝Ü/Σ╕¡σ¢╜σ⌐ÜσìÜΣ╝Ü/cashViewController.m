//
//  cashViewController.m
//  中国婚博会
//
//  Created by Admin on 15/11/5.
//  Copyright © 2015年 a. All rights reserved.
//

#import "cashViewController.h"
#import "MJRefresh.h"
#import "CashManager.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "MBProgressHUD.h"
#import "MingRenController.h"

#import "Ad2Cell.h"
#import "storeModel.h"
#import "hotelModel.h"
@interface cashViewController ()<UITableViewDataSource,UITableViewDelegate,MBProgressHUDDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)NSMutableArray *datas;
@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)UIPageControl *pageCtl;
@end

@implementation cashViewController{
    BOOL Tend;
    MBProgressHUD *HUD;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSArray *testArray;
   testArray = @[ @[ @"全部分类", @"全部", @"订喜宴", @"拍婚照", @"找婚庆" , @"定婚戒" , @"选婚纱",@"淘婚品",@"度蜜月",@"装新房" ], @[@"默认", @"附近",@"默认",@"最新"]];
    
    MXPullDownMenu *menu = [[MXPullDownMenu alloc] initWithArray:testArray selectedColor:[UIColor greenColor]];
    menu.delegate = self;
    menu.frame = CGRectMake(0, 60, menu.frame.size.width+200, menu.frame.size.height);
    [self.view addSubview:menu];

    [self creatHUD];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    
    self.navigationItem.title=@"现金券";
    
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],UITextAttributeTextColor, nil]];
   
    [self DropdownRefresh];
    [[CashManager shareInstance]loadInternetData];
    MJRefreshGifHeader *header=[MJRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(DropdownRefresh)];
    NSArray *images=@[[UIImage imageNamed:@"pullto_center_icon"]];
    
    [header setImages:images forState:MJRefreshStateRefreshing];
    
    self.tableView.header=header;
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(notify:) name:CashManagerRefreshNotify object:nil];
    [self registerCell];
}
- (void)DropdownRefresh
{
    [HUD show:YES];
    [self.tableView reloadData];
    [self.tableView.header endRefreshing];
    [HUD hide:YES];
}
- (void)notify:(NSNotification *)note
{
    NSInteger section = [note.object integerValue];
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.tableView.header endRefreshing];
}

-(void)registerCell{
    [self.tableView registerNib:[UINib nibWithNibName:@"Ad2Cell" bundle:nil] forCellReuseIdentifier:@"Ad2Cell"];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==0) {
        return 0;
    }
    return 20;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    Ad2Cell *cell=[tableView dequeueReusableCellWithIdentifier:@"Ad2Cell"];
    if ([CashManager shareInstance].Ad2Models.count!=0) {
        cell.hidden=NO;
        [cell configCellWithAd2Models:[CashManager shareInstance].Ad2Models cellForRowAtIndexPath:indexPath];
    }
    else{
        cell.hidden=YES;
    }
    return cell;

}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
        return 120;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    MingRenController *mingrenCtl=[[MingRenController alloc]init];
    [mingrenCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:mingrenCtl animated:YES];
}
- (void)creatHUD
{
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    HUD.labelText = @"正在加载中...";
    HUD.dimBackground = YES;
    HUD.delegate = self;
}
- (void)PullDownMenu:(MXPullDownMenu *)pullDownMenu didSelectRowAtColumn:(NSInteger)column row:(NSInteger)row
{
    NSLog(@"%ld -- %ld", (long)column, (long)row);
}

@end
