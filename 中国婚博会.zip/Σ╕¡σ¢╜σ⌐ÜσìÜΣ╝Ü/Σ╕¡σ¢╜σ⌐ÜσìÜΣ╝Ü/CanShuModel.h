//
//  CanShuModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/5.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CanShuModel : NSObject
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *name;
@property(nonatomic,strong)NSString *value;
@end
