//
//  YXJClickImage1Cell.h
//  MeishiProject
//
//  Created by Yang on 15/11/27.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface YXJClickImage1Cell : UITableViewCell
/**
 *
 scrollView滑动范围方法
 */
- (void)setScrollViewX:(CGFloat)x;

@property (nonatomic, strong) NSMutableArray *m_practiceArray;

@property (nonatomic, strong) NSMutableArray *m_1materialArray;

@property (nonatomic, strong) NSMutableArray *m_1commonSenseArray;

@property (nonatomic, strong) NSMutableArray *m_1xiangKeArray;

@property (nonatomic, strong) NSMutableArray *m_footArr;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, assign) NSInteger m_caiMingCount;

+ (instancetype)yxjClickImage1Cell:(UITableView *)tableView;


@property (nonatomic, strong) UIView *m_slideView1;


@end
