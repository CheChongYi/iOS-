//
//  YXJEnterFoodClassView.m
//  MeishiProject
//
//  Created by Yang on 15/12/5.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJEnterFoodClassView.h"
#import "enterFoodClassModel.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"


@interface YXJEnterFoodClassView ()


@property (weak, nonatomic) IBOutlet UIButton *firstBtn;

@property (nonatomic, strong) UIButton *selectBtn;

@property (nonatomic, assign) NSInteger m_tag;


@end

@implementation YXJEnterFoodClassView


- (void)awakeFromNib
{
    _selectBtn = _firstBtn;
    [self click:_selectBtn];
}


+ (instancetype)enterFoodClassView
{
    return [[[NSBundle mainBundle] loadNibNamed:@"YXJEnterFoodClassView" owner:self options:nil]firstObject];
}




- (void)setM_arr:(NSMutableArray *)m_arr
{
    _m_arr = m_arr;
    for (int i = 0; i<_m_arr.count; i++) {
        enterFoodClassModel *mod = _m_arr[0];
        self.topTitleLabel.text = mod.m_topSeries_title;
        self.topDiscLabel.text = mod.m_topDisc;
        [self.headImage sd_setImageWithURL:[NSURL URLWithString:mod.m_topImage]];
    }
}


///点击（1~~~8）按钮
- (IBAction)click:(UIButton *)sender
{
    [_selectBtn setBackgroundColor:[UIColor lightGrayColor]];
    [sender setBackgroundColor:[UIColor orangeColor]];
    _selectBtn = sender;
    
    enterFoodClassModel *model = self.m_arr[sender.tag];
    self.topTitleLabel.text = model.m_topSeries_title;
    self.topDiscLabel.text = model.m_topDisc;
    [self.headImage sd_setImageWithURL:[NSURL URLWithString:model.m_topImage]];
    
    self.m_tag = sender.tag;


}


- (IBAction)playVideo:(id)sender
{
    
    if ([self.delegate respondsToSelector:@selector(yxjEnterFoodClassViewDidClickPlay:)])
    {
        [self.delegate yxjEnterFoodClassViewDidClickPlay:self.m_tag];
    }
    
}


@end
