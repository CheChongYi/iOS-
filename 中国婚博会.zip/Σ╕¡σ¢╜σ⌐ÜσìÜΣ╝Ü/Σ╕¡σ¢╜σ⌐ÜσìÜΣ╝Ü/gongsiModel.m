//
//  gongsiModel.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import "gongsiModel.h"

@implementation gongsiModel

@end
