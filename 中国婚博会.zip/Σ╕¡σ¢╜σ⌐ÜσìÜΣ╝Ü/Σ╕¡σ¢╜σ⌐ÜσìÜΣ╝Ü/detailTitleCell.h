//
//  detailTitleCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/12.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface detailTitleCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
-(void)configCellWithdetailModels:(NSArray *)detailModels;
@end
