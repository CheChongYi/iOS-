//
//  AdController.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/5.
//  Copyright © 2015年 a. All rights reserved.
//

#import "AdController.h"
#import "HomeViewController.h"
#import "MyTabbarController.h"
@interface AdController ()<UIScrollViewDelegate>
@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)UIPageControl *pageControl;
@end

@implementation AdController

- (void)viewDidLoad {
    [super viewDidLoad];
    _scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    _scrollView.contentSize=CGSizeMake(4*ScreenWidth,ScreenHeight);
    _scrollView.pagingEnabled=YES;
    _scrollView.bounces=NO;
    _scrollView.showsHorizontalScrollIndicator=NO;
    _scrollView.showsVerticalScrollIndicator=NO;
    _scrollView.delegate=self;
    
    for (int i=0; i<4; i++) {
        UIImageView *imageView=[[UIImageView alloc]initWithFrame:CGRectMake(i*ScreenWidth, 0, ScreenWidth, ScreenHeight)];
        imageView.image=[UIImage imageNamed:[NSString stringWithFormat:@"lead_icon_%d",i+1]];
        NSLog(@"====lead_icon_%d=====",i);
        [_scrollView addSubview:imageView];
        
        UIButton *button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.frame=CGRectMake(ScreenWidth*3+140, 600, 100, 50);
        button.layer.borderWidth=1;
        button.layer.cornerRadius=10;
        button.layer.borderColor=[UIColor redColor].CGColor;
        [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(info) forControlEvents:UIControlEventTouchUpInside];
        [button setTitle:@"欢迎体验" forState:UIControlStateNormal];
        [_scrollView addSubview:button];
        
        _pageControl=[[UIPageControl alloc]initWithFrame:CGRectMake(0, ScreenHeight-40, ScreenWidth, 40)];
        _pageControl.numberOfPages=4;
        _pageControl.currentPageIndicatorTintColor=RGBColor(237, 103, 97);
        _pageControl.pageIndicatorTintColor=[UIColor grayColor];
        [_pageControl addTarget:self action:@selector(pageTurn:) forControlEvents:UIControlEventValueChanged];
        [self.view addSubview:_scrollView];
        [self.view addSubview:_pageControl];
    }
}
-(void)info{
    MyTabbarController *tabbar=[[MyTabbarController alloc]init];
    [self presentViewController:tabbar animated:YES completion:nil];
}
-(void)pageTurn:(UIPageControl *)sender{
    NSInteger pageNum=_pageControl.currentPage;
    CGSize viewSize=_scrollView.frame.size;
    [_scrollView setContentOffset:CGPointMake((pageNum)*viewSize.width, 0)];
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    int currentPage=floor((self.scrollView.contentOffset.x-ScreenWidth/2)/ScreenWidth+1);
    NSLog(@"scrollview的当前页面数==%d",currentPage);
    if (currentPage==0) {
        [_scrollView scrollRectToVisible:CGRectMake(ScreenWidth*4, 0, ScreenWidth, ScreenHeight) animated:YES];
        _pageControl.currentPage=0;
        return;
    }else if (currentPage==5){
        [_scrollView scrollRectToVisible:CGRectMake(ScreenWidth, 0, ScreenWidth, ScreenHeight) animated:YES];
        _pageControl.currentPage=0;
        return;
    }
    _pageControl.currentPage=currentPage;
     NSLog(@"当前-pageControl currentPage==%ld",(long)self.pageControl.currentPage);
}
@end
