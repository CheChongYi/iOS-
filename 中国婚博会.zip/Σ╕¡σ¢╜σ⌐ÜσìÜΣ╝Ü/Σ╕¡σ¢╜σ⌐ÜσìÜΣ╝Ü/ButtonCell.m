//
//  ButtonCell.m
//  中国婚博会
//
//  Created by Admin on 15/11/6.
//  Copyright © 2015年 a. All rights reserved.
//

#import "ButtonCell.h"
#import "buttonModel.h"
#import "UIImageView+WebCache.h"
@implementation ButtonCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)configCellWithbuttonModels:(NSArray *)buttonModels{
    for (int i=0; i<8; i++) {
        UIImageView *imageView=(UIImageView *)[self viewWithTag:10+i];
        UILabel *label=(UILabel *)[self viewWithTag:20+i];
        buttonModel *model=buttonModels[i];
        label.text=model.title;
        [imageView sd_setImageWithURL:[NSURL URLWithString:model.imgUrl]];
    }
}
@end
