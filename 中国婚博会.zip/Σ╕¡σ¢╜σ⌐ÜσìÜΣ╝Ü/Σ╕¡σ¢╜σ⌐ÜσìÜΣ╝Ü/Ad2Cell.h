//
//  Ad2Cell.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Ad2Cell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *totalLabel;
@property (weak, nonatomic) IBOutlet UILabel *applyLabel;
- (void)configCellWithAd2Models:(NSArray *)Ad2Models cellForRowAtIndexPath:(NSIndexPath *)indexPath;
@end
