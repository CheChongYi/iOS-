//
//  fitManager.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/2.
//  Copyright © 2015年 a. All rights reserved.
//

#import "fitManager.h"
#import "AFNetworking.h"
#import "fitADModel.h"
#import "shangpinNameModel.h"
#import "actModel.h"
NSString *fitManagerRefreshNotify = @"fitManagerRefreshNotify";
static fitManager *manager=nil;
@implementation fitManager
+(instancetype)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager=[[[self class]alloc]init];
        }
    });
    return manager;
}
-(void)loadInternetData{
    [self loadfitADData];
    [self loadshangpinNameData];
    [self loadactData];
}
-(void)loadfitADData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:fitUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"banner"];
        for (NSDictionary *dic in array) {
            fitADModel *model=[[fitADModel alloc]init];
            model.imgurl=dic[@"img_url"];
            if (!_fitADModels) {
                _fitADModels=[NSMutableArray array];
            }
            [self.fitADModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:fitManagerRefreshNotify object:@(10)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
        [alertView show];
        [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
    }];
}
-(void)loadshangpinNameData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:fitUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"shangpinleibie"];
        for (NSDictionary *dic in array) {
            shangpinNameModel *model=[[shangpinNameModel alloc]init];
            model.title=dic[@"title"];
            model.img_url=dic[@"img_url"];
            if (!_shangpinNameModels) {
                _shangpinNameModels=[NSMutableArray array];
            }
            [self.shangpinNameModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:fitManagerRefreshNotify object:@(1)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadactData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:fitUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"act"];
        for (NSDictionary *dic in array) {
            actModel *model=[[actModel alloc]init];
            model.img_url=dic[@"img_url"];
            if (!_actModels) {
                _actModels=[NSMutableArray array];
            }
            [self.actModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:fitManagerRefreshNotify object:@(3)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)     {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
