//
//  YXJClickImage1Model.h
//  MeishiProject
//
//  Created by Yang on 15/11/26.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YXJClickImage1Model : NSObject
/**
 *  点击热门第一张图片进入之后(做法)界面模型
 */
@property (nonatomic, copy) NSString *m_practiceNumber;

@property (nonatomic, copy) NSString *m_practiceDesc;

@property (nonatomic, copy) NSString *m_practiceImage;

@property (nonatomic, copy) NSString *m_cooking_time;

/**
 *  点击热门第一张图片进入之后(食材)界面模型
 */
@property (nonatomic, copy) NSString *m_material_image;

@property (nonatomic, copy) NSString *m_material_name;

@property (nonatomic, copy) NSString *m_material_weight;

@property (nonatomic, copy) NSString *m_footTitle;

@property (nonatomic, copy) NSString *m_footImage;

/**
 *  点击热门第一张图片进入之后(相关常识)界面模型
 */
@property (nonatomic, copy) NSString *m_commonSenseTitle;

@property (nonatomic, copy) NSString *m_commonSenseDisc;

@property (nonatomic, copy) NSString *m_commonSenseImage;

/**
 *  点击热门第一张图片进入之后(相宜相克)界面模型
 */
@property (nonatomic, copy) NSString *m_xiangkeHeaderImage;

@property (nonatomic, copy) NSString *m_xiangKeMainName;

@property (nonatomic, copy) NSString *m_xiangKeImage1;

@property (nonatomic, copy) NSString *m_xiangKeName1;

@property (nonatomic, copy) NSString *m_xiangKeDesc1;



@end
