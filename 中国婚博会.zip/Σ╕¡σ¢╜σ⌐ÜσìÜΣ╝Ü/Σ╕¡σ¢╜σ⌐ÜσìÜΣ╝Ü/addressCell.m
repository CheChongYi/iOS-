//
//  addressCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/7.
//  Copyright © 2015年 a. All rights reserved.
//

#import "addressCell.h"
#import "ShangJiaModel.h"

@implementation addressCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithaddressModels:(NSArray *)addressModels{
    ShangJiaModel *model=addressModels[0];
    _addresLabel.text=model.address;
    _distanceLabel.text=[NSString stringWithFormat:@"距离:%@>>",model.distance];
}
@end
