//
//  boundViewController.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/19.
//  Copyright © 2015年 a. All rights reserved.
//

#import "boundViewController.h"
#import "noticeViewController.h"
#import "personalViewController.h"
#import "KxMenu.h"
@interface boundViewController ()
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;
@property (weak, nonatomic) IBOutlet UIButton *button;

@end

@implementation boundViewController{
    UIButton *_btn1;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    UIView *smallView=[[UIView alloc]initWithFrame:CGRectMake(0,0,ScreenWidth, 50)];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(110,0, 100,50)];
    label.text=@"绑定";
    label.textColor=[UIColor whiteColor];
    [smallView addSubview:label];
    
    UIBarButtonItem *leftBtn=[[UIBarButtonItem alloc]initWithTitle:@"<" style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    leftBtn.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=leftBtn;
    
    _btn1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _btn1.frame = CGRectMake(280,15, 30, 20);
    [_btn1 setImage:[UIImage imageNamed:@"home_enum_icon2"] forState:UIControlStateNormal];
    _btn1.tintColor=[UIColor whiteColor];
    [_btn1 addTarget:self action:@selector(showMenu:) forControlEvents:UIControlEventTouchUpInside];
    [smallView addSubview:_btn1];
    [self.navigationItem.titleView sizeToFit];
    self.navigationItem.titleView=smallView;
}
-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void) viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    _btn1.frame = CGRectMake(280, 15, 30, 20);
}
- (void)showMenu:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      
      [KxMenuItem menuItem:@"首页"
                     image:[UIImage imageNamed:@"home_normal_icon"]
                    target:self
                    action:@selector(pushMenuItem:)],
      
      [KxMenuItem menuItem:@"我的通信"
                     image:[UIImage imageNamed:@"my_notice_icon"]
                    target:self
                    action:@selector(pushMenuItem2:)],
      
      [KxMenuItem menuItem:@"我的私信"
                     image:[UIImage imageNamed:@"my_personal_letter_icon"]
                    target:self
                    action:@selector(pushMenuItem3:)],
      ];
    
    KxMenuItem *first = menuItems[0];
    first.foreColor = [UIColor colorWithRed:47/255.0f green:112/255.0f blue:225/255.0f alpha:1.0];
    first.alignment = NSTextAlignmentCenter;
    
    [KxMenu showMenuInView:self.view
                  fromRect:sender.frame
                 menuItems:menuItems];
}
- (void) pushMenuItem:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void) pushMenuItem2:(id)sender
{
    noticeViewController *noCtl=[[noticeViewController alloc]init];
    [self.navigationController pushViewController:noCtl animated:YES];
}
- (void) pushMenuItem3:(id)sender
{
    personalViewController *personalCtl=[[personalViewController alloc]init];
    [self.navigationController pushViewController:personalCtl animated:YES];
}
- (IBAction)boundBtn {
    [_button setTitle:@"绑定手机" forState:UIControlStateNormal];
    UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"您已解除手机绑定" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
    [alertView show];
        _titleLabel=(UILabel *)[self.view viewWithTag:10];
        _titleLabel.text=@"您未绑定手机号码";
        
        _numberLabel=(UILabel *)[self.view viewWithTag:11];
        _numberLabel.text=nil;
}
@end
