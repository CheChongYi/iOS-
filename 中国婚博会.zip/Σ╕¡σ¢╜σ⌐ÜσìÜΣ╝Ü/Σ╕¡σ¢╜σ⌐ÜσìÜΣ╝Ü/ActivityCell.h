//
//  ActivityCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/7.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActivityCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (weak, nonatomic) IBOutlet UIImageView *logoView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *mainLabel;
-(void)configCellWithActivityModels:(NSArray *)ActivityModels cellForRowAtIndexPath:(NSIndexPath *)indexPath;
@end
