//
//  FoodClassCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/9.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "FoodClassCell.h"
#import "FoodClassViewController.h"
#import "UIImageView+WebCache.h"
#import "FoodClassModel.h"

@interface FoodClassCell ()

@property (weak, nonatomic) IBOutlet UIImageView *foodClassImage;
@property (weak, nonatomic) IBOutlet UILabel *tagLabel;
@property (weak, nonatomic) IBOutlet UILabel *series_nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *playLabel;


@end

@implementation FoodClassCell


//标签的字体颜色
- (void)layoutSubviews
{
    switch (self.idx)
    {
        case 0:
            _tagLabel.backgroundColor = [UIColor redColor];
            break;
        case 1:
            _tagLabel.backgroundColor = [UIColor orangeColor];
            break;
        case 2:
            _tagLabel.backgroundColor = [UIColor purpleColor];
            break;
        case 3:
            _tagLabel.backgroundColor = [UIColor blueColor];
            _tagLabel.alpha = 0.8;
            break;
            
        default:
            _tagLabel.backgroundColor = [UIColor orangeColor];
            break;
    }
}



+ (instancetype)cellWithTabelView: (UITableView *)tabelView
{
    static NSString *ID = @"ce";
    FoodClassCell *cell = [tabelView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"FoodClassCell" owner:nil options:nil]firstObject];
    }
    return cell;
}



- (void)setFoodClassModel:(FoodClassModel *)foodClassModel
{
    _foodClassModel = foodClassModel;
    self.tagLabel.text = foodClassModel.tag;
    self.series_nameLabel.text =foodClassModel.series_name;
    self.playLabel.text = [NSString stringWithFormat:@"%@人做过",foodClassModel.play];
    [self.foodClassImage sd_setImageWithURL:[NSURL URLWithString:_foodClassModel.image]]
    ;
    
}



@end
