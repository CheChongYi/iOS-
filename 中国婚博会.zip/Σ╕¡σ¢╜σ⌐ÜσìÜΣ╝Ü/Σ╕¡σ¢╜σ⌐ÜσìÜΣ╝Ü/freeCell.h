//
//  freeCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface freeCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIWebView *webView1;
@property (weak, nonatomic) IBOutlet UIImageView *imageView1;
@property (weak, nonatomic) IBOutlet UIWebView *webView2;
@property (weak, nonatomic) IBOutlet UIImageView *imageView2;
@property (weak, nonatomic) IBOutlet UIImageView *imageView3;
@property (weak, nonatomic) IBOutlet UIWebView *webView;
-(void)configCellWithfreeModels:(NSArray *)freeModels;
@end
