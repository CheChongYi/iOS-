//
//  DownViewController.h
//  中国婚博会
//
//  Created by Admin on 15/11/18.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DownViewController : UIViewController
- (void)configCellWithrecommendWEBModels:(NSArray *)recommendWEBModels;
@end
