//
//  bendipaisheCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/29.
//  Copyright © 2015年 a. All rights reserved.
//

#import "bendipaisheCell.h"
#import "bendipaisheModel.h"
#import "UIImageView+WebCache.h"

@implementation bendipaisheCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithbendipaisheModels:(NSArray *)bendipaisheModels{
    for (int i=0; i<6; i++) {
        UILabel *titleLabel=(UILabel *)[self viewWithTag:10+i];
        UILabel *idescLabel=(UILabel *)[self viewWithTag:20+i];
        UIImageView *iconView=(UIImageView *)[self viewWithTag:30+i];
        bendipaisheModel *model=bendipaisheModels[i];
        titleLabel.text=model.title;
        idescLabel.text=model.idesc;
        [iconView sd_setImageWithURL:[NSURL URLWithString:model.img_url]];
    }
}
@end
