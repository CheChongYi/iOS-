//
//  enterSearchModel.m
//  MeishiProject
//
//  Created by Yang on 15/12/10.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "enterSearchModel.h"

@implementation enterSearchModel

@end
