//
//  getCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/29.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface getCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
-(void)configCellWithgetModels:(NSArray *)getModels;
@end
