//
//  InfoManager.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/10.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>
extern NSString *InfoManagerRefreshNotify;

@interface InfoManager : NSObject
@property(nonatomic,strong)NSMutableArray *AboutBuyModels;
@property(nonatomic,strong)NSMutableArray *GuizeModels;
@property(nonatomic,strong)NSMutableArray *recommendModels;
@property(nonatomic,strong)NSMutableArray *WeChatModels;
@property(nonatomic,strong)NSMutableArray *welfareModels;
@property(nonatomic,strong)NSMutableArray *getTicketModels;
@property(nonatomic,strong)NSMutableArray *presentModels;
@property(nonatomic,strong)NSMutableArray *shareModels;
@property(nonatomic,strong)NSMutableArray *imgandNameModels;
@property(nonatomic,strong)NSMutableArray *DuiHuanModels;

+(instancetype)shareInstance;
-(void)loadInternetData;
@end
