//
//  HOPhotoView.m
//  HOPhotoView
//
//  Created by Chris on 15/8/6.
//  Copyright (c) 2015年 www.aoyolo.com 艾悠乐iOS学院. All rights reserved.
//

#import "HOPhotoView.h"
#import "HOProgress.h"
#import "UIImageView+WebCache.h"

#define WIDTH [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height

@implementation HOPhotoView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithFrame:(CGRect)frame photoArray:(NSArray *)photos index:(NSInteger)index
{
    self = [super initWithFrame:frame];
    if (self) {
        self.delegate = self;
        self.pagingEnabled = YES;
        self.contentSize = CGSizeMake(WIDTH * photos.count, HEIGHT);
        self.backgroundColor = [UIColor blackColor];
        [self initPhotos:photos];
        [self scrollRectToVisible:CGRectMake(WIDTH * index, 0, WIDTH, HEIGHT) animated:YES];
    }
    return self;
}

- (void)initPhotos:(NSArray *)photosArray
{
    for (int i = 0; i < photosArray.count; i++) {
        UIScrollView *imgScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(WIDTH * i, 0, WIDTH, HEIGHT)];
        imgScrollView.delegate = self;
        imgScrollView.minimumZoomScale = 1;
        imgScrollView.maximumZoomScale = 3;
        
        UIImageView *photoImg = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT)];
        photoImg.contentMode = UIViewContentModeScaleAspectFit;
        
        //创建一个进度条
        HOProgress *hoProgress = [[HOProgress alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
        hoProgress.backgroundColor = [UIColor clearColor];
        hoProgress.center = photoImg.center;
        [photoImg addSubview:hoProgress];
        
        [photoImg sd_setImageWithURL:[NSURL URLWithString:photosArray[i]] placeholderImage:nil options:SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
            float progress = receivedSize*1.0 / expectedSize;
            [hoProgress setProgress:progress];
        } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            photoImg.image = image;
            [hoProgress removeFromSuperview];
        }];
        
        [imgScrollView addSubview:photoImg];
        
        [self addSubview:imgScrollView];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSInteger pageno = (NSInteger)scrollView.contentOffset.x / WIDTH;
    if (_changedIndex) {
        _changedIndex(pageno);
    }
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return scrollView.subviews[0];
}

@end
