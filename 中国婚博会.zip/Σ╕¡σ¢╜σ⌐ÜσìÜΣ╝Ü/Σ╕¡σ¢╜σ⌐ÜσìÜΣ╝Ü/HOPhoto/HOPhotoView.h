//
//  HOPhotoView.h
//  HOPhotoView
//
//  Created by Chris on 15/8/6.
//  Copyright (c) 2015年 www.aoyolo.com 艾悠乐iOS学院. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^CINDEX)(NSInteger index);

@interface HOPhotoView : UIScrollView<UIScrollViewDelegate>

@property (nonatomic, copy) CINDEX changedIndex;
- (instancetype)initWithFrame:(CGRect)frame photoArray:(NSArray *)photos index:(NSInteger)index;

@end
