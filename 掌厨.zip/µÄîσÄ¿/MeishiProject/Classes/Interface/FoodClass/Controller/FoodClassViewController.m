//
//  FoodClassViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/2.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "FoodClassViewController.h"
#import "YXJCollectionViewCell.h"
#import "DsjLineLayout.h"
#import "enterFoodClassViewController.h"
#import "Header.h"
#import "AFNetworking.h"
#import "FoodClassModel.h"
#import "FoodClassCell.h"
#import "UIImageView+WebCache.h"
#import "YXJEnterFoodClassView.h"
#import "MBProgressHUD.h"




@interface FoodClassViewController ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
{
     UIScrollView *_m_scrollView;
     UIPageControl *_m_pageControl;
     NSTimer *_m_timer;
}
@property (nonatomic, strong) UITableView *m_tabelView;
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray *m_foodClassArray1;
@property (nonatomic, strong) NSMutableArray *m_foodClassArray2;
@property (nonatomic, strong) MBProgressHUD *progressHUD;


@end

@implementation FoodClassViewController

// static(防止其他文件访问) const是一个常量(防止别人修改) ce是在自定义cell的xib文件里面标示符Identifier的名字
static NSString *const ID = @"ce";




- (void)createHUD
{
    self.progressHUD = [[MBProgressHUD alloc] init];
    [self.navigationController.view addSubview:self.progressHUD];
    self.progressHUD.labelText = @"小优正在努力中...";
    self.progressHUD.dimBackground = YES;
    
    [self.progressHUD show:YES];
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self createHUD];
    [self createTabelView];
    [self createCollectionView];
    [self createFoodClassReaquest];
    //设置导航栏颜色
    [self.navigationController.navigationBar setBarTintColor:RGBColor(255, 122, 68)];
    //设置导航栏标题的字体大小和颜色
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
}




- (void)createTabelView
{
    if (self.m_tabelView == nil)
    {
        self.m_tabelView = [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
        self.m_tabelView.delegate = self;
        self.m_tabelView.dataSource = self;
        self.m_tabelView.separatorStyle = NO;
        [self.view addSubview:self.m_tabelView];
    }
}




- (void)createCollectionView
{
    self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 160) collectionViewLayout:[[DsjLineLayout alloc] init]];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    //隐藏滑动条
    self.collectionView.showsHorizontalScrollIndicator = NO;
    [self.collectionView registerNib:[UINib nibWithNibName:@"YXJCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:ID];
    self.m_tabelView.tableHeaderView = self.collectionView;
}



- (NSMutableArray *)m_foodClassArray1
{
    if (_m_foodClassArray1 == nil)
    {
        _m_foodClassArray1 = [NSMutableArray array];
    }
    return _m_foodClassArray1;
}



- (NSMutableArray *)m_foodClassArray2
{
    if (_m_foodClassArray2 == nil)
    {
        _m_foodClassArray2 = [NSMutableArray array];
    }
    return _m_foodClassArray2;
}



- (void)createFoodClassReaquest
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:FoodClassUrl parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSData *data = [NSData dataWithData:responseObject];
        NSDictionary *dic1 = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSDictionary *dic2 = dic1[@"data"];
        NSArray *Arr = dic2[@"top"];
        for (NSDictionary *Dic in Arr)
        {
            FoodClassModel *foodClassModel1 = [[FoodClassModel alloc]init];
            //顶部滑动图片
            foodClassModel1.banner_picture = Dic[@"banner_picture"];
            [self.m_foodClassArray2 addObject:foodClassModel1];
        }
        [self.collectionView reloadData];
        
        NSArray *arr = dic2[@"data"];
        for (NSDictionary *dic3 in arr)
        {
            FoodClassModel *foodClassModel = [[FoodClassModel alloc]init];
            foodClassModel.series_name = dic3[@"series_name"];
            foodClassModel.image = dic3[@"image"];
            foodClassModel.episode_sum = dic3[@"episode_sum"];
            foodClassModel.episode = dic3[@"episode"];
            foodClassModel.play = dic3[@"play"];
            foodClassModel.tag = dic3[@"tag"];
            foodClassModel.m_series_id = dic3[@"series_id"];
            [self.m_foodClassArray1 addObject:foodClassModel];
        }
        [self.m_tabelView reloadData];
    
        [self.progressHUD hide:YES];
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}



#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    enterFoodClassViewController *enterFoodClassVC = [[enterFoodClassViewController alloc] init];
    enterFoodClassVC.hidesBottomBarWhenPushed = YES;
    FoodClassModel*model = self.m_foodClassArray1[indexPath.row];
    enterFoodClassVC.m_mainTopTitle = model.series_name;
    enterFoodClassVC.m_ID = model.m_series_id;
    [self.navigationController pushViewController:enterFoodClassVC animated:YES];
    
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 200;
}



#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.m_foodClassArray1.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
      FoodClassCell *cell = [FoodClassCell cellWithTabelView:tableView];
      FoodClassModel *model = self.m_foodClassArray1[indexPath.row];
      cell.foodClassModel = model;
      cell.idx = indexPath.row;
    
    return cell;
}




//~~~~~~~~~~~~~~~~~~~~~~~UICollectionViewDataSource~~~~~~~~~~~~~~~~~
//返回内容的个数(每一个Items就是一个cell)
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{

    return self.m_foodClassArray2.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    YXJCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
    FoodClassModel *model2 = self.m_foodClassArray2[indexPath.item];
    cell.collectionModel = model2;
    
    return cell;
}



#pragma mark - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(180, 80);
}



- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
     enterFoodClassViewController *topVC = [[enterFoodClassViewController alloc] init];
    [topVC setHidesBottomBarWhenPushed:YES];
    FoodClassModel*model = self.m_foodClassArray1[indexPath.row];
    topVC.m_ID = model.m_series_id;
    topVC.m_mainTopTitle = model.series_name;
    [self.navigationController pushViewController:topVC animated:YES];
}

@end
