//
//  HaiMaController.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/4.
//  Copyright © 2015年 a. All rights reserved.
//

#import "HaiMaController.h"
#import "KxMenu.h"
#import "MJRefresh.h"
#import "noticeViewController.h"
#import "personalViewController.h"
#import "CanShuController.h"
#import "UIImageView+WebCache.h"
#import "HaiMaModel.h"
#import "HaiMaManager.h"
#import "TuWenController.h"
#import "XiaoFeiController.h"
#import "loveController.h"

#import "HaiMaNameCell.h"
#import "HaiMaLogoCell.h"
#import "CanshuCell.h"
#import "WentuCell.h"
#import "logoCell.h"
#import "feedCell.h"
#import "ShopsCell.h"
@interface HaiMaController ()<UIScrollViewDelegate,UITableViewDataSource,UITableViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)UICollectionView *collectionView;
@property (nonatomic, strong) UICollectionViewFlowLayout *flow;
@end

@implementation HaiMaController{
    UIButton *_btn1;
    BOOL Tend;
    NSArray *arrCell;
    NSArray *heights;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    UIView *smallView=[[UIView alloc]initWithFrame:CGRectMake(0,0,ScreenWidth, 50)];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(110,0, 100,50)];
    label.text=@"商品详情";
    label.textColor=[UIColor whiteColor];
    [smallView addSubview:label];
    
    UIBarButtonItem *leftBtn=[[UIBarButtonItem alloc]initWithTitle:@"<" style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    leftBtn.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=leftBtn;
    
    _btn1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _btn1.frame = CGRectMake(260,0, 100, 50);
    [_btn1 setImage:[UIImage imageNamed:@"a02"] forState:UIControlStateNormal];
    _btn1.tintColor=[UIColor whiteColor];
    [_btn1 addTarget:self action:@selector(showMenu:) forControlEvents:UIControlEventTouchUpInside];
    [smallView addSubview:_btn1];
    [self.navigationItem.titleView sizeToFit];
    self.navigationItem.titleView=smallView;
    
    [[HaiMaManager shareInstance]loadInternetData];
    MJRefreshGifHeader *header=[MJRefreshGifHeader headerWithRefreshingBlock:^{
        [self.tableView reloadData];
        [self.tableView.header endRefreshing];
    }];
    
    NSArray *images=@[[UIImage imageNamed:@"pullto_center_icon"]];
    
    [header setImages:images forState:MJRefreshStateRefreshing];
    
    self.tableView.header=header;
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(notify:) name:HaiMaManagerRefreshNotify object:nil];
    heights=@[@(100),@(40),@(40),@(40),@(40),@(150),@(40),@(40)];
    [self initFootView];
    [self registerCell];
}
-(void)initFootView{
    _collectionView = [self getCollectionView];
    //使其不能滚动的属性
    _collectionView.scrollEnabled = NO;
    //是否显示滚动条
    _collectionView.showsHorizontalScrollIndicator = NO;
    _collectionView.showsVerticalScrollIndicator = NO;
    _collectionView.backgroundColor = [UIColor clearColor];
    [self.collectionView registerNib:[UINib nibWithNibName:@"ShopsCell" bundle:nil] forCellWithReuseIdentifier:@"ShopsCell"];
    self.tableView.tableFooterView=_collectionView;
}
- (UICollectionView *)getCollectionView
{
    _flow = [[UICollectionViewFlowLayout alloc] init];
    [_flow setScrollDirection:UICollectionViewScrollDirectionVertical];
    //****************** item的个数的一个*************************
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ((ScreenHeight-66-15*2)/2.35)*2 )                                                   collectionViewLayout:_flow];
    collectionView.delegate = self;
    collectionView.dataSource = self;
    return collectionView;
}

-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)notify:(NSNotification *)note
{
    NSInteger section = [note.object integerValue];
    if (section==9) {
        [self.collectionView reloadData];
        return;
    }
    if (section==10) {
        [self _initHeaderView];
        return;
    }
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.tableView.header endRefreshing];
}
-(void)registerCell{
arrCell=@[@"HaiMaNameCell",@"HaiMaLogoCell",@"CanshuCell",@"WentuCell",@"logoCell",@"feedCell"];
    for (int i=0; i<arrCell.count; i++) {
     [self.tableView registerNib:[UINib nibWithNibName:arrCell[i] bundle:nil] forCellReuseIdentifier:arrCell[i]];
    }
}
- (void) viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    _btn1.frame = CGRectMake(260, 0, 100, 50);
}
- (void)showMenu:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      
      [KxMenuItem menuItem:@"首页"
                     image:[UIImage imageNamed:@"home_normal_icon"]
                    target:self
                    action:@selector(pushMenuItem:)],
      
      [KxMenuItem menuItem:@"我的通信"
                     image:[UIImage imageNamed:@"my_notice_icon"]
                    target:self
                    action:@selector(pushMenuItem2:)],
      
      [KxMenuItem menuItem:@"我的私信"
                     image:[UIImage imageNamed:@"my_personal_letter_icon"]
                    target:self
                    action:@selector(pushMenuItem3:)],
      ];
    
    KxMenuItem *first = menuItems[0];
    first.foreColor = [UIColor colorWithRed:47/255.0f green:112/255.0f blue:225/255.0f alpha:1.0];
    first.alignment = NSTextAlignmentCenter;
    
    [KxMenu showMenuInView:self.view
                  fromRect:sender.frame
                 menuItems:menuItems];
}
- (void) pushMenuItem:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void) pushMenuItem2:(id)sender
{
    noticeViewController *noCtl=[[noticeViewController alloc]init];
    [noCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:noCtl animated:YES];
}
- (void) pushMenuItem3:(id)sender
{
    personalViewController *personalCtl=[[personalViewController alloc]init];
    [personalCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:personalCtl animated:YES];
}
-(void)_initHeaderView
{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 120)];
    for (int i = 0; i < [HaiMaManager shareInstance].HaiMaModels
         .count; i++)
    {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(ScreenWidth*i, 0, ScreenWidth, headerView.frame.size.height)];
        HaiMaModel *model = [HaiMaManager shareInstance].HaiMaModels[i];
        [imageView sd_setImageWithURL:[NSURL URLWithString:model.imgArray[0]]];
        imageView.userInteractionEnabled = YES;
        [headerView addSubview:imageView];
    }
    self.tableView.tableHeaderView= headerView;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 8;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==3) {
        return 3;
    }
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        HaiMaNameCell *cell=[tableView dequeueReusableCellWithIdentifier:@"HaiMaNameCell"];
        [cell configCellWithHaiMaNameModels:[HaiMaManager shareInstance].HaiMaNameModels];
        return cell;
    }
    else if(indexPath.section==1){
        HaiMaLogoCell *cell=[tableView dequeueReusableCellWithIdentifier:@"HaiMaLogoCell"];
        [cell configCellWithHaiMaLogoModels:[HaiMaManager shareInstance].HaiMaLogoModels];
        return cell;
    }
    else if(indexPath.section==2){
            static NSString *cellIdentifier=@"cell";
            UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
            if (cell==nil) {
                cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            }
            cell.textLabel.text=@"主要参数";
        UIButton *button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.frame=CGRectMake(270, 0,100, 50);
        [button setTitle:@"全部参数 >" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchDown];
        [cell addSubview:button];
        return cell;
    }
    else if(indexPath.section==3){
        CanshuCell *cell=[tableView dequeueReusableCellWithIdentifier:@"CanshuCell"];
        [cell configCellWithCanshuModels:[HaiMaManager shareInstance].rec_attrsModels cellForRowAtIndexPath:indexPath];
        return cell;
    }
    else if(indexPath.section==4){
        WentuCell *cell=[tableView dequeueReusableCellWithIdentifier:@"WentuCell"];
        return  cell;
    }
    else if(indexPath.section==5){
        logoCell *cell=[tableView dequeueReusableCellWithIdentifier:@"logoCell"];
        [cell configCellWithlogoModels:[HaiMaManager shareInstance].HaiMaLogoModels];
        return cell;
    }
    else if(indexPath.section==6){
        feedCell *cell=[tableView dequeueReusableCellWithIdentifier:@"feedCell"];
        return cell;
    }
    else{
        static NSString *cellIdentifier=@"cell";
        UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.textLabel.text=@"您可能喜欢";
        return cell;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
   return [heights[indexPath.section]doubleValue];
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 4;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section==1){
        NSMutableString *str=[[NSMutableString alloc]initWithFormat:@"tel:%@",@"15107558161"];
        UIWebView *callWebView=[[UIWebView alloc]init];
        [callWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
        [self.view addSubview:callWebView];
    }
    else if(indexPath.section==4){
        TuWenController *tuwenCtl=[[TuWenController alloc]init];
        [tuwenCtl setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:tuwenCtl animated:YES];
    }
    else if(indexPath.section==5){
        loveController *loveCtl=[[loveController alloc]init];
        [loveCtl setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:loveCtl animated:YES];
    }
    else if(indexPath.section==6){
        XiaoFeiController *xiaofeiCtl=[[XiaoFeiController alloc]init];
        [xiaofeiCtl setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:xiaofeiCtl animated:YES];
    }
}
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ShopsCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"ShopsCell" forIndexPath:indexPath];
    [cell configCellWithShopsModels:[HaiMaManager shareInstance].ShopsModels cellForRowAtIndexPath:indexPath];
    return cell;
}
#pragma mark - ===UICollectionViewDelegate(代理)===
//定义每个UICollectionView 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((ScreenWidth-3*15)/2, (ScreenHeight-66-15*2)/2.5);
}

//定义每个UICollectionView 的 margin
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    
    return UIEdgeInsetsMake(15, 15, 15, 15);
}
-(void)cancel{
    CanShuController *canShuCtl=[[CanShuController alloc]init];
    [canShuCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:canShuCtl animated:YES];
}
@end
