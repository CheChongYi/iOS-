//
//  LIkeModel.h
//  MeishiProject
//
//  Created by Yang on 15/11/9.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface LIkeModel : NSObject


@property (nonatomic, copy) NSString *liketitle;

@property (nonatomic, copy) NSString *likeContent;

@property (nonatomic, copy) NSString *likedescription;

@property (nonatomic, copy) NSString *likeimage;

@property (nonatomic, copy) NSString *likevideo;

@property (nonatomic, copy) NSString *likevideo1;

@property (nonatomic, copy) NSString *likeHard_level;

@property (nonatomic, copy) NSString *likeCooking_time;

@property (nonatomic, copy) NSString *likeTaste;

@property (nonatomic, copy) NSString *likeDishes_id;

@end
