//
//  baliModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/18.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface baliModel : NSObject
@property(nonatomic,strong)NSString *product_name;
@property(nonatomic,strong)NSString *mall_price;
@property(nonatomic,strong)NSString *market_price;
@property(nonatomic,strong)NSString *imgs;
@property(nonatomic,strong)NSString *name;
@property(nonatomic,strong)NSString *value;
@property(nonatomic,strong)NSString *icon;
@property(nonatomic,strong)NSString *text;
@end
