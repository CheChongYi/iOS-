//
//  specialCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/12.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "specialCell.h"
#import "UIImageView+WebCache.h"
#import "CookBookModel.h"


@interface specialCell ()


@property (weak, nonatomic) IBOutlet UIImageView *specialImage;
@property (weak, nonatomic) IBOutlet UILabel *specialTitle;
@property (weak, nonatomic) IBOutlet UILabel *specialDescription;

@property (weak, nonatomic) IBOutlet UIImageView *twpSpecialImage;
@property (weak, nonatomic) IBOutlet UILabel *twoSpecialTitle;
@property (weak, nonatomic) IBOutlet UILabel *twoSpecialDescription;

- (IBAction)clickTap:(UITapGestureRecognizer *)tap;


@end

@implementation specialCell


+ (instancetype)cellWithTabelView: (UITableView *)tabelView
{
    static NSString *ID = @"ce";
    specialCell *cell = [tabelView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"specialCell" owner:self options:nil]firstObject];
    }
    return cell;
}


- (void)setSpecialCellArray:(NSMutableArray *)specialCellArray
{
    _specialCellArray = specialCellArray;
    for (int i = 0; i<_specialCellArray.count; i++)
    {
        CookBookModel *model = _specialCellArray[i];
        if (i == 2)
        {
            self.specialTitle.text = model.hotTitle;
            self.specialDescription.text = model.hotDescription;
            [self.specialImage sd_setImageWithURL:[NSURL URLWithString:model.hotImage]];
            
        }
        else if(i == 3)
        {
            self.twoSpecialTitle.text = model.hotTitle;
            self.twoSpecialDescription.text = model.hotDescription;
            [self.twpSpecialImage sd_setImageWithURL:[NSURL URLWithString:model.hotImage]];
        }
        
        
        
    }
}



- (IBAction)clickTap:(UITapGestureRecognizer *)tap
{
    if ([self.delegate respondsToSelector:@selector(specialCell:didClickIndex:)])
    {
        [self.delegate specialCell:self didClickIndex:tap.view.tag];
    }
}

@end
