//
//  YXJTwoTopViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/20.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJTwoTopViewController.h"
#import "Header.h"
#import "YXJModel.h"
#import "AFNetworking.h"



@interface YXJTwoTopViewController ()<UIWebViewDelegate>
{
    UIActivityIndicatorView *_m_activity;
}


@property (nonatomic, strong) UIWebView *m_webView;



@end


@implementation YXJTwoTopViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.navigationItem setHidesBackButton:YES];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:allCookBookUrl parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSDictionary *dic1 = responseObject[@"data"];
        NSDictionary *dic2 = dic1[@"banner"];
        NSArray *arr = dic2[@"data"];
        NSDictionary *dic3 = [arr objectAtIndex:1];
        self.title = dic3[@"title"];
        YXJModel *model = [[YXJModel alloc] init];
        model.content = dic3[@"link"];
        NSURL *url = [NSURL URLWithString:model.content];
        self.m_webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 64, screenWidth, screenHeight)];
        self.m_webView.scrollView.bounces = NO;
        self.m_webView.delegate = self;
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [self.m_webView loadRequest:request];
        [self.view addSubview:self.m_webView];

        [self createButton];
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
    
}




- (void)createButton
{
    //设置导航栏标题的字体大小和颜色
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 65)];
    view.backgroundColor = [UIColor whiteColor];
    [self.m_webView addSubview:view];
    
    UIBarButtonItem *leftBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"returnButton.png"] style:(UIBarButtonItemStyleDone) target:self action:@selector(popView)];
    leftBtn.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = leftBtn;
}



- (void)popView
{
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)viewWillAppear:(BOOL)animated
{
    _m_activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    _m_activity.center = CGPointMake(screenWidth/2, screenHeight/2);
    _m_activity.color = [UIColor blackColor];
    [self.view addSubview:_m_activity];
    [_m_activity startAnimating];
}



- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [_m_activity stopAnimating];
}

@end
