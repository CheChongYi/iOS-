//
//  YXJEnterMoreModel.h
//  MeishiProject
//
//  Created by Yang on 15/11/24.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YXJEnterMoreModel : NSObject

/**
 *  进入专题更多模型
 */
@property (nonatomic, copy) NSString *m_enterMoreTitle;

@property (nonatomic, copy) NSString *m_enterMoreDescription;

@property (nonatomic, copy) NSString *m_enterMoreImage;

@property (nonatomic, copy) NSString *m_enterMoreID;


@end
