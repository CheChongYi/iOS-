//
//  collectViewController.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/17.
//  Copyright © 2015年 a. All rights reserved.
//

#import "collectViewController.h"

#import "View2.h"
#import "View3.h"
@interface collectViewController ()<UIActionSheetDelegate>

@end

@implementation collectViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    self.navigationItem.title=@"我的收藏";
    UIBarButtonItem *leftBtn=[[UIBarButtonItem alloc]initWithTitle:@"<" style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    leftBtn.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=leftBtn;
    UIBarButtonItem *rightBtn=[[UIBarButtonItem alloc]initWithTitle:@"管理" style:UIBarButtonItemStyleDone target:self action:@selector(dianji)];
    rightBtn.tintColor=[UIColor whiteColor];
    self.navigationItem.rightBarButtonItem=rightBtn;
    
    CGRect frame =CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height -64);
    NSArray *views =@[[View2 new],[View3 new]];
    NSArray *names =@[@"商品",@"说说"];
    //创建使用
    self.scroll =[XLScrollViewer scrollWithFrame:frame withViews:views withButtonNames:names withThreeAnimation:111];//三中动画都选择
    
    //自定义各种属性。。打开查看
    self.scroll.xl_topBackImage =[UIImage imageNamed:@"10.jpg"];
    self.scroll.xl_topBackColor =[UIColor yellowColor];
    self.scroll.xl_sliderColor =[UIColor orangeColor];
    self.scroll.xl_buttonColorNormal =[UIColor redColor];
    self.scroll.xl_buttonColorSelected =[UIColor yellowColor];
    self.scroll.xl_buttonFont =12;
    self.scroll.xl_buttonToSlider =20;
    self.scroll.xl_sliderHeight =20;
    self.scroll.xl_topHeight =20;
    self.scroll.xl_isSliderCorner =YES;
    
    //加入控制器视图
    [self.view addSubview:self.scroll];

}
-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)dianji{
    UIActionSheet *actionSheet=[[UIActionSheet alloc]initWithTitle:@"是否删除有关文件？" delegate:self cancelButtonTitle:@"取消"destructiveButtonTitle:nil otherButtonTitles:@"确定", nil];
    [actionSheet showInView:self.view];
}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            UIAlertView *alertView4=[[UIAlertView alloc]initWithTitle:nil message:@"没有内容😢" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView4 show];
        }
            break;
        default:
            return;
            break;
    }
}
@end
