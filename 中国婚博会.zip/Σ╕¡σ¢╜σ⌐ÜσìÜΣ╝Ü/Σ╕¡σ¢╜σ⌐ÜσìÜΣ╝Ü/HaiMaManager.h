//
//  HaiMaManager.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/4.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>
extern NSString *HaiMaManagerRefreshNotify;
@interface HaiMaManager : NSObject
@property(nonatomic,strong)NSMutableArray *HaiMaModels;
@property(nonatomic,strong)NSMutableArray *HaiMaNameModels;
@property(nonatomic,strong)NSMutableArray *rec_attrsModels;
@property(nonatomic,strong)NSMutableArray *HaiMaLogoModels;
@property(nonatomic,strong)NSMutableArray *ShopsModels;
@property(nonatomic,strong)NSMutableArray *CanShuModels;
@property(nonatomic,strong)NSMutableArray *TuWenModels;
@property(nonatomic,strong)NSMutableArray *XiaoFeiModels;

+(instancetype)shareInstance;
- (void)loadInternetData;
@end
