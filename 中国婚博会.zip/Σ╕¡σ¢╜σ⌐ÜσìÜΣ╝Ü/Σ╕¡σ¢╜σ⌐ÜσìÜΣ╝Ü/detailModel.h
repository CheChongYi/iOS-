//
//  detailModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/12.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface detailModel : NSObject
@property(nonatomic,strong)NSString *gift_name;
@property(nonatomic,strong)NSString *total_num;
@property(nonatomic,strong)NSString *left_num;
@property(nonatomic,strong)NSString *img_url;
@property(nonatomic,strong)NSString *url;
@property(nonatomic,strong)NSString *exchanged_num;
@property(nonatomic,strong)NSString *exchange_score;
@property(nonatomic,strong)NSString *exchange_creative;
@property(nonatomic,strong)NSString *discount;
@property(nonatomic,strong)NSString *content;
@property(nonatomic,strong)NSString *store_name;
@property(nonatomic,strong)NSString *logo;
@property(nonatomic,strong)NSString *end_time;
@end
