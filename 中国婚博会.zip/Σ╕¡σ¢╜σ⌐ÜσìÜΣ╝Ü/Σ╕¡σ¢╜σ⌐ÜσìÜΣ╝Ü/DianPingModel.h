//
//  DianPingModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DianPingModel : NSObject
@property(nonatomic,strong)NSString *uname;
@property(nonatomic,strong)NSString *content;
@property(nonatomic,strong)NSString *origin;
@property(nonatomic,strong)NSString *source;
@property(nonatomic,strong)NSString *avatar;
@end
