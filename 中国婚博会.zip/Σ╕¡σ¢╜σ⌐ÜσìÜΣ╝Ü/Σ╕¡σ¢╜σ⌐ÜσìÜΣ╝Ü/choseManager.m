//
//  choseManager.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/30.
//  Copyright © 2015年 a. All rights reserved.
//

#import "choseManager.h"
#import "AFNetworking.h"

#import "new2016Model.h"
#import "money2Model.h"
#import "productModel.h"
#import "styleModel.h"
#import "ranking2Model.h"
#import "guidModel.h"
NSString *choseManagerRefreshNotify = @"choseManagerRefreshNotify";
static choseManager *manager=nil;
@implementation choseManager
+(instancetype)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager=[[[self class]alloc]init];
        }
    });
    return manager;
}
-(void)loadInternetData{
    [self loadnew2016Data];
    [self loadmoney2Data];
    [self loadproductData];
    [self loadfashionData];
    [self loadranking2Data];
    [self loadguidData];
}
-(void)loadnew2016Data{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:choseUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"banner"];
        for (NSDictionary *dic in array) {
            new2016Model *model=[[new2016Model alloc]init];
            model.imgurl=dic[@"img_url"];
            if (!_news2016Models) {
                _news2016Models=[NSMutableArray array];
            }
            [self.news2016Models addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:choseManagerRefreshNotify object:@(10)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
        [alertView show];
        [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
    }];
}
-(void)loadmoney2Data{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:choseUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"coupon"];
        for (NSDictionary *dic in array) {
            money2Model *model=[[money2Model alloc]init];
            model.imgurl=dic[@"img_url"];
            if (!_money2Models) {
                _money2Models=[NSMutableArray array];
            }
            [self.money2Models addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:choseManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadproductData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:choseUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"product"];
        for (NSDictionary *dic in array) {
            productModel *model=[[productModel alloc]init];
            model.title=dic[@"title"];
            model.img_url=dic[@"img_url"];
            if (!_productModels) {
                _productModels=[NSMutableArray array];
            }
            [self.productModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:choseManagerRefreshNotify object:@(1)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadfashionData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:choseUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"fashion"];
        for (NSDictionary *dic in array) {
            styleModel *model=[[styleModel alloc]init];
            model.title=dic[@"title"];
            model.img_url=dic[@"img_url"];
            if (!_styleModels) {
                _styleModels=[NSMutableArray array];
            }
            [self.styleModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:choseManagerRefreshNotify object:@(3)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadranking2Data{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:choseUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"ranking"];
        for (NSDictionary *dic in array) {
            ranking2Model *model=[[ranking2Model alloc]init];
            model.store_name=dic[@"store_name"];
                        model.logo=dic[@"logo"];
            model.average_price=dic[@"average_price"];
            if (!_ranking2Models) {
                _ranking2Models=[NSMutableArray array];
            }
            [self.ranking2Models addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:choseManagerRefreshNotify object:@(5)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadguidData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:choseUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"guid"];
        for (NSDictionary *dic in array) {
            guidModel *model=[[guidModel alloc]init];
            model.article_title=dic[@"article_title"];
            if (!_guidModels) {
                _guidModels=[NSMutableArray array];
            }
            [self.guidModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:choseManagerRefreshNotify object:@(7)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)     {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
