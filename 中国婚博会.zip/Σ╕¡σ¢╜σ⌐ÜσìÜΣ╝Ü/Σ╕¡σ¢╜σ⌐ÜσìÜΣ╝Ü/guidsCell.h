//
//  guidsCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface guidsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
-(void)configCellWithguidsModels:(NSArray *)guidsModels cellForRowAtIndexPath:(NSIndexPath *)indexPath;
@end
