//
//  enterFoodClassViewController.h
//  MeishiProject
//
//  Created by Yang on 15/12/4.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface enterFoodClassViewController : UIViewController

@property (nonatomic, copy) NSString *m_mainTopTitle;

@property (nonatomic, copy) NSString *m_ID;

@property (nonatomic, copy) NSString *m_play;


@end
