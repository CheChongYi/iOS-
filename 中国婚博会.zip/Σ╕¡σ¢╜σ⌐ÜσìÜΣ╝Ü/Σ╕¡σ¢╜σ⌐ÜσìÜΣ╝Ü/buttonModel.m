//
//  buttonModel.m
//  中国婚博会
//
//  Created by Admin on 15/11/6.
//  Copyright © 2015年 a. All rights reserved.
//

#import "buttonModel.h"

@implementation buttonModel

@end
