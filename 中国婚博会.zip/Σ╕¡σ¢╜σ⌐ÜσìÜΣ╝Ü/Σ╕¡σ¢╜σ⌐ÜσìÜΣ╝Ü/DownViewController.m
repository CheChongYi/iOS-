//
//  DownViewController.m
//  中国婚博会
//
//  Created by Admin on 15/11/18.
//  Copyright © 2015年 a. All rights reserved.
//

#import "DownViewController.h"
#import "recommendModel.h"
#import "InfoManager.h"
#import "MBProgressHUD.h"
@interface DownViewController ()<UIWebViewDelegate,MBProgressHUDDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation DownViewController{
    MBProgressHUD *HUD;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self creatHUD];
    [self configCellWithrecommendWEBModels:[InfoManager shareInstance].recommendModels];
}
-(void)configCellWithrecommendWEBModels:(NSArray *)recommendWEBModels{
    for (int i=0; i<1; i++) {
        recommendModel *model=recommendWEBModels[i];
        NSURL *url=[NSURL URLWithString:model.link];
        NSURLRequest *request=[NSURLRequest requestWithURL:url];
        [self.webView loadRequest:request];
    }
}
- (void)creatHUD
{
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    HUD.labelText = @"加载中...";
    //黑化背景
    HUD.dimBackground = NO;
    HUD.delegate = self;
}
-(void)webViewDidStartLoad:(UIWebView *)webView{
    [HUD show:YES];
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    [HUD hide:YES];
}
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
    [alertView show];
    [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)     {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
