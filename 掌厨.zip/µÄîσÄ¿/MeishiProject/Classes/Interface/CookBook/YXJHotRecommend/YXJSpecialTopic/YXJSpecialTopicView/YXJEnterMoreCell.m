//
//  YXJEnterMoreCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/24.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJEnterMoreCell.h"
#import "UIImageView+WebCache.h"
#import "YXJEnterMoreModel.h"




@interface YXJEnterMoreCell ()

@property (weak, nonatomic) IBOutlet UIImageView *m_moreImage;
@property (weak, nonatomic) IBOutlet UILabel *m_moreTitle;
@property (weak, nonatomic) IBOutlet UILabel *m_moreDescription;

@end

@implementation YXJEnterMoreCell


+ (instancetype)cellWithTableView:(UITableView *)tableView;
{
    static  NSString *ID = @"ce";
    YXJEnterMoreCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"YXJEnterMoreCell" owner:self options:nil]firstObject];
    }
    return cell;
}



- (void)setM_moreModel:(YXJEnterMoreModel *)m_moreModel
{
    _m_moreModel = m_moreModel;
    self.m_moreTitle.text = _m_moreModel.m_enterMoreTitle;
    self.m_moreDescription.text = _m_moreModel.m_enterMoreDescription;
    [self.m_moreImage sd_setImageWithURL:[NSURL URLWithString:_m_moreModel.m_enterMoreImage]];
}


@end
