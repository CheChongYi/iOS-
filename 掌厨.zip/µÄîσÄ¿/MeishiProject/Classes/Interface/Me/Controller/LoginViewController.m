//
//  LoginViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/6.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

- (IBAction)dismissButton:(id)sender;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
 

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)dismissButton:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
