//
//  GuizeCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/11.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GuizeCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UITextView *ideacText;
- (void)configCellWithGuizeModels:(NSArray *)GuizeModels cellForRowAtIndexPath:(NSIndexPath *)indexPath;
@end
