//
//  freeCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import "freeCell.h"
#import "freeModel.h"
#import "UIImageView+WebCache.h"
@implementation freeCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithfreeModels:(NSArray *)freeModels{
    freeModel *model=freeModels[0];
    _titleLabel.text=model.activity_title;
    _timeLabel.text=[NSString stringWithFormat:@"活动起止时间%@至%@",model.start_time,model.end_time];
    [_webView1 loadHTMLString:model.content baseURL:nil];
    [_imageView1 sd_setImageWithURL:[NSURL URLWithString:model.url]];
    [_webView2 loadHTMLString:model.content2 baseURL:nil];
    [_imageView2 sd_setImageWithURL:[NSURL URLWithString:model.url2]];
    [_webView loadHTMLString:model.content3 baseURL:nil];
    [_imageView3 sd_setImageWithURL:[NSURL URLWithString:model.url3]];
}
@end
