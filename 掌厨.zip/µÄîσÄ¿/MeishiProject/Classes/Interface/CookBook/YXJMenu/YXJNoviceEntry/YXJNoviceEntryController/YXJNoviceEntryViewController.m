//
//  YXJNoviceEntryViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/23.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJNoviceEntryViewController.h"
#import "Header.h"


@interface YXJNoviceEntryViewController ()<UIWebViewDelegate>
{
    UIActivityIndicatorView *_m_activity;
}

@end

@implementation YXJNoviceEntryViewController



//加载数据的时候显示菊花
- (void)viewWillAppear:(BOOL)animated
{
    _m_activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    _m_activity.center = CGPointMake(screenWidth/2, screenHeight/2);
    _m_activity.color = [UIColor blackColor];
    [self.view addSubview:_m_activity];
    [_m_activity startAnimating];
}


#pragma mark - UIWebViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [_m_activity stopAnimating];
}



- (void)viewDidLoad
{
    
    [super viewDidLoad];
    
    [self setNavigationItem];
    
    UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, screenHeight)];
    webView.delegate = self;
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://pub.szzhangchu.com/html/Tour.html?from=app&#turn-to-top"]];
    [webView loadRequest:request];
    [self.view addSubview:webView];
}



- (void)setNavigationItem
{
    self.title = @"新手入门";
    //取消自带的返回按钮，添加自定义返回按钮
    [self.navigationItem setHidesBackButton:YES];
    UIBarButtonItem *returnBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"returnButton.png"] style:UIBarButtonItemStyleDone target:self action:@selector(popViewController)];
    returnBtn.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = returnBtn;
    //设置导航栏标题的字体大小和颜色
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
}



- (void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}









@end
