//
//  address2Cell.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/9.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface address2Cell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *addressLabel;
@property (weak, nonatomic) IBOutlet UILabel *distanceLabel;
-(void)configCellWithaddress2Models:(NSArray *)address2Models;
@end
