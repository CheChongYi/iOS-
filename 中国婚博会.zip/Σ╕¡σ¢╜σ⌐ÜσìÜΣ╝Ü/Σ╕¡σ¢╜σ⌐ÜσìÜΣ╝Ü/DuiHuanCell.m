//
//  DuiHuanCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/11.
//  Copyright © 2015年 a. All rights reserved.
//

#import "DuiHuanCell.h"
#import "UIImageView+WebCache.h"
#import "DuiHuanModel.h"
@implementation DuiHuanCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithDuiHuanModels:(NSArray *)DuiHuanModels cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    DuiHuanModel *model=DuiHuanModels[indexPath.row];
    [_iconView sd_setImageWithURL:[NSURL URLWithString:model.img_url]];
    _gift_name.text=model.gift_name;
    _total_num.text=[NSString stringWithFormat:@"总数量：%@",model.total_num];
    _left_num.text=[NSString stringWithFormat:@"剩余量：%@",model.left_num];
    NSString *end_time_string=model.end_time;
    int end_time=[end_time_string intValue];
    NSDate *endTime=[NSDate dateWithTimeIntervalSince1970:end_time];
    NSTimeInterval time=[endTime timeIntervalSinceNow];
    int day=(int)(time/3600/24);
    int hour=(int)(time/3600)-(day*24);
    int minute=(int)(time-day*3600*24-hour*3600)/60;
     int second = (int)(time - day*3600*24-hour*3600 - minute)/60;
    NSString *result_time=[NSString stringWithFormat:@"距开始还有：%d天%d时%d分%d秒",day,hour,minute,second];
    _timeLabel.text=result_time;
}
@end
