//
//  enterSearchViewController.h
//  MeishiProject
//
//  Created by Yang on 15/12/10.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface enterSearchViewController : UIViewController

@property (nonatomic, copy) NSString *m_searchResult;


@end
