//
//  YXJEnterFoodClassView.h
//  MeishiProject
//
//  Created by Yang on 15/12/5.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol YXJEnterFoodClassViewDelegate <NSObject>

- (void)yxjEnterFoodClassViewDidClickPlay: (NSInteger) index;

@end

@interface YXJEnterFoodClassView : UIView



@property (nonatomic, weak) id<YXJEnterFoodClassViewDelegate>delegate;

@property (weak, nonatomic) IBOutlet UIImageView *headImage;
@property (weak, nonatomic) IBOutlet UILabel *topTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *topDiscLabel;
@property (weak, nonatomic) IBOutlet UILabel *playCount;

+ (instancetype)enterFoodClassView;

@property (nonatomic, strong) NSMutableArray *m_arr;

@end
