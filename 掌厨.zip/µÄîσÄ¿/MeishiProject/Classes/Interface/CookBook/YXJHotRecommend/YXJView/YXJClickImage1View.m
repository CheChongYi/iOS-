//
//  YXJClickImage1View.m
//  MeishiProject
//
//  Created by Yang on 15/11/26.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJClickImage1View.h"


@implementation YXJClickImage1View


+ (instancetype)yxjClickImage1View
{
    return [[[NSBundle mainBundle] loadNibNamed:@"YXJClickImage1View" owner:nil options:nil]firstObject];
}



@end
