//
//  detailDuiHuanCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/12.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface detailDuiHuanCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *jifenLabel;
@property (weak, nonatomic) IBOutlet UILabel *marry_numLabel;
@property (weak, nonatomic) IBOutlet UILabel *needjifenLabel;
@property (weak, nonatomic) IBOutlet UILabel *needmarryLabel;
-(void)configCellWithdetailModels:(NSArray *)detailModels;
@end
