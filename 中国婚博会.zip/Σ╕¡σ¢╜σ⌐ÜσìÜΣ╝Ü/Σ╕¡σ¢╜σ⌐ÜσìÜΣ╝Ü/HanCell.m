//
//  HanCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/14.
//  Copyright © 2015年 a. All rights reserved.
//

#import "HanCell.h"
#import "UIImageView+WebCache.h"
#import "bendiModel.h"
@implementation HanCell

- (void)awakeFromNib {
    // Initialization code
}
-(void)configCellWithHanModels:(NSArray *)HanModels cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    bendiModel *model=HanModels[indexPath.row];
    [_iconView sd_setImageWithURL:[NSURL URLWithString:model.img_url]];
    _priceLabel.text=[NSString stringWithFormat:@"￥%@",model.mall_price];
    _nameLabel.text=model.store_name;
}
@end
