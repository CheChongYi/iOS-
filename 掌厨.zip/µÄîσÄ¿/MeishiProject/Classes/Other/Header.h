//
//  Header.h
//  MeishiProject
//
//  Created by Yang on 15/11/2.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#ifndef Header_h
#define Header_h


#define RGBColor(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]

#define screenWidth [[UIScreen mainScreen]bounds].size.width
#define screenHeight [[UIScreen mainScreen]bounds].size.height

//食谱界面URL
#define BtnUrl @"http://api.izhangchu.com/?methodName=HomeIndex&version=4.02"

//食谱整个界面URL
#define allCookBookUrl @"http://api.izhangchu.com/?methodName=HomeIndex&user_id=0&version=4.01"


//热门界面URL
#define hotRecommendUrl @"http://api.izhangchu.com/?methodName=HomeIndex&version=4.02"


//进入热门top界面URL
#define enterHotUrl @"http://api.izhangchu.com/?dishes_id=7663&methodName=DishesView"

//进入热门 做法url
#define enterHotUrl1 @"http://api.izhangchu.com/?dishes_id=8744&methodName=DishesView"

//进入热门 食材url
#define enterHotUrl2 @"http://api.izhangchu.com/?dishes_id=8744&methodName=DishesMaterial"


//进入热门 相宜相克url
#define enterHotUrl3 @"http://api.izhangchu.com/?dishes_id=8744&methodName=DishesSuitable"


//进入热门 相关常识url
#define enterHotUrl4 @"http://api.izhangchu.com/?dishes_id=8744&methodName=DishesCommensense"

//进入热门更多新品url
#define enterHotNew @"http://api.izhangchu.com/?methodName=HomeMore&page=1&size=6&type=2&user_id=0"


//进入热门更多热门url
#define enterHotAndHot1 @"http://api.izhangchu.com/?methodName=HomeMore&page=1&type=1"

#define enterHotAndHot2 @"http://api.izhangchu.com/?methodName=HomeMore&page=2&type=1"

//点击专题图片url
#define enterSpecialTopicUrl @"http://h5.izhangchu.com/web/topic_view/index.html?&topic_id=111"
//进入专题更多界面
#define enterSpecialMoreUrl @"http://api.izhangchu.com/?appVersion=4.0.2&sysVersion=9.1&devModel=iPhone&methodName=TopicList&page=1"


//家常菜界面URL
#define homeCookingUrl @"http://api.izhangchu.com/?methodName=HomeSerial&page=1&serial_id=1&size=6&user_id=0&version=4.01"

//小炒界面URL
#define sprinkleUrl @"http://api.izhangchu.com/?methodName=HomeSerial&page=1&serial_id=2&size=6&user_id=0&version=4.01"


//喜欢界面URL
#define LikeUrl @"http://api.izhangchu.com/?methodName=UserLikes"

//食课界面URL
#define FoodClassUrl @"http://api.izhangchu.com/?methodName=CourseIndex&version=4.1"



#endif /* Header_h */
