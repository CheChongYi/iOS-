//
//  rankingCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/12.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "rankingCell.h"
#import "UIImageView+WebCache.h"
#import "CookBookModel.h"
#import "CookBookViewController.h"


@interface rankingCell ()

@property (weak, nonatomic) IBOutlet UIImageView *oneRangkingImage;
@property (weak, nonatomic) IBOutlet UILabel *onetitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *oneDescriptionlabel;
@property (weak, nonatomic) IBOutlet UILabel *oneFavoriteLabel;
@property (weak, nonatomic) IBOutlet UILabel *onePlayLabel;
- (IBAction)onePlayVideo:(id)sender;

@property (weak, nonatomic) IBOutlet UIImageView *twoRangkingImage;
@property (weak, nonatomic) IBOutlet UILabel *twoTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *twoDescriptionLabel;
@property (weak, nonatomic) IBOutlet UILabel *twoFavoriteLabel;
@property (weak, nonatomic) IBOutlet UILabel *twoPlayLabel;

@property (weak, nonatomic) IBOutlet UIImageView *threeRangkingImage;
@property (weak, nonatomic) IBOutlet UILabel *threeTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *threeDescriptionLabel;
@property (weak, nonatomic) IBOutlet UILabel *threeFavoriteLabel;
@property (weak, nonatomic) IBOutlet UILabel *threePlayLabel;


- (IBAction)m_tap:(UITapGestureRecognizer *)tap;




@end



@implementation rankingCell


+ (instancetype)cellWithTabelView: (UITableView *)TableView
{
    static NSString *ID = @"ce";
    rankingCell *cell = [TableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle]loadNibNamed:@"rankingCell" owner:self options:nil]firstObject];
    }
    return cell;
}



- (void)setRangkingArray:(NSMutableArray *)rangkingArray
{
    _rangkingArray = rangkingArray;
    for (int i=0; i<_rangkingArray.count; i++)
     {
        CookBookModel *rangkingModel = _rangkingArray[i];
        if (i == 4)
        {
            self.onetitleLabel.text = rangkingModel.hotTitle;
            self.oneDescriptionlabel.text = rangkingModel.hotDescription;
            self.oneFavoriteLabel.text = rangkingModel.favorite;
            self.onePlayLabel.text = [NSString stringWithFormat:@"%@",rangkingModel.hotPlay];
            [self.oneRangkingImage sd_setImageWithURL:[NSURL URLWithString:rangkingModel.hotImage]];
        }
       else if (i == 5)
        {
            self.twoTitleLabel.text = rangkingModel.hotTitle;
            self.twoDescriptionLabel.text = rangkingModel.hotDescription;
            self.twoFavoriteLabel.text = rangkingModel.favorite;
             self.twoPlayLabel.text = [NSString stringWithFormat:@"%@",rangkingModel.hotPlay];
            [self.twoRangkingImage sd_setImageWithURL:[NSURL URLWithString:rangkingModel.hotImage]];
        }
       else if (i == 6)
       {
           self.threeTitleLabel.text = rangkingModel.hotTitle;
           self.threeDescriptionLabel.text = rangkingModel.hotDescription;
           self.threeFavoriteLabel.text = rangkingModel.favorite;
            self.threePlayLabel.text = [NSString stringWithFormat:@"%@",rangkingModel.hotPlay];
           [self.threeRangkingImage sd_setImageWithURL:[NSURL URLWithString:rangkingModel.hotImage]];
       }
         
    }
    
}


- (IBAction)onePlayVideo:(id)sender
{
    //获取按钮的Tag值
    NSInteger tag = ((UIButton *)sender).tag;
    if ([self.delegate respondsToSelector:@selector(rangkingDidPlayVideo:)])
    {
        CookBookModel *model = [[CookBookModel alloc] init];
        model.hotVideo = [(CookBookModel *)self.rangkingArray[4+tag-1000]hotVideo];
        [self.delegate rangkingDidPlayVideo:model];
    }
   
}

- (IBAction)m_tap:(UITapGestureRecognizer *)tap
{
    if ([self.delegate respondsToSelector:@selector(rankingCellDidClickImage:)])
    {
        [self.delegate rankingCellDidClickImage:tap.view.tag];
    }
}



@end
