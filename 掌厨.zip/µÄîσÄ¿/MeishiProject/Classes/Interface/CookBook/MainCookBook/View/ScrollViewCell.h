//
//  ScrollViewCell.h
//  MeishiProject
//
//  Created by Yang on 15/11/10.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>



@class ScrollViewCell;


@protocol ScrollViewCellDelegate <NSObject>

@optional
- (void)scrollViewCell:(ScrollViewCell *)cell didClickIndex:(NSInteger)index;


@end

@interface ScrollViewCell : UITableViewCell



@property (nonatomic, weak) id<ScrollViewCellDelegate> delegate;

@property (nonatomic, strong) NSMutableArray *BtnArray;

+ (instancetype)scrollViewCellWithTabelView: (UITableView *)tabelView;


@end
