//
//  detailContentCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/12.
//  Copyright © 2015年 a. All rights reserved.
//

#import "detailContentCell.h"
#import "detailModel.h"
#import "UIImageView+WebCache.h"
@implementation detailContentCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithdetailModels:(NSArray *)detailModels{
    detailModel *model=detailModels[0];
    [_iconView sd_setImageWithURL:[NSURL URLWithString:model.url]];
    [_webView loadHTMLString:model.content baseURL:nil];
}
@end
