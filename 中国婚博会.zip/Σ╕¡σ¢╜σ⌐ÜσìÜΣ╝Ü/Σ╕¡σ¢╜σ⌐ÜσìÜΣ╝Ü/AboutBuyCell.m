//
//  AboutBuyCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/10.
//  Copyright © 2015年 a. All rights reserved.
//

#import "AboutBuyCell.h"
#import "AboutButModel.h"
#import "UIImageView+WebCache.h"
@implementation AboutBuyCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithAboutBuyModels:(NSArray *)AboutBuyModels{
    for (int i=0; i<1; i++) {
        AboutButModel *model=AboutBuyModels[i];
        [self.iconView sd_setImageWithURL:[NSURL URLWithString:model.imgurl]];
        self.banbenLabel.text=model.banben;
        self.contentLabel.text=model.title;
    }
}
@end
