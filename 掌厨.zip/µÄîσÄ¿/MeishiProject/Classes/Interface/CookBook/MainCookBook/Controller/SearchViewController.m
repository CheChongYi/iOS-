//
//  SearchViewController.m
//  MeishiProject
//
//  Created by Yang on 15/12/5.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "SearchViewController.h"
#import "enterSearchViewController.h"
#import "AFNetworking.h"
#import "Header.h"



@interface SearchViewController ()<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate>
{
    UISearchBar *_searchBar;
}
@property (nonatomic, strong) UITableView *m_searchTableView;
@property (nonatomic, strong) NSMutableArray *m_searchArray;
@property (nonatomic, copy) NSString *m_searchLabel;
@property (nonatomic, copy) NSString *m_keyWord;



@end

@implementation SearchViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self customNavigationItem];

    self.automaticallyAdjustsScrollViewInsets = NO;
    
}



- (void)customNavigationItem
{
    _searchBar = [[UISearchBar alloc] init];
    _searchBar.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    _searchBar.delegate = self;
    _searchBar.placeholder = @"输入菜名或食材搜索";
    self.navigationItem.titleView = _searchBar;
    
    [self.navigationItem setHidesBackButton:YES];
    UIBarButtonItem *returnBtn = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStyleDone target:self action:@selector(returnToCookBookVC)];
    self.navigationItem.rightBarButtonItem = returnBtn;
    returnBtn.tintColor = [UIColor whiteColor];
}


- (void)returnToCookBookVC
{
    [self.navigationController popViewControllerAnimated:YES];
}



- (NSMutableArray *)m_searchArray
{
    if (_m_searchArray == nil)
    {
        _m_searchArray = [NSMutableArray array];
    }
    return _m_searchArray;
}




//UITableView是继承UIscrollView，所以可以拥有父类的属性和方法 (收回键盘)
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_searchBar resignFirstResponder];

}



#pragma mark - UISearchBarDelegate
//点击搜索框的时候调用
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.m_searchTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, screenWidth, screenHeight) style:UITableViewStylePlain];
    self.m_searchTableView.delegate = self;
    self.m_searchTableView.dataSource = self;
    [self.view addSubview:self.m_searchTableView];
}



//搜索栏输入内容时调用
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText;
{
    //把searchText设为全局变量
    self.m_keyWord = searchText;
    if (searchText.length == 0)
    {
        [self.m_searchArray removeAllObjects];
    }
    NSString *searchURL =@"http://api.izhangchu.com/";
    NSDictionary *dic = @{@"appVersion":@"4.0.2",
                          @"sysVersion":@"9.1",
                          @"devModel":@"iPhone",
                          @"keyword":searchText,
                          @"methodName":@"SearchKeyword"
                          };
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:searchURL parameters:dic success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSDictionary *dic = responseObject[@"data"];
        NSArray *arr = dic[@"data"];
        for (NSDictionary *dic1 in arr) {
            self.m_searchLabel = dic1[@"text"];
            [self.m_searchArray addObject:self.m_searchLabel];
        }
        [self.m_searchTableView reloadData];
        
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        NSLog(@"%@", error);
    }];
}




#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //push过去时把键盘注销
    [_searchBar resignFirstResponder];

    enterSearchViewController *enterSearchVC = [[enterSearchViewController alloc] init];
    NSString *string = self.m_searchArray[indexPath.row];
    enterSearchVC.m_searchResult = string;
    [self.navigationController pushViewController:enterSearchVC animated:YES];
}



#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.m_searchArray.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"ce";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    NSString *str = self.m_searchArray[indexPath.row];
    //查找某个字符串中指定的字符
    NSRange range = [str rangeOfString:self.m_keyWord];
    //给某一个指定的字符设置颜色
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc]initWithString:str];
    [string addAttribute:NSForegroundColorAttributeName value:[UIColor orangeColor] range:range];
    cell.textLabel.attributedText = string;
    
    //点击单元格Cell时不会变色
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}





@end
