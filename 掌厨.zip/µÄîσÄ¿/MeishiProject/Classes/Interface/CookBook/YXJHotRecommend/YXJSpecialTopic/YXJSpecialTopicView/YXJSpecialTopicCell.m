//
//  YXJSpecialTopicCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/19.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJSpecialTopicCell.h"


@interface YXJSpecialTopicCell ()

@end

@implementation YXJSpecialTopicCell



@end
