//
//  DsjLineLayout.m
//  UICollectionViewDemo
//
//  Created by DSJ on 15/11/7.
//  Copyright © 2015年 aoyolo.com. All rights reserved.
//

#import "DsjLineLayout.h"
#import "Header.h"


static  CGFloat const DsjItemW = 45;
static  CGFloat const DsjItemH = DsjItemW ;

@implementation DsjLineLayout


- (void)prepareLayout
{
    self.itemSize = CGSizeMake(DsjItemW, DsjItemH);
    CGFloat inset = (self.collectionView.frame.size.width - DsjItemW) * 0.5;
    //    self.sectionInset = UIEdgeInsetsMake(50, inset , 8, inset);
    self.collectionView.contentInset = UIEdgeInsetsMake(25, 97 , 8, 97);
    self.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    self.minimumLineSpacing = inset ;
    
    self.collectionView.bounces = YES;
    self.collectionView.pagingEnabled = NO;
    
}



- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds
{
    return YES;
}



- (NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect
{
    CGRect visableRect;
    visableRect.origin = self.collectionView.contentOffset;
    visableRect.size = self.collectionView.frame.size;
    CGFloat centerX = self.collectionView.contentOffset.x + self.collectionView.frame.size.width * 0.5;
    NSArray *arr = [super layoutAttributesForElementsInRect:rect];
    for (UICollectionViewLayoutAttributes *attr in arr)
    {
        if (!CGRectIntersectsRect(visableRect, attr.frame))
            continue;
        CGFloat itemCenterX = attr.center.x;
        CGFloat scale = 1 + 1 * (1 - (ABS(itemCenterX - centerX)/self.collectionView.frame.size.width * 0.5));
        attr.transform3D = CATransform3DMakeScale(scale, scale, 1.0);
    }
    return arr;
    
}



- (CGPoint)targetContentOffsetForProposedContentOffset:(CGPoint)proposedContentOffset withScrollingVelocity:(CGPoint)velocity//这个速度的x 反映着当前滚动的方向，正向右，负数向左
{
    CGRect lastRect;
    lastRect.origin = proposedContentOffset;
    lastRect.size = self.collectionView.frame.size;
    NSArray *arr = [self layoutAttributesForElementsInRect:lastRect];
    CGFloat centerX = proposedContentOffset.x + screenWidth* 0.5;
    CGFloat adjustOffset = MAXFLOAT;
    for (UICollectionViewLayoutAttributes *attr in arr)
    {
        if (ABS(attr.center.x - centerX) < ABS(adjustOffset))
        {
            adjustOffset = attr.center.x - centerX;
        }
    }
    return CGPointMake(proposedContentOffset.x + adjustOffset, 0);
}



@end
