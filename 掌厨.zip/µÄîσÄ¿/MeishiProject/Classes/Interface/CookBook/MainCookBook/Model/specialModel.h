//
//  specialModel.h
//  MeishiProject
//
//  Created by Yang on 15/11/12.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface specialModel : NSObject


@property (nonatomic, copy) NSString *m_specialTitle;

@property (nonatomic, copy) NSString *m_specialID;


@end
