//
//  ImgandNameModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/25.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImgandNameModel : NSObject
@property(nonatomic,strong)NSString *uname;
@property(nonatomic,strong)NSString *medium_img;
@end
