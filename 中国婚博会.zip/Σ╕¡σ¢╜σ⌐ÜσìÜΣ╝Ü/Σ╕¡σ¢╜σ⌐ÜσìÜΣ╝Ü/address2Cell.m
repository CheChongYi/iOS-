//
//  address2Cell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/9.
//  Copyright © 2015年 a. All rights reserved.
//

#import "address2Cell.h"
#import "MingRenModel.h"
@implementation address2Cell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithaddress2Models:(NSArray *)address2Models{
    MingRenModel *model=address2Models[0];
    _addressLabel.text=model.address;
    _distanceLabel.text=[NSString stringWithFormat:@"距离:%@",model.distance];
}
@end
