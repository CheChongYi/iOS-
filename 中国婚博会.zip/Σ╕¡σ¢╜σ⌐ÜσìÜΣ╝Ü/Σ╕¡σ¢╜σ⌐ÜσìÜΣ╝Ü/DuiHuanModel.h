//
//  DuiHuanModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/11.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DuiHuanModel : NSObject
@property(nonatomic,strong)NSString *gift_name;
@property(nonatomic,strong)NSString *img_url;
@property(nonatomic,strong)NSNumber *total_num;
@property(nonatomic,strong)NSNumber *left_num;
@property(nonatomic,strong)NSString *exchange_time;
@property(nonatomic,strong)NSString *end_time;
@end
