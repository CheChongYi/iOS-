//
//  YXJCollectionViewCell.h
//  MeishiProject
//
//  Created by Yang on 15/12/16.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>


@class FoodClassModel;

@interface YXJCollectionViewCell : UICollectionViewCell


@property (nonatomic, strong) FoodClassModel *collectionModel;

@end
