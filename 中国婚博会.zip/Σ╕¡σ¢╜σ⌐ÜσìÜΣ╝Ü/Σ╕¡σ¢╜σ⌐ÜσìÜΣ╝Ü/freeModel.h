//
//  freeModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface freeModel : NSObject
@property(nonatomic,strong)NSString *activity_title;
@property(nonatomic,strong)NSString *content;
@property(nonatomic,strong)NSString *url;
@property(nonatomic,strong)NSString *content2;
@property(nonatomic,strong)NSString *url2;
@property(nonatomic,strong)NSString *url3;
@property(nonatomic,strong)NSString *content3;
@property(nonatomic,strong)NSString *start_time;
@property(nonatomic,strong)NSString *end_time;
@end
