//
//  CookBookModel.h
//  MeishiProject
//
//  Created by Yang on 15/11/3.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CookBookModel : NSObject


@property (nonatomic, copy) NSString *text;

@property (nonatomic, copy) NSString *image;

@property (nonatomic, copy) NSString *hotVideo;

@property (nonatomic, copy) NSString *hotVideo1;

@property (nonatomic, copy) NSString *hotImage;

@property (nonatomic, copy) NSString *hotTitle;

@property (nonatomic, copy) NSString *hotDescription;

@property (nonatomic,strong) NSNumber *hotPlay;

@property (nonatomic, copy) NSString *banner_picture ;

@property (nonatomic, copy) NSString *favorite;

@property (nonatomic, copy) NSString *dishes_id;

@property (nonatomic, copy) NSString *m_content;




@end
