//
//  YXJHotMoreCell.h
//  MeishiProject
//
//  Created by Yang on 15/11/19.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>



@class YXJHotMoreModel;
@class  YXJHotMoreCell;

@protocol YXJHotMoreCellDelegate <NSObject>

- (void)yxjHotMoreCellDidClickVideo:(YXJHotMoreCell *)cell;

@end


@interface YXJHotMoreCell : UITableViewCell


@property (nonatomic, strong) YXJHotMoreModel *m_hotMoreModel;

+ (instancetype)cellWithTabelView: (UITableView *)tabelView;

@property (nonatomic, weak) id<YXJHotMoreCellDelegate>delegate;


@end
