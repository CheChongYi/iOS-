//
//  guidsCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import "guidsCell.h"
#import "guidsModel.h"
#import "UIImageView+WebCache.h"
@implementation guidsCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithguidsModels:(NSArray *)guidsModels cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    for (int i=0;i<2; i++) {
        guidsModel *model=guidsModels[indexPath.row];
        _titleLabel.text=model.title;
    }
}
@end
