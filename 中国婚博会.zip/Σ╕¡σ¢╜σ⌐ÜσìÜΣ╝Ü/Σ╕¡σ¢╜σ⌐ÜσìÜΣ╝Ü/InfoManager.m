//
//  InfoManager.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/10.
//  Copyright © 2015年 a. All rights reserved.
//

#import "InfoManager.h"
#import "AFNetworking.h"
#import "AboutButModel.h"
#import "GuizeModel.h"
#import "recommendModel.h"
#import "WeChatModel.h"
#import "welfareModel.h"
#import "getTicketModel.h"
#import "presentModel.h"
#import "shareModel.h"
#import "ImgandNameModel.h"
#import "DuiHuanModel.h"
NSString *InfoManagerRefreshNotify=@"InfoManagerRefreshNotify";
static InfoManager *manager=nil;

@implementation InfoManager
+(instancetype)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager=[[[self class]alloc]init];
        }
    });
    return manager;
}
-(void)loadInternetData{
    [self loadjiehunData];
    [self loadGuizeData];
    [self loadrecommendData];
    [self loadWeChatData];
    [self loadwelfareData];
    [self loadgetTicketData];
    [self loadpresentData];
    [self loadshareData];
    [self loadimgandnameData];
}
-(void)loadjiehunData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:banbenUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"list"];
        for (NSDictionary *dic in array) {
            AboutButModel *model=[[AboutButModel alloc]init];
            model.imgurl=dic[@"icon"];
            model.banben=dic[@"title"];
            model.title=dic[@"idesc"];
            if (!_AboutBuyModels) {
                _AboutBuyModels=[NSMutableArray array];
            }
            [self.AboutBuyModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:InfoManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
        [alertView show];
        [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
    }];
}
-(void)loadGuizeData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:banbenUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"list"];
        for (NSDictionary *dic in array) {
            GuizeModel *model=[[GuizeModel alloc]init];
            model.idesc=dic[@"idesc"];
            model.imgurl=dic[@"icon"];
            if (!_GuizeModels) {
                _GuizeModels=[NSMutableArray array];
            }
            [self.GuizeModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:InfoManagerRefreshNotify object:@(1)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadrecommendData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:DownUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"list"];
        for (NSDictionary *dic in array) {
            recommendModel *model=[[recommendModel alloc]init];
            model.title=dic[@"title"];
            
            model.idesc=dic[@"idesc"];
            
            model.imgurl=dic[@"icon"];
            
            model.link=dic[@"link"];
            if (!_recommendModels) {
                _recommendModels=[NSMutableArray array];
            }
            [self.recommendModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:InfoManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadWeChatData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:WeChatUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"list"];
        for (NSDictionary *dic in array) {
            WeChatModel *model=[[WeChatModel alloc]init];
            model.imgurl=dic[@"icon"];
            model.title=dic[@"title"];
            model.idesc=dic[@"idesc"];
            if (!_WeChatModels) {
                _WeChatModels=[NSMutableArray array];
            }
            [self.WeChatModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:InfoManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadwelfareData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:welfareUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"list"];
        for (NSDictionary *dic in array) {
            welfareModel *model=[[welfareModel alloc]init];
            model.imgurl=dic[@"img_url"];
            if (!_welfareModels) {
                _welfareModels=[NSMutableArray array];
            }
            
            [self.welfareModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:InfoManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadgetTicketData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:getTicketUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
            getTicketModel *model=[[getTicketModel alloc]init];
            model.ticket_url=dic[@"ticket_url"];
            if (!_getTicketModels) {
                _getTicketModels=[NSMutableArray array];
            }
            [self.getTicketModels addObject:model];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadpresentData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:presentUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        presentModel *model=[[presentModel alloc]init];
        model.ad_img=dic[@"ad_img"];
        model.ad_link=dic[@"ad_link"];
        if (!_presentModels) {
            _presentModels=[NSMutableArray array];
        }
        [self.presentModels addObject:model];
        [[NSNotificationCenter defaultCenter] postNotificationName:InfoManagerRefreshNotify object:nil];
      } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    }];
}
-(void)loadshareData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:shareUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSDictionary *dict=dic[@"user_info"];
            shareModel *model=[[shareModel alloc]init];
            model.user_img=dict[@"user_img"];
            
            model.user_name=dict[@"user_name"];
           
            model.wed_name=dict[@"wed_name"];
            
            model.banner_img=dict[@"banner_img"];
            
            if (!_shareModels) {
                _shareModels=[NSMutableArray array];
            }
            [self.shareModels addObject:model];
    
        [[NSNotificationCenter defaultCenter]postNotificationName:InfoManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadimgandnameData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:infoImgandNameUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        ImgandNameModel *model=[[ImgandNameModel alloc]init];
        model.uname=dic[@"uname"];
        NSDictionary *dict=dic[@"avatar"];
        model.medium_img=dict[@"medium"];
        if (!_imgandNameModels) {
            _imgandNameModels=[NSMutableArray array];
        }
        [self.imgandNameModels addObject:model];
        [[NSNotificationCenter defaultCenter]postNotificationName:InfoManagerRefreshNotify object:nil];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)     {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
