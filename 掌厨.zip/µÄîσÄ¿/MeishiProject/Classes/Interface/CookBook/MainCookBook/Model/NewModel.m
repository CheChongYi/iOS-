//
//  NewModel.m
//  MeishiProject
//
//  Created by Yang on 15/11/8.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "NewModel.h"

@implementation NewModel

@end
