//
//  CanshuCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/5.
//  Copyright © 2015年 a. All rights reserved.
//

#import "CanshuCell.h"
#import "rec_attrsModel.h"
@implementation CanshuCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithCanshuModels:(NSArray *)CanshuModels cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    for (int i=0; i<3; i++) {
        rec_attrsModel *model=CanshuModels[indexPath.row];
        _nameLabel.text=model.name;
        _valueLabel.text=model.value;
    }
   
}
@end
