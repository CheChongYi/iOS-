//
//  ActivityCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/7.
//  Copyright © 2015年 a. All rights reserved.
//

#import "ActivityCell.h"
#import "ActivityModel.h"
#import "UIImageView+WebCache.h"
@implementation ActivityCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithActivityModels:(NSArray *)ActivityModels cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ActivityModel *model=ActivityModels[indexPath.row];
    [_imgView sd_setImageWithURL:[NSURL URLWithString:model.imgUrl]];
    [_logoView sd_setImageWithURL:[NSURL URLWithString:model.logo]];
    _titleLabel.text=model.title;
    _mainLabel.text=model.storeName;
}
@end
