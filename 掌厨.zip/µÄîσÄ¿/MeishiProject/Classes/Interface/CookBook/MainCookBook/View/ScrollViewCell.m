//
//  ScrollViewCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/10.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "ScrollViewCell.h"
#import "CookBookModel.h"
#import "UIImageView+WebCache.h"


@interface ScrollViewCell ()

@property (weak, nonatomic) IBOutlet UIImageView *OneImage;
@property (weak, nonatomic) IBOutlet UILabel *OneLabel;
@property (weak, nonatomic) IBOutlet UIImageView *TwoImage;
@property (weak, nonatomic) IBOutlet UILabel *TwoLabel;
@property (weak, nonatomic) IBOutlet UIImageView *ThreeImage;
@property (weak, nonatomic) IBOutlet UILabel *ThreeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *FourImage;
@property (weak, nonatomic) IBOutlet UILabel *FourLabel;
@property (weak, nonatomic) IBOutlet UIImageView *FiveImage;
@property (weak, nonatomic) IBOutlet UILabel *FiveLabel;
@property (weak, nonatomic) IBOutlet UIImageView *sixImage;
@property (weak, nonatomic) IBOutlet UILabel *sixLabel;
@property (weak, nonatomic) IBOutlet UIImageView *SevenImage;
@property (weak, nonatomic) IBOutlet UILabel *SevenLabel;
@property (weak, nonatomic) IBOutlet UIImageView *EightImage;
@property (weak, nonatomic) IBOutlet UILabel *EightLabel;

- (IBAction)tapClick:(UITapGestureRecognizer *)sender;

@end

@implementation ScrollViewCell




+ (instancetype)scrollViewCellWithTabelView: (UITableView *)tabelView
{
    static NSString *ID = @"ce";
    ScrollViewCell *cell = [tabelView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"ScrollViewCell" owner:nil options:nil]firstObject];
    }
    return cell;
}




- (void)setBtnArray:(NSMutableArray *)BtnArray
{
    _BtnArray = BtnArray;
    for (int i=0; i<BtnArray.count; i++)
    {
        CookBookModel *model1 = BtnArray[i];
        if (i == 0)
        {
            self.OneLabel.text = model1.text;
            [self.OneImage sd_setImageWithURL:[NSURL URLWithString:model1.image]];
        }
        else if (i == 12)
        {
            self.TwoLabel.text = model1.text;
            [self.TwoImage sd_setImageWithURL:[NSURL URLWithString:model1.image]];
        }
        else if (i == 15)
        {
            self.ThreeLabel.text = model1.text;
            [self.ThreeImage sd_setImageWithURL:[NSURL URLWithString:model1.image]];
        }
        else if (i == 13)
        {
            self.FourLabel.text = model1.text;
            [self.FourImage sd_setImageWithURL:[NSURL URLWithString:model1.image]];
        }
        else if (i == 4)
        {
            self.FiveLabel.text = model1.text;
            [self.FiveImage sd_setImageWithURL:[NSURL URLWithString:model1.image]];
        }
        else if (i == 5)
        {
            self.sixLabel.text = model1.text;
            [self.sixImage sd_setImageWithURL:[NSURL URLWithString:model1.image]];
        }
        else if (i == 7)
        {
            self.SevenLabel.text = model1.text;
            [self.SevenImage sd_setImageWithURL:[NSURL URLWithString:model1.image]];
        }
        else if (i == 11)
        {
            self.EightLabel.text = model1.text;
            [self.EightImage sd_setImageWithURL:[NSURL URLWithString:model1.image]];
        }
    }
}


- (IBAction)tapClick:(UITapGestureRecognizer *)tap
{

    if ([self.delegate respondsToSelector:@selector(scrollViewCell:didClickIndex:)])
    {
        [self.delegate scrollViewCell:self didClickIndex:tap.view.tag];
    }
}
@end
