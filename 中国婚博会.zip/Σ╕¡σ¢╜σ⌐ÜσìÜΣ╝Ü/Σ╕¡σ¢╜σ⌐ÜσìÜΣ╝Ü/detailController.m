//
//  detailController.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/12.
//  Copyright © 2015年 a. All rights reserved.
//

#import "detailController.h"
#import "MJRefresh.h"
#import "KxMenu.h"
#import "noticeViewController.h"
#import "personalViewController.h"
#import "detailManager.h"

#import "detailTitleCell.h"
#import "detailTimeCell.h"
#import "detailDuiHuanCell.h"
#import "deailLogoCell.h"
#import "detailContentCell.h"
#import "ZuanController.h"
@interface detailController ()<UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation detailController
{
    NSArray *arrCell;
    UIButton *_btn1;
    NSArray *heights;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    UIView *smallView=[[UIView alloc]initWithFrame:CGRectMake(0,0,ScreenWidth, 50)];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(110,0, 100,50)];
    label.text=@"礼品详情";
    label.textColor=[UIColor whiteColor];
    [smallView addSubview:label];
    
    UIBarButtonItem *leftBtn=[[UIBarButtonItem alloc]initWithTitle:@"<" style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    leftBtn.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=leftBtn;
    
    _btn1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _btn1.frame = CGRectMake(260,0, 100, 50);
    [_btn1 setImage:[UIImage imageNamed:@"a02"] forState:UIControlStateNormal];
    _btn1.tintColor=[UIColor whiteColor];
    [_btn1 addTarget:self action:@selector(showMenu:) forControlEvents:UIControlEventTouchUpInside];
    [smallView addSubview:_btn1];
    [self.navigationItem.titleView sizeToFit];
    self.navigationItem.titleView=smallView;
    
    [[detailManager shareInstance]loadInternetData];
    [self registerCell];
    heights=@[@(40),@(90),@(200),@(140),@(40),@(700)];
   [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(notify:) name:detailManagerRefreshNotify object:nil];
}
- (void)notify:(NSNotification *)note
{
    NSInteger section = [note.object integerValue];
    if (section==0) {
        [self.tableView reloadData];
        return;
    }
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationAutomatic];
}

-(void)registerCell{
arrCell=@[@"detailTitleCell",@"detailTimeCell",@"detailDuiHuanCell",@"deailLogoCell",@"detailContentCell"];
    for (int i=0; i<arrCell.count; i++) {
        [self.tableView registerNib:[UINib nibWithNibName:arrCell[i] bundle:nil] forCellReuseIdentifier:arrCell[i]];
    }
}


-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void) viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    _btn1.frame = CGRectMake(260, 0, 100, 50);
}
- (void)showMenu:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      
      [KxMenuItem menuItem:@"首页"
                     image:[UIImage imageNamed:@"home_normal_icon"]
                    target:self
                    action:@selector(pushMenuItem:)],
      
      [KxMenuItem menuItem:@"我的通信"
                     image:[UIImage imageNamed:@"my_notice_icon"]
                    target:self
                    action:@selector(pushMenuItem2:)],
      
      [KxMenuItem menuItem:@"我的私信"
                     image:[UIImage imageNamed:@"my_personal_letter_icon"]
                    target:self
                    action:@selector(pushMenuItem3:)],
      ];
    
    KxMenuItem *first = menuItems[0];
    first.foreColor = [UIColor colorWithRed:47/255.0f green:112/255.0f blue:225/255.0f alpha:1.0];
    first.alignment = NSTextAlignmentCenter;
    
    [KxMenu showMenuInView:self.view
                  fromRect:sender.frame
                 menuItems:menuItems];
}
- (void) pushMenuItem:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void) pushMenuItem2:(id)sender
{
    noticeViewController *noCtl=[[noticeViewController alloc]init];
    [noCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:noCtl animated:YES];
}
- (void) pushMenuItem3:(id)sender
{
    personalViewController *personalCtl=[[personalViewController alloc]init];
    [personalCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:personalCtl animated:YES];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 6;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        detailTitleCell *cell=[tableView dequeueReusableCellWithIdentifier:@"detailTitleCell"];
        [cell configCellWithdetailModels:[detailManager shareInstance].detailModels];
        return cell;
    }
    else if(indexPath.section==1){
        detailTimeCell *cell=[tableView dequeueReusableCellWithIdentifier:@"detailTimeCell"];
        [cell configCellWithdetailModels:[detailManager shareInstance].detailModels];
        return cell;
    }
    else if(indexPath.section==2){
        detailDuiHuanCell *cell=[tableView dequeueReusableCellWithIdentifier:@"detailDuiHuanCell"];
        [cell configCellWithdetailModels:[detailManager shareInstance].detailModels];
        UIButton *button=(UIButton *)[cell viewWithTag:10];
        [button addTarget:self action:@selector(duihuan) forControlEvents:UIControlEventTouchDown];
        return cell;
    }
    else if(indexPath.section==3){
        deailLogoCell *cell=[tableView dequeueReusableCellWithIdentifier:@"deailLogoCell"];
        [cell configCellWithdetailModels:[detailManager shareInstance].detailModels];
        return cell;
    }
    else if(indexPath.section==4){
        static NSString *cellIdentifier=@"cell";
        UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.textLabel.text=@"礼品介绍";
        return cell;
    }
    else{
        detailContentCell *cell=[tableView dequeueReusableCellWithIdentifier:@"detailContentCell"];
        [cell configCellWithdetailModels:[detailManager shareInstance].detailModels];
        return cell;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [heights[indexPath.section]doubleValue];
}
-(void)duihuan{
    UIActionSheet *actionsheet=[[UIActionSheet alloc]initWithTitle:@"总积分不够" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"查看如何获取积分", nil];
    [actionsheet showInView:self.view];
}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:{
            ZuanController *zuanCtl=[[ZuanController alloc]init];
            [zuanCtl setHidesBottomBarWhenPushed:YES];
            [self.navigationController pushViewController:zuanCtl animated:YES];
        }
            break;
        case 1:
            return;
            break;
        default:
            break;
    }
}
@end
