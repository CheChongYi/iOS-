//
//  enterFoodClassModel.h
//  MeishiProject
//
//  Created by Yang on 15/12/5.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface enterFoodClassModel : NSObject
/// 进入食客界面模型(头部自定义的view)
@property (nonatomic, copy) NSString *m_topImage;

@property (nonatomic, copy) NSString *m_topVideo;

@property (nonatomic, copy) NSString *m_topDisc;

@property (nonatomic, copy) NSString *m_topSeries_title;

@property (nonatomic, copy) NSString *m_topPlay;

/**
 *  进入食客界面模型(评论)
 */
@property (nonatomic, copy) NSString *m_nick;

@property (nonatomic, copy) NSString *m_content;

@property (nonatomic, copy) NSString *m_create_time;

@property (nonatomic, copy) NSString *m_head_img;

@property (nonatomic, copy) NSString *m_total;



@end
