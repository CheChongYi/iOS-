//
//  rangKingModel.m
//  MeishiProject
//
//  Created by Yang on 15/12/3.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "rangKingModel.h"

@implementation rangKingModel

@end
