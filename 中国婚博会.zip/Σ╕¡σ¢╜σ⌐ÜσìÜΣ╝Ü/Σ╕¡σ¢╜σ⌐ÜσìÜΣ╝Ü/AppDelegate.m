//
//  AppDelegate.m
//  中国婚博会
//
//  Created by Admin on 15/11/5.
//  Copyright © 2015年 a. All rights reserved.
//

#import "AppDelegate.h"
#import "AdController.h"
#import "MyTabbarController.h"

#import <ShareSDK/ShareSDK.h>
#import <ShareSDKConnector/ShareSDKConnector.h>
#import "WeiboSDK.h"

@interface AppDelegate ()
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window=[[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
    self.window.backgroundColor=[UIColor whiteColor];
    
    AdController *ad=[[AdController alloc]init];
    self.window.rootViewController=ad;
    
//    MyTabbarController *tabbar=[[MyTabbarController alloc]init];
//    self.window.rootViewController=tabbar;
     [self.window makeKeyAndVisible];
    [NSThread sleepForTimeInterval:2];
    return YES;
}

@end
