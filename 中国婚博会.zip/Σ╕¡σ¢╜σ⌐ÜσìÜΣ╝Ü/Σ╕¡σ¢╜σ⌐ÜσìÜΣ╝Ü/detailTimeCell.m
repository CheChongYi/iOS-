//
//  detailTimeCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/12.
//  Copyright © 2015年 a. All rights reserved.
//

#import "detailTimeCell.h"
#import "detailModel.h"
#import "UIImageView+WebCache.h"
@implementation detailTimeCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithdetailModels:(NSArray *)detailModels{
    detailModel *model=detailModels[0];
    [_imgView sd_setImageWithURL:[NSURL URLWithString:model.img_url]];
    _totalLabel.text=[NSString stringWithFormat:@"总数量：%@",model.total_num];
    _leftLabel.text=[NSString stringWithFormat:@"剩余量：%@",model.left_num];
}
@end
