//
//  LikeCell.h
//  MeishiProject
//
//  Created by Yang on 15/11/8.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LIkeModel;
@class LikeCell;


@protocol LikeCellDelegate <NSObject>

@optional
- (void)likeCellDidClickPlay:(LikeCell *)cell;

@end


@interface LikeCell : UITableViewCell


@property (nonatomic, weak) id<LikeCellDelegate>delegate;

@property (nonatomic, strong) LIkeModel *likeModel2;

+ (instancetype)cellWithTabelView: (UITableView *)tabelView;



@end
