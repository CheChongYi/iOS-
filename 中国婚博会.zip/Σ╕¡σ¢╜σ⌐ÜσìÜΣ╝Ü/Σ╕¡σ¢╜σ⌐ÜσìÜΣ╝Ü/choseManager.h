//
//  choseManager.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/30.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>
extern NSString *choseManagerRefreshNotify;
@interface choseManager : NSObject
@property(nonatomic,strong)NSMutableArray *news2016Models;
@property(nonatomic,strong)NSMutableArray *money2Models;
@property(nonatomic,strong)NSMutableArray *productModels;
@property(nonatomic,strong)NSMutableArray *styleModels;
@property(nonatomic,strong)NSMutableArray *ranking2Models;
@property(nonatomic,strong)NSMutableArray *guidModels;

+(instancetype)shareInstance;
- (void)loadInternetData;
@end
