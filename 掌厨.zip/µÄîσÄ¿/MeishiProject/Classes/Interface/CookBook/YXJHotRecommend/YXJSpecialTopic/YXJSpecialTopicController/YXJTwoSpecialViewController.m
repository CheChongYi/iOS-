//
//  YXJTwoSpecialViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/19.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJTwoSpecialViewController.h"
#import "Header.h"



@interface YXJTwoSpecialViewController ()<UIWebViewDelegate>
{
    UIActivityIndicatorView *m_activity;
}
@property (nonatomic, strong) UIWebView *m_webView;


@end

@implementation YXJTwoSpecialViewController
- (void)viewDidLoad
{
    
    [super viewDidLoad];
    
    [self setNavigationItem];
    
    NSString *string = [NSString stringWithFormat:@"http://h5.izhangchu.com/index.php?g=web&m=topic_view_min&a=index&topic_id=%@",self.ID];
    NSURL *url = [NSURL URLWithString:string];
    self.m_webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, screenHeight)];
    self.m_webView.delegate = self;
    //设置webView没有回弹效果
    self.m_webView.scrollView.bounces = NO;
    //修改scrollView视图的页面大小
    self.m_webView.scrollView.contentInset = UIEdgeInsetsMake(0, 0, -220, 0);
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.m_webView loadRequest:request];
    [self.view addSubview:self.m_webView];
    
    [self createButton];
    
}



- (void)setNavigationItem
{
    self.title = self.topTitle;
    //取消自带的返回按钮，添加自定义返回按钮
    [self.navigationItem setHidesBackButton:YES];
    //设置导航栏标题的字体大小和颜色
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
}


- (void)createButton
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 64, screenWidth, 45)];
    view.backgroundColor = [UIColor whiteColor];
    [self.m_webView addSubview:view];
    
    UIBarButtonItem *returnBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"returnButton.png"] style:UIBarButtonItemStyleDone target:self action:@selector(popViewController)];
    returnBtn.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = returnBtn;
}



- (void)popViewController
{
    
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)viewWillAppear:(BOOL)animated
{
    m_activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    m_activity.center = CGPointMake(screenWidth/2, 250);
    m_activity.color = [UIColor blackColor];
    [m_activity startAnimating];
    [self.view addSubview:m_activity];

}




- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [m_activity stopAnimating];
}


@end
