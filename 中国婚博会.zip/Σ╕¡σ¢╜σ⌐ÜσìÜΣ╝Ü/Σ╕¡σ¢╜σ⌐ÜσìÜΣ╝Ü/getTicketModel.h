//
//  getTicketModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/19.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface getTicketModel : NSObject
@property(nonatomic,strong)NSString *ticket_url;
@end
