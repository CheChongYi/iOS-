//
//  YXJBakeCell.m
//  MeishiProject
//
//  Created by Yang on 15/11/16.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJBakeCell.h"
#import "UIImageView+WebCache.h"
#import "YXJBakeModel.h"



@interface YXJBakeCell ()

@property (weak, nonatomic) IBOutlet UIImageView *m_cellBakeImage;
@property (weak, nonatomic) IBOutlet UILabel *m_bakeTitle;
@property (weak, nonatomic) IBOutlet UILabel *m_bakeDeputytitle;
@property (weak, nonatomic) IBOutlet UIButton *m_bakeVideo;
- (IBAction)m_clickPlay:(id)sender;

@end

@implementation YXJBakeCell


+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *ID = @"ce";
    YXJBakeCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle]loadNibNamed:@"YXJBakeCell" owner:self options:nil]firstObject];
    }
    return cell;
}



- (void)setM_bakeModel:(YXJBakeModel *)m_bakeModel
{
    _m_bakeModel = m_bakeModel;
    self.m_bakeTitle.text = _m_bakeModel.m_bakeTitle;
    self.m_bakeDeputytitle.text = _m_bakeModel.m_bakeDescription;
    [self.m_cellBakeImage sd_setImageWithURL:[NSURL URLWithString:_m_bakeModel.m_bakeImage]];
}




- (IBAction)m_clickPlay:(id)sender
{
    if ([self.delegate respondsToSelector:@selector(yxjBakeCellDidClickVideo:)])
    {
        [self.delegate yxjBakeCellDidClickVideo:self];
    }
}


@end
