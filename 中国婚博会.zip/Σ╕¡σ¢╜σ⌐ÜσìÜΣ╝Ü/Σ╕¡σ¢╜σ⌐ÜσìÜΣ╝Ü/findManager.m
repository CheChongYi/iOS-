//
//  findManager.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import "findManager.h"
#import "AFNetworking.h"

#import "celebrationModel.h"
#import "quanModel.h"
#import "hunlixingshiModel.h"
#import "hunlizhusediaoModel.h"
#import "gongsiModel.h"
#import "guidsModel.h"
NSString *findManagerRefreshNotify = @"findManagerRefreshNotify";
static findManager *manager=nil;
@implementation findManager
+(instancetype)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager=[[[self class]alloc]init];
        }
    });
    return manager;
}
-(void)loadInternetData{
    [self loadcelebrationData];
    [self loadquanData];
    [self loadhunlixingshiData];
    [self loadhunlizhusediaoData];
    [self loadgongsiData];
    [self loadguidsData];
}
-(void)loadcelebrationData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:findUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"banner"];
        for (NSDictionary *dic in array) {
            celebrationModel *model=[[celebrationModel alloc]init];
            model.imgurl=dic[@"img_url"];
            if (!_celebrationModels) {
                _celebrationModels=[NSMutableArray array];
            }
            [self.celebrationModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:findManagerRefreshNotify object:@(10)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
        [alertView show];
        [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
    }];
}
-(void)loadquanData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:findUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"coupon"];
        for (NSDictionary *dic in array) {
            quanModel *model=[[quanModel alloc]init];
            model.imgurl=dic[@"img_url"];
            if (!_quanModels) {
                _quanModels=[NSMutableArray array];
            }
            [self.quanModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:findManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadhunlixingshiData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:findUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"hunlixingshi"];
        for (NSDictionary *dic in array) {
            hunlixingshiModel *model=[[hunlixingshiModel alloc]init];
            model.title=dic[@"title"];
            model.idesc=dic[@"idesc"];
            model.img_url=dic[@"img_url"];
            if (!_hunlixingshiModels) {
                _hunlixingshiModels=[NSMutableArray array];
            }
            [self.hunlixingshiModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:findManagerRefreshNotify object:@(2)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadhunlizhusediaoData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:findUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"hunlizhusediao"];
        for (NSDictionary *dic in array) {
            hunlizhusediaoModel *model=[[hunlizhusediaoModel alloc]init];
            model.title=dic[@"title"];
            model.img_url=dic[@"img_url"];
            if (!_hunlizhusediaoModels) {
                _hunlizhusediaoModels=[NSMutableArray array];
            }
            [self.hunlizhusediaoModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:findManagerRefreshNotify object:@(4)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadgongsiData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:findUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"ranking"];
        for (NSDictionary *dic in array) {
            gongsiModel *model=[[gongsiModel alloc]init];
            model.store_name=dic[@"store_name"];
            model.logo=dic[@"logo"];
            model.average_price=dic[@"average_price"];
            if (!_gongsiModels) {
                _gongsiModels=[NSMutableArray array];
            }
            [self.gongsiModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:findManagerRefreshNotify object:@(6)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadguidsData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:findUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"guid"];
        for (NSDictionary *dic in array) {
            guidsModel *model=[[guidsModel alloc]init];
            model.title=dic[@"article_title"];
            NSLog(@"%@",model.title);
            if (!_guidsModels) {
                _guidsModels=[NSMutableArray array];
            }
            [self.guidsModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:findManagerRefreshNotify object:@(8)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)     {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
