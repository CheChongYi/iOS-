//
//  YXJBakeViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/16.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJBakeViewController.h"
#import "YXJBakeCell.h"
#import "YXJBakeModel.h"
#import "AFNetworking.h"
#import "Header.h"
#import "MJRefresh.h"
@import MediaPlayer;
#import "YXJClickImage1Controller.h"



@interface YXJBakeViewController ()<UITableViewDataSource,UITableViewDelegate,YXJBakeCellDelegate>
{
    NSInteger m_page;
    UIActivityIndicatorView *_m_activity;
}


@property (nonatomic, strong) NSMutableArray *m_bakeArray;
@property (nonatomic, strong) UITableView *m_bakeTableView;

@end

@implementation YXJBakeViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setNavigationItem];
    [self createTableView];
    [self bakeXiala];
}


//加载数据的时候显示菊花(视图将要出现)
- (void)viewWillAppear:(BOOL)animated
{
    _m_activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    _m_activity.center = CGPointMake(screenWidth/2, screenHeight/2);
    _m_activity.color = [UIColor blackColor];
    [self.view addSubview:_m_activity];
    [_m_activity startAnimating];
    
    self.navigationController.navigationBarHidden = NO;
}

//视图已经出现,停止菊花效果
- (void)viewDidAppear:(BOOL)animated
{
    [_m_activity stopAnimating];
}



- (void)createTableView
{
    self.m_bakeTableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    self.m_bakeTableView.delegate = self;
    self.m_bakeTableView.dataSource = self;
    //隐藏TableView的分割线
    self.m_bakeTableView.separatorStyle = NO;
    [self.view addSubview:self.m_bakeTableView];
    
    MJRefreshGifHeader *bakeHeader = [MJRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(bakeXiala)];
     NSArray *bakeArr1 = @[[UIImage imageNamed:@"refurbish1.png"],[UIImage imageNamed:@"refurbish2.png"]];
    [bakeHeader setImages:bakeArr1 forState:MJRefreshStateRefreshing];
    self.m_bakeTableView.header = bakeHeader;
    
    MJRefreshAutoGifFooter *bakeFooter = [MJRefreshAutoGifFooter footerWithRefreshingTarget:self refreshingAction:@selector(bakeShangla)];
     NSArray *bakeArr2 = @[[UIImage imageNamed:@"refurbish1.png"],[UIImage imageNamed:@"refurbish2.png"]];
    [bakeFooter setImages:bakeArr2 forState:MJRefreshStateRefreshing];
    self.m_bakeTableView.footer = bakeFooter;

}



- (void)setNavigationItem
{
    self.title = @"烘培时光 29道";
    //取消自带的返回按钮，添加自定义返回按钮
    [self.navigationItem setHidesBackButton:YES];
    UIBarButtonItem *returnBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"returnButton.png"] style:UIBarButtonItemStyleDone target:self action:@selector(popViewController)];
    returnBtn.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = returnBtn;
    //设置导航栏标题的字体大小和颜色
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];    
}



- (void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}



- (NSMutableArray *)m_bakeArray
{
    if (_m_bakeArray == nil)
    {
        _m_bakeArray = [NSMutableArray array];
    }
    return _m_bakeArray;
}




- (void)bakeXiala
{
    m_page = 1;
    [self createBakeReaquest1:m_page];
}



- (void)bakeShangla
{
    m_page++;
    [self createBakeReaquest1:m_page];
}


//烘培数据请求
- (void)createBakeReaquest1:(NSInteger)page;
{
    NSString *bakeStr = [NSString stringWithFormat:@"http://api.izhangchu.com/?appVersion=4.0.2&sysVersion=9.1&devModel=iPhone&cat_id=404&methodName=CategorySearch&page=%ld&type=1",page];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:bakeStr parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        
        if (page == 1) {
            [self.m_bakeArray removeAllObjects];
        }
        
        NSData *data = [NSData dataWithData:responseObject];
        NSDictionary *dic1 = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSDictionary *dic2 = dic1[@"data"];
        NSArray *arr = dic2[@"data"];
        for (NSDictionary *dic3 in arr) {
            YXJBakeModel *bakeModel = [[YXJBakeModel alloc] init];
            bakeModel.m_bakeTitle = dic3[@"title"];
            bakeModel.m_bakeDescription = dic3[@"description"];
            bakeModel.m_bakeImage = dic3[@"image"];
            bakeModel.m_bakeVideo = dic3[@"video"];
            bakeModel.m_bakeVideo1 = dic3[@"video1"];
            bakeModel.m_content = dic3[@"content"];
            bakeModel.m_hard_level = dic3[@"hard_level"];
            bakeModel.m_cooking_time = dic3[@"cooking_time"];
            bakeModel.m_dishes_id = dic3[@"dishes_id"];
            bakeModel.m_taste = dic3[@"taste"];
            [self.m_bakeArray addObject:bakeModel];
        }
        [self.m_bakeTableView reloadData];
        [self.m_bakeTableView.header endRefreshing];
        [self.m_bakeTableView.footer endRefreshing];
        
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}



#pragma mark - UITableViewDelegate (push到YXJClickImage1Controller及传模型数据)
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    YXJClickImage1Controller *clickImageCtr = [[YXJClickImage1Controller alloc] init];
    [self.navigationController pushViewController:clickImageCtr animated:YES];
    YXJBakeModel *model = self.m_bakeArray[indexPath.row];
    clickImageCtr.m_headImageString = model.m_bakeImage;
    clickImageCtr.m_title = model.m_bakeTitle;
    clickImageCtr.m_content = model.m_content;
    clickImageCtr.m_dishesId = model.m_dishes_id;
    clickImageCtr.m_cooking_time = model.m_cooking_time;
    clickImageCtr.m_hard_level = model.m_hard_level;
    clickImageCtr.m_taste = model.m_taste;
    clickImageCtr.m_video = model.m_bakeVideo;
    clickImageCtr.m_video1 = model.m_bakeVideo1;
}




//返回行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 200;
}




#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.m_bakeArray.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    YXJBakeModel *model = self.m_bakeArray[indexPath.row];
    YXJBakeCell *cell = [YXJBakeCell cellWithTableView:tableView];
    cell.m_bakeModel = model;
    cell.delegate = self;
    return cell;
    
}


//烘培视频播放
#pragma mark - YXJBakeCellDelegate
- (void)yxjBakeCellDidClickVideo:(YXJBakeCell *)cell
{
    NSURL *url = [NSURL URLWithString:cell.m_bakeModel.m_bakeVideo];
    MPMoviePlayerViewController *bakePlay = [[MPMoviePlayerViewController alloc] initWithContentURL:url];
    [self presentViewController:bakePlay animated:YES completion:nil];
}




@end
