//
//  HotCell.h
//  MeishiProject
//
//  Created by Yang on 15/11/7.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>


@class CookBookModel;
@class HotCell;


@protocol HotCellDelegate <NSObject>

@optional
/// 点击视频
- (void)hotCellDidClickPlay:(HotCell *)cell;
// 点击图片
- (void)hotCellDidClickImage:(HotCell *)cell;

@end

@interface HotCell : UITableViewCell


@property (nonatomic, strong) CookBookModel *hotModel;

+ (instancetype)cellWithTabelView: (UITableView *)tabelView;

@property (nonatomic, weak) id<HotCellDelegate>delegate;


@end
