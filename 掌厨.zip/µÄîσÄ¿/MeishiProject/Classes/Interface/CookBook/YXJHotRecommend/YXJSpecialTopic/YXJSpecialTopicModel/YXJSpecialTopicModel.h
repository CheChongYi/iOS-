//
//  YXJSpecialTopicModel.h
//  MeishiProject
//
//  Created by Yang on 15/11/19.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YXJSpecialTopicModel : NSObject

@end
