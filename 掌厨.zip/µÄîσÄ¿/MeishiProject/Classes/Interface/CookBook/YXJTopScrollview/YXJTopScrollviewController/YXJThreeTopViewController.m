//
//  YXJThreeTopViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/20.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJThreeTopViewController.h"
#import "AFNetworking.h"
#import "Header.h"
#import "YXJModel.h"



@interface YXJThreeTopViewController ()<UIWebViewDelegate>
{
    UIActivityIndicatorView *_m_activity;
}

@property (nonatomic, strong) UIWebView *m_webView;



@end

@implementation YXJThreeTopViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.navigationItem setHidesBackButton:YES];
    //设置导航栏标题的字体大小和颜色
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:allCookBookUrl parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSDictionary *dic1 = responseObject[@"data"];
        NSDictionary *dic2 = dic1[@"banner"];
        NSArray *arr = dic2[@"data"];
        NSDictionary *dic3 = [arr objectAtIndex:2];
        self.title = dic3[@"title"];
        YXJModel *model = [[YXJModel alloc] init];
        model.content = dic3[@"link"];
        NSURL *url = [NSURL URLWithString:model.content];
        self.m_webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 64, screenWidth, screenHeight)];
        //设置webView没有回弹效果
        self.m_webView.scrollView.bounces = NO;
        //修改scrollView视图的页面大小
        self.m_webView.scrollView.contentInset = UIEdgeInsetsMake(0, 0, -150, 0);
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [self.m_webView loadRequest:request];
        [self.view addSubview:self.m_webView];
        
        [self createButton];
     } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
     }];
    
}



- (void)createButton
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 45)];
    view.backgroundColor = [UIColor whiteColor];
    [self.m_webView addSubview:view];
    
    //取消自带的返回按钮，添加自定义返回按钮
    [self.navigationItem setHidesBackButton:YES];
    UIBarButtonItem *returnBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"returnButton.png"] style:UIBarButtonItemStyleDone target:self action:@selector(popViewController)];
    returnBtn.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = returnBtn;
}



- (void)popViewController
{
    
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)viewWillAppear:(BOOL)animated
{
    _m_activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    _m_activity.center = CGPointMake(screenWidth/2, screenHeight/2);
    _m_activity.color = [UIColor blackColor];
    [self.view addSubview:_m_activity];
    [_m_activity startAnimating];
}



- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [_m_activity stopAnimating];
}


@end
