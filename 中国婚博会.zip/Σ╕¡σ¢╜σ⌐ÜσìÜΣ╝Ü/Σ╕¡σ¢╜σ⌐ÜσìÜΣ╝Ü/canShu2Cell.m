//
//  canShu2Cell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/5.
//  Copyright © 2015年 a. All rights reserved.
//

#import "canShu2Cell.h"
#import "CanShuModel.h"
@implementation canShu2Cell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithCanShuModels:(NSArray *)CanShuModels cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CanShuModel *model=CanShuModels[indexPath.section];
    _nameLabel.text=model.name;
    _valueLabel.text=model.value;
}
@end
