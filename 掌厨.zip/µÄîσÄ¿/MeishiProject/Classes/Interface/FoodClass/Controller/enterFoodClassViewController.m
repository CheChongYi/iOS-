//
//  enterFoodClassViewController.m
//  MeishiProject
//
//  Created by Yang on 15/12/4.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "enterFoodClassViewController.h"
#import "YXJEnterFoodClassTableViewCell.h"
#import "YXJEnterFoodClassView.h"
#import "LoginViewController.h"
#import "enterFoodClassModel.h"
#import "AFNetworking.h"
#import "Header.h"
#import "UIImageView+WebCache.h"
#import "MJRefresh.h"

@import MediaPlayer;



@interface enterFoodClassViewController ()<UITableViewDelegate,UITableViewDataSource,YXJEnterFoodClassViewDelegate>
{
    NSInteger m_page;
}

@property (nonatomic, strong) UITableView *m_foodClassTableView;

@property (nonatomic, strong) NSMutableArray *m_foodClassArray;

@property (nonatomic, strong) NSMutableArray *m_enterFoodClassArray;

@property (nonatomic, strong) YXJEnterFoodClassView *m_customview;

@property (nonatomic, copy) NSString *m_pinglun;

@property (nonatomic, copy) NSString *m_video;

@property (nonatomic, strong) NSMutableArray *m_array;



@end

@implementation enterFoodClassViewController


- (void)viewDidLoad
{
    [super viewDidLoad];

    [self setNavigationItem];
    [self createTableView];
    [self createTopDataRequest];
    [self initYXJEnterFoodClassView];
    [self xiala];

}




- (void)initYXJEnterFoodClassView
{
    YXJEnterFoodClassView *view = [YXJEnterFoodClassView enterFoodClassView];
    view.delegate = self;
    self.m_customview = view;
    self.m_foodClassTableView.tableHeaderView = self.m_customview;
}



- (void)createTableView
{
    self.m_foodClassTableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStyleGrouped];
    self.m_foodClassTableView.delegate = self;
    self.m_foodClassTableView.dataSource = self;
    self.m_foodClassTableView.separatorStyle = NO;
    [self.view addSubview:self.m_foodClassTableView];
    //下拉刷新
    MJRefreshGifHeader *header = [MJRefreshGifHeader headerWithRefreshingTarget:self refreshingAction:@selector(xiala)];
    // 设置刷新图片
    NSArray *arr = @[[UIImage imageNamed:@"refurbish1.png"],[UIImage imageNamed:@"refurbish2.png"]];
    [header setImages:arr forState:MJRefreshStateRefreshing];
    self.m_foodClassTableView.header = header;
    //上拉加载
    MJRefreshAutoGifFooter *footer = [MJRefreshAutoGifFooter footerWithRefreshingTarget:self refreshingAction:@selector(shangla)];
    // 设置刷新图片
    NSArray *arr1 = @[[UIImage imageNamed:@"refurbish1.png"],[UIImage imageNamed:@"refurbish2.png"]];
    [footer setImages:arr1 forState:MJRefreshStateRefreshing];
    self.m_foodClassTableView.footer = footer;
    

    
}


- (void)setNavigationItem
{
   self.title = self.m_mainTopTitle;
   //截取字符串变为数组
   NSArray *arr = [self.title componentsSeparatedByString:@"#"];
   self.title = arr[1];
    //取消自带的返回按钮，添加自定义返回按钮
    [self.navigationItem setHidesBackButton:YES];
    UIBarButtonItem *returnBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"returnButton.png"] style:UIBarButtonItemStyleDone target:self action:@selector(popViewController)];
    returnBtn.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = returnBtn;
    //设置导航栏标题的字体大小和颜色
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
}


- (void)popViewController
{
    [self.navigationController popViewControllerAnimated:YES];
}




- (NSMutableArray *) m_foodClassArray
{
    if (_m_foodClassArray == nil)
    {
        _m_foodClassArray = [NSMutableArray array];
    }
    return _m_foodClassArray;
}




- (NSMutableArray *)m_enterFoodClassArray
{
    if (_m_enterFoodClassArray == nil)
    {
        _m_enterFoodClassArray = [NSMutableArray array];
    }
    return _m_enterFoodClassArray;
}




- (NSMutableArray *)m_array
{
    if (_m_array == nil)
    {
        _m_array = [NSMutableArray array];
    }
    return _m_array;
}



- (void)xiala
{
    m_page = 1;
    [self createDataRequest:m_page];
}


- (void)shangla
{
    m_page ++;
    [self createDataRequest:m_page];
}


//评论数据请求
- (void)createDataRequest:(NSInteger)page;
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    NSString *url = [NSString stringWithFormat:@"http://api.izhangchu.com/?appVersion=4.0.2&sysVersion=9.1&devModel=iPhone&methodName=CommentList&page=%ld&relate_id=%@&size=10&token=0&type=2&user_id=0&version=4.1",page,self.m_ID];
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        
        if (m_page == 1)
        {
            [self.m_foodClassArray removeAllObjects];
        }
        
        NSDictionary *dic1 = responseObject[@"data"];
        self.m_pinglun = [NSString stringWithFormat:@"%@评论",dic1[@"total"]];
        NSArray *arr1 = dic1[@"data"];
        for (NSDictionary *dic2 in arr1)
        {
            enterFoodClassModel *model2 = [[enterFoodClassModel alloc] init];
            model2.m_head_img = dic2[@"head_img"];
            model2.m_nick = dic2[@"nick"];
            model2.m_content = dic2[@"content"];
            model2.m_create_time = dic2[@"create_time"];
            [self.m_foodClassArray addObject:model2];
        }
        [self.m_foodClassTableView reloadData];
         //刷新结束
        [self.m_foodClassTableView.header endRefreshing];
        [self.m_foodClassTableView.footer endRefreshing];

    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}



///头部自定义view数据请求
- (void)createTopDataRequest
{
    NSString *string = [NSString stringWithFormat:@"http://api.izhangchu.com/?appVersion=4.0.2&sysVersion=9.1&devModel=iPhone&methodName=CourseSeriesView&series_id=%@&token=0&user_id=0&version=4.1",self.m_ID];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager GET:string parameters:nil
         success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
             NSDictionary *dic = responseObject[@"data"];
             NSArray *arr = dic[@"data"];
             for (NSDictionary *dic1 in arr) {
                 enterFoodClassModel *model = [[enterFoodClassModel alloc] init];
                 model.m_topImage = dic1[@"course_image"];
                 model.m_topSeries_title = dic1[@"course_name"];
                 model.m_topDisc = dic1[@"course_subject"];
                 //播放视频url
                  NSString *string = dic1[@"course_video"];
                 [self.m_array addObject:string];
                 
                 [self.m_enterFoodClassArray addObject:model];
             }
             self.m_customview.m_arr = self.m_enterFoodClassArray;
             
         } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
             
         }];
    
}



#pragma mark - 单元格头部视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
        UIView *headerView = [[UIView alloc] init];
        headerView.backgroundColor = [UIColor whiteColor];
    
        UIImageView *image = [[UIImageView alloc] initWithFrame:CGRectMake(20, 12, 40, 25)];
        image.image = [UIImage imageNamed:@"pinglun.png"];
        [headerView addSubview:image];
         //多少条评论
        UILabel *m_titleLabel = [[UILabel alloc] initWithFrame: CGRectMake(70, 15, 80, 20)];
        m_titleLabel.text = self.m_pinglun;
        m_titleLabel.font = [UIFont systemFontOfSize:16];
        [headerView addSubview:m_titleLabel];
        
        UILabel *titleLabel2 = [[UILabel alloc] initWithFrame: CGRectMake(20, 45, screenWidth-40, 30)];
        titleLabel2.backgroundColor = [UIColor orangeColor];
        titleLabel2.font = [UIFont systemFontOfSize:18];
        titleLabel2.text = @"我要评论";
        titleLabel2.textAlignment = NSTextAlignmentCenter;
        titleLabel2.textColor = [UIColor whiteColor];
        titleLabel2.userInteractionEnabled = YES;
        [headerView addSubview:titleLabel2];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(puchLoginController)];
        [titleLabel2 addGestureRecognizer:tap];
    
        return headerView;
}




#pragma mark -跳到登陆界面
- (void)puchLoginController
{
    LoginViewController *loginVC = [[LoginViewController alloc] init];
    [self presentViewController:loginVC animated:YES completion:nil];
}




- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    LoginViewController *loginVC1 = [[LoginViewController alloc] init];
    [self presentViewController:loginVC1 animated:YES completion:nil];
}


#pragma mark - 行高
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 80;
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}


#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.m_foodClassArray.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    YXJEnterFoodClassTableViewCell *cell = [YXJEnterFoodClassTableViewCell enterFoodClassTableViewCell:tableView];
    ///评论模型数据
    enterFoodClassModel *mod = self.m_foodClassArray[indexPath.row];
    cell.m_model = mod;
    
    return cell;
}



#pragma mark - YXJEnterFoodClassViewDelegate 进入食客界面播放视频
- (void)yxjEnterFoodClassViewDidClickPlay:(NSInteger)index
{

    NSURL *url = [NSURL URLWithString:self.m_array[index]];
    MPMoviePlayerViewController *play = [[MPMoviePlayerViewController alloc] initWithContentURL:url];
    [self presentViewController:play animated:YES completion:nil];

}


@end
