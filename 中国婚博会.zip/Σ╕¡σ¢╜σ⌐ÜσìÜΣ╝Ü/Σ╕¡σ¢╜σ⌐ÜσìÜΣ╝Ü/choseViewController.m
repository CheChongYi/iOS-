//
//  ShopsViewController.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/30.
//  Copyright © 2015年 a. All rights reserved.
//

#import "choseViewController.h"
#import "choseManager.h"
#import "MJRefresh.h"
#import "new2016Model.h"
#import "UIImageView+WebCache.h"
#import "styleModel.h"
#import "tryController.h"

#import "money2Cell.h"
#import "productCell.h"
#import "ranking2Cell.h"
#import "guidCell.h"
@interface choseViewController ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)UIPageControl *pageCtl;
@end

@implementation choseViewController{
    NSArray *heights;
    BOOL Tend;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    self.navigationItem.title=@"婚纱礼服";
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],UITextAttributeTextColor, nil]];
    UIBarButtonItem *leftItem=[[UIBarButtonItem alloc]initWithTitle:@"< " style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    leftItem.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=leftItem;
    
    [[choseManager shareInstance]loadInternetData];
    MJRefreshGifHeader *header=[MJRefreshGifHeader headerWithRefreshingBlock:^{
        [self.tableView reloadData];
        [self.tableView.header endRefreshing];
    }];
    NSArray *images=@[[UIImage imageNamed:@"pullto_center_icon"]];
    
    [header setImages:images forState:MJRefreshStateRefreshing];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(notify:) name:choseManagerRefreshNotify object:nil];
    [self registerCell];
    self.tableView.header=header;
    
    heights=@[@(70),@(190),@(50),@(120),@(50),@(100),@(40),@(40)];
}
-(void)_initHeaderView
{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 120)];
    for (int i = 0; i < [choseManager shareInstance].news2016Models.count; i++)
    {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(ScreenWidth*i, 0, ScreenWidth, headerView.frame.size.height)];
        new2016Model *model = [choseManager shareInstance].news2016Models[i];
        [imageView sd_setImageWithURL:[NSURL URLWithString:model.imgurl]];
        imageView.tag = i;
        imageView.userInteractionEnabled = YES;
        [headerView addSubview:imageView];
        UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
        [imageView addGestureRecognizer:tap];
    }
    self.tableView.tableHeaderView = headerView;
}
-(void)tap:(UITapGestureRecognizer *)tap{
    NSInteger i = tap.view.tag;
    if (i==0) {
        tryController *tryCtl=[[tryController alloc]init];
        [tryCtl setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:tryCtl animated:YES];
    }
}
-(void)registerCell{
    [self.tableView registerNib:[UINib nibWithNibName:@"money2Cell" bundle:nil] forCellReuseIdentifier:@"money2Cell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"productCell" bundle:nil] forCellReuseIdentifier:@"productCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"ranking2Cell" bundle:nil] forCellReuseIdentifier:@"ranking2Cell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"guidCell" bundle:nil] forCellReuseIdentifier:@"guidCell"];
}
-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)notify:(NSNotification *)note
{
    NSInteger section = [note.object integerValue];
    if (section==10) {
        [self _initHeaderView];
        return;
    }
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.tableView.header endRefreshing];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 8;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==5) {
        return 4;
    }
    if (section==7) {
        return 2;
    }
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        money2Cell *cell=[tableView dequeueReusableCellWithIdentifier:@"money2Cell"];
        [cell configCellWithmoney2Models:[choseManager shareInstance].money2Models];
        return cell;
    }
    else if(indexPath.section==1){
        productCell *cell=[tableView dequeueReusableCellWithIdentifier:@"productCell"];
        [cell configCellWithproductModels:[choseManager shareInstance].productModels];
        return cell;
    }
    else if (indexPath.section==2){
        static NSString *cellIdentifier=@"cell";
        UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
     cell.textLabel.text=@"最新款式";
        return cell;
    }
    else if(indexPath.section==3){
        static NSString *cellIdentifier=@"cell";
        UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 120)];
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 120)];
        _scrollView.contentSize = CGSizeMake(ScreenWidth*[choseManager shareInstance].styleModels.count, headerView.frame.size.height);
        _scrollView.delegate = self;
        _scrollView.pagingEnabled=YES;
        //    _scrollview.bounces = NO;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.scrollEnabled = YES;     //是否可以触摸滚动视图 默认可以
        _pageCtl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, 90,  ScreenWidth, 30)];
        _pageCtl.pageIndicatorTintColor = [UIColor grayColor];
        _pageCtl.currentPageIndicatorTintColor = RGBColor(237, 103, 97);
        _pageCtl.backgroundColor = [UIColor clearColor];
        _pageCtl.numberOfPages = [choseManager shareInstance].styleModels.count;
        [_pageCtl addTarget:self action:@selector(changeValues:) forControlEvents:UIControlEventAllEvents];
        for (int i = 0; i < [choseManager shareInstance].styleModels.count; i++)
        {
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(ScreenWidth*i, 0, ScreenWidth, _scrollView.frame.size.height)];
            styleModel *model = [choseManager shareInstance].styleModels[i];
            [imageView sd_setImageWithURL:[NSURL URLWithString:model.img_url]];
            imageView.tag = i;
            
            imageView.userInteractionEnabled = YES;
            [_scrollView addSubview:imageView];
        }
        [cell addSubview:headerView];
        [headerView addSubview:_scrollView];
        [headerView addSubview:_pageCtl];
        //添加计时器timer
        [NSTimer scheduledTimerWithTimeInterval:4 target:self selector:@selector(handleMaxShowTimer) userInfo: nil repeats:YES];
        return cell;
    }
    else if(indexPath.section==4){
        static NSString *cellIdentifier=@"cell";
        UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
      cell.textLabel.text=@"商家口碑";
        UIButton *button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.frame=CGRectMake(320, 0,50, 50);
        [button setTitle:@"更多" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchDown];
        [cell addSubview:button];
        return cell;
    }
    else if(indexPath.section==5){
        ranking2Cell *cell=[tableView dequeueReusableCellWithIdentifier:@"ranking2Cell"];
        [cell configCellWithranking2Models:[choseManager shareInstance].ranking2Models cellForRowAtIndexPath:indexPath];
        return cell;
    }
    else if(indexPath.section==6){
        static NSString *cellIdentifier=@"cell";
        UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        cell.textLabel.text=@"新手必读";
        return cell;
    }
    else{
        guidCell *cell=[tableView dequeueReusableCellWithIdentifier:@"guidCell"];
        [cell configCellWithguidModels:[choseManager shareInstance].guidModels cellForRowAtIndexPath:indexPath];
        return cell;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [heights[indexPath.section]doubleValue];
}
//实现计时器
- (void)handleMaxShowTimer{
    ++_pageCtl.currentPage;
    if(Tend)
    {
        [_scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
        _pageCtl.currentPage=0;
    }else
    {
        [_scrollView setContentOffset:CGPointMake(_pageCtl.currentPage*ScreenWidth, 0) animated:YES];
    }
    if (_pageCtl.currentPage==_pageCtl.numberOfPages-1)
    {
        Tend=YES;
    }
    else
    {
        Tend=NO;
    }
}
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    NSInteger page = _scrollView.contentOffset.x/_scrollView.frame.size.width;
    _pageCtl.currentPage = page;
}
- (void)changeValues:(UIPageControl *)pageControl
{
    int page=_scrollView.contentOffset.x/ScreenWidth;
    pageControl.currentPage=page;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    int page=_scrollView.contentOffset.x/ScreenWidth;
    _pageCtl.currentPage=page;
}

@end
