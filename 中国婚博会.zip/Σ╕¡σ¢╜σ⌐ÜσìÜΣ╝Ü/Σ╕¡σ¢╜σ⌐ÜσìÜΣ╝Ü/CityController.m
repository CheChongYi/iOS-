//
//  CityController.m
//  中国婚博会
//
//  Created by Admin on 15/11/6.
//  Copyright © 2015年 a. All rights reserved.
//

#import "CityController.h"
@interface CityController ()<UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property(nonatomic,strong)NSArray *cityArray;
@property(nonatomic,strong)UITableViewCell *cell;
@end

@implementation CityController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setBarTintColor:[UIColor whiteColor]];
    _cityArray=@[@"北京",@"上海",@"广州",@"武汉",@"天津"];
    self.navigationItem.title=@"所在城市";
    UIBarButtonItem *leftBtn=[[UIBarButtonItem alloc]initWithTitle:@"<" style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    [self.navigationController.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor grayColor],UITextAttributeTextColor, nil]];
    leftBtn.tintColor=[UIColor redColor];
    self.navigationItem.leftBarButtonItem=leftBtn;
}
-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _cityArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId=@"cell";
    _cell=[tableView dequeueReusableCellWithIdentifier:cellId];
    if (_cell==nil) {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    NSString *text=_cityArray[indexPath.row];
    _cell.textLabel.text=text;
    return _cell;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return @"城市选择";
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *text=_cityArray[indexPath.row];
    _cell.textLabel.text=text;
    [self.delegate changeValue:text];
    [self.navigationController popViewControllerAnimated:YES];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
}
@end
