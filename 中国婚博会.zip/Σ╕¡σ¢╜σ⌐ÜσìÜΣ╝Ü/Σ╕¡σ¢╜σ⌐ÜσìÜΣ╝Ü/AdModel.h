//
//  AdModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AdModel : NSObject
@property(nonatomic,strong)NSString *imgUrl;
@property(nonatomic,strong)NSString *link;
@end
