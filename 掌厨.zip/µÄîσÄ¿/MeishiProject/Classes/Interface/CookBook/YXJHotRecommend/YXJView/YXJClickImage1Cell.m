//
//  YXJClickImage1Cell.m
//  MeishiProject
//
//  Created by Yang on 15/11/27.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJClickImage1Cell.h"
#import "UIImageView+WebCache.h"
#import "YXJClickImage1Model.h"
#import "Header.h"
#import <objc/runtime.h>


@interface YXJClickImage1Cell ()<UIScrollViewDelegate>

@property (nonatomic, strong) UIScrollView *m_scrollView;

@property (nonatomic, strong) UIView *m_v1;

@property (nonatomic, strong) UIView *m_v2;

@property (nonatomic, strong) UIView *m_v3;

@property (nonatomic, strong) UIView *m_v4;

@end

@implementation YXJClickImage1Cell

+ (instancetype)yxjClickImage1Cell:(UITableView *)tableView
{
    static NSString *ID = @"ce";
    YXJClickImage1Cell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"YXJClickImage1Cell" owner:self options:nil]firstObject];
    }
    return cell;
}


//scrollView滑动范围方法
- (void)setScrollViewX:(CGFloat)x
{
    [self.m_scrollView setContentOffset:CGPointMake(x, 0) animated:YES];
}



#pragma mark - UIScrollViewDelegate
// 手势滑动视图减速完成后调用方法
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [UIView animateWithDuration:0.3 animations:^{
        NSInteger i = self.m_scrollView.contentOffset.x / screenWidth;
        self.m_slideView1.frame = CGRectMake((screenWidth/4)*i, 40, screenWidth/4, 5);
    }];
}




//点击热门图片1进入之后的(做法)加载数据
- (void)setM_practiceArray:(NSMutableArray *)m_practiceArray
{
    _m_practiceArray = m_practiceArray;
    
    [self.m_scrollView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)]; //////////6
    [self.m_scrollView removeFromSuperview];/////////////////7
    
    self.m_scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 2100)];
    self.m_scrollView.delegate = self;
    self.m_scrollView.pagingEnabled = YES;
    self.m_scrollView.contentSize = CGSizeMake (screenWidth * 4, 0);
    [self addSubview:self.m_scrollView];
    
    UIView *v1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 2100)];
    self.m_v1 = v1;
    [self.m_scrollView addSubview:self.m_v1];
    
    UIView *v2 = [[UIView alloc] initWithFrame:CGRectMake(screenWidth, 0, screenWidth, 2100)];
    self.m_v2 = v2;
    [self.m_scrollView addSubview:self.m_v2];
    
    UIView *v3 = [[UIView alloc] initWithFrame:CGRectMake(screenWidth * 2, 0, screenWidth, 2100)];
    self.m_v3 = v3;
    [self.m_scrollView addSubview:self.m_v3];
    
    UIView *v4 = [[UIView alloc] initWithFrame:CGRectMake(screenWidth * 3, 0, screenWidth, 2100)];
    self.m_v4 = v4;
    [self.m_scrollView addSubview:self.m_v4];
    
    for (NSInteger i=0; i<_m_practiceArray.count; i++)
    {
        YXJClickImage1Model *model = _m_practiceArray[i];
        //内容描述
        UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(10,i*235+170, screenWidth-40, 50)];
        label1.numberOfLines = 2;
        label1.alpha = 0.7;
        label1.font = [UIFont systemFontOfSize:15];
        NSString *string = [NSString stringWithFormat:@"%@ %@",model.m_practiceNumber,model.m_practiceDesc];
        //设置某一范围的字体颜色
        NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:string];
        [str addAttribute:NSForegroundColorAttributeName value:[UIColor orangeColor] range:NSMakeRange(0, 1)];
        label1.attributedText = str;
        [self.m_v1 addSubview:label1];
        
        UIImageView *image = [[UIImageView alloc] initWithFrame:CGRectMake(10, i*235, screenWidth-20, 170)];
        [image sd_setImageWithURL:[NSURL URLWithString:model.m_practiceImage]];
        [self.m_v1 addSubview:image];
        
        UIView *fenGeView = [[UIView alloc] initWithFrame:CGRectMake(0, i*235+220, screenWidth, 10)];
        fenGeView.alpha = 0.3;
        fenGeView.backgroundColor = [UIColor grayColor];
        [self.m_v1 addSubview:fenGeView];
        
    }
    
}


//点击热门图片1进入之后的(食材)加载数据
- (void)setM_1materialArray:(NSMutableArray *)m_1materialArray
{
    _m_1materialArray = m_1materialArray;
    
    for (int i = 0; i<_m_1materialArray.count; i++)
    {
        YXJClickImage1Model *model1 = _m_1materialArray[i];
        //食材头部图片
        UIImageView *image = [[UIImageView alloc] initWithFrame:CGRectMake(10, 0, screenWidth-20, 250)];
        [image sd_setImageWithURL:[NSURL URLWithString:model1.m_material_image]];
        [self.m_v2 addSubview:image];
        //菜名
        UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(10,i*20+250, screenWidth-110, 20)];
        label1.numberOfLines = 2;
        label1.text = model1.m_material_name;
        [self.m_v2 addSubview:label1];
        //多少克
        UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(screenWidth-100,i*20+230, 80, 60)];
        label2.numberOfLines = 2;
        label2.textAlignment = NSTextAlignmentRight;
        label2.text = model1.m_material_weight;
        [self.m_v2 addSubview:label2];
        
        for (int j = 0; j < _count; j++) {
            //食材分割线
            UIView *jianGeview1 = [[UIView alloc] initWithFrame:CGRectMake(0,j*40+300, screenWidth, 0.5)];
            jianGeview1.backgroundColor = [UIColor lightGrayColor];
            [self.m_v2 addSubview:jianGeview1];
        }
//        //图片分割线
//        UIView *jianGeview2 = [[UIView alloc] initWithFrame:CGRectMake(0,260+i*220+self.m_caiMingCount*40, screenWidth, 10)];
//        jianGeview2.backgroundColor = [UIColor lightGrayColor];
//        jianGeview2.alpha = 0.3;
//        [self.m_v2 addSubview:jianGeview2];

        
//        if (model1.m_footTitle != nil)
//        {   //尾部标题
//            UILabel *footTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, titleLabelIndex*236+450+ _count * 38, 100, 50)];
//            titleLabelIndex ++;
//            footTitleLabel.textColor = [UIColor orangeColor];
//            footTitleLabel.text = model1.m_footTitle;
//            [self.m_v2 addSubview:footTitleLabel];
//        }
    }
    
}


//点击热门图片1进入之后的(食材)尾部加载数据
- (void)setM_footArr:(NSMutableArray *)m_footArr
{
    _m_footArr = m_footArr;
    for (int i = 0; i<_m_footArr.count; i++) {
    YXJClickImage1Model *footModel = _m_footArr[i];
    //图片分割线
    UIView *jianGeview2 = [[UIView alloc] initWithFrame:CGRectMake(0,260+i*220+self.m_caiMingCount*40, screenWidth, 10)];
    jianGeview2.backgroundColor = [UIColor lightGrayColor];
    jianGeview2.alpha = 0.3;
    [self.m_v2 addSubview:jianGeview2];
    //尾部图片
    UIImageView *footImage = [[UIImageView alloc] initWithFrame:CGRectMake(10,275+i*220+self.m_caiMingCount*40, screenWidth-20, 200)];
    [footImage sd_setImageWithURL:[NSURL URLWithString:footModel.m_footImage]];
    [self.m_v2 addSubview:footImage];
        
    //尾部标题
    UILabel *footTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(15,435+i*220+self.m_caiMingCount*40, 200, 50)];
    footTitleLabel.textColor = [UIColor orangeColor];
    footTitleLabel.text = footModel.m_footTitle;
    [self.m_v2 addSubview:footTitleLabel];
    }
}



//点击热门图片1进入之后的(相关常识)加载数据
- (void)setM_1commonSenseArray:(NSMutableArray *)m_1commonSenseArray
{
    _m_1commonSenseArray = m_1commonSenseArray;
    
    for (int i = 0; i<_m_1commonSenseArray.count; i++)
    {
        YXJClickImage1Model *commonSenseModel = _m_1commonSenseArray[i];
         UIImageView *Image = [[UIImageView alloc] initWithFrame:CGRectMake(10,0, screenWidth-20, 200)];
        [Image sd_setImageWithURL:[NSURL URLWithString:commonSenseModel.m_commonSenseImage]];
        [self.m_v3 addSubview:Image];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 240, screenWidth-20, 10)];
        label.text = @"相关常识";
        [self.m_v3 addSubview:label];
        
        UILabel *label3 = [[UILabel alloc] init];
        label3.numberOfLines = 0;
        label3.alpha = 0.5;
        label3.text = commonSenseModel.m_commonSenseTitle;
        CGRect l3Rect = [label3.text boundingRectWithSize:CGSizeMake(screenWidth-20, 1000) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]} context:nil];
        label3.frame = CGRectMake(10, 265, screenWidth - 20, l3Rect.size.height);
        [self.m_v3 addSubview:label3];
        
        UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(label3.frame) + 30, screenWidth-20, 10)];
        label2.text = @"制作指导";
        [self.m_v3 addSubview:label2];
        
        UILabel *label4 = [[UILabel alloc] init];
        label4.numberOfLines = 0;
        label4.alpha = 0.5;
        label4.font = [UIFont systemFontOfSize:16];
        label4.text = commonSenseModel.m_commonSenseDisc;
        CGRect l4Rect = [commonSenseModel.m_commonSenseDisc boundingRectWithSize:CGSizeMake(screenWidth-20, 1000) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:label4.font} context:nil];
        label4.frame = CGRectMake(10, CGRectGetMaxY(label2.frame) + 15, screenWidth - 20, l4Rect.size.height);
        [self.m_v3 addSubview:label4];
        
        UIView *FGView = [[UIView alloc] initWithFrame:CGRectMake(0, 210, screenWidth, 10)];
        FGView.backgroundColor = [UIColor grayColor];
        FGView.alpha = 0.3;
        [self.m_v3 addSubview:FGView];
        
        UIView *FGView2 = [[UIView alloc] initWithFrame:CGRectMake(0, 270 + l3Rect.size.height, screenWidth, 10)];
        FGView2.backgroundColor = [UIColor grayColor];
        FGView2.alpha = 0.3;
        [self.m_v3 addSubview:FGView2];
    }
}



//点击热门图片1进入之后的(相宜相克)加载数据
- (void) setM_1xiangKeArray:(NSMutableArray *)m_1xiangKeArray
{
    _m_1xiangKeArray = m_1xiangKeArray;
    
    for (int i = 0; i < _m_1xiangKeArray.count; i++)
    {
         YXJClickImage1Model *model4 = _m_1xiangKeArray[i];

        if (i == 0)
        {
            //头部图片
            UIImageView *imageV = [[UIImageView alloc] initWithFrame:CGRectMake(10,0, screenWidth-20, 200)];
            [imageV sd_setImageWithURL:[NSURL URLWithString:model4.m_xiangkeHeaderImage]];
            [self.m_v4 addSubview:imageV];
            
            UILabel *titleLabel  = [[UILabel alloc] initWithFrame:CGRectMake(80, 240, screenWidth-20, 10)];
            //设置某一范围的字体颜色
            NSString *string = [NSString stringWithFormat:@"与%@搭配相宜的食材",model4.m_xiangKeMainName];
            NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:string];
            [str addAttribute:NSForegroundColorAttributeName value:[UIColor greenColor] range:NSMakeRange(5, 2)];
            titleLabel.attributedText = str;
            [self.m_v4 addSubview:titleLabel];
            
            UILabel *titleLabel2  = [[UILabel alloc] initWithFrame:CGRectMake(80, 420, screenWidth-20, 10)];
            //设置某一范围的字体颜色
            NSString *string2 = [NSString stringWithFormat:@"与%@搭配相克的食材",model4.m_xiangKeMainName];
            NSMutableAttributedString *str2 = [[NSMutableAttributedString alloc] initWithString:string2];
            [str2 addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(5, 2)];
            titleLabel2.attributedText = str2;
            [self.m_v4 addSubview:titleLabel2];
            
        }
        else if ( i == 1)
        {
            //尾部图片
            UIImageView * fourImageV1 = [[UIImageView alloc] initWithFrame:CGRectMake(10,260, 60, 60)];
            [fourImageV1 sd_setImageWithURL:[NSURL URLWithString:model4.m_xiangKeImage1]];
            [self.m_v4 addSubview:fourImageV1];
            
            UILabel *labelTitle1 = [[UILabel alloc] initWithFrame:CGRectMake(80, 270, 100, 20)];
            labelTitle1.text = model4.m_xiangKeName1;
            [self.m_v4 addSubview:labelTitle1];
            
            UILabel *labelDesc1 = [[UILabel alloc] initWithFrame:CGRectMake(80, 295, 290, 20)];
            labelDesc1.alpha = 0.6;
            labelDesc1.font = [UIFont systemFontOfSize:16];
            labelDesc1.text = model4.m_xiangKeDesc1;
            [self.m_v4 addSubview:labelDesc1];
        }
        else if ( i == 2)
        {
            //尾部图片
            UIImageView * fourImageV2 = [[UIImageView alloc] initWithFrame:CGRectMake(10,330, 60, 60)];
            [fourImageV2 sd_setImageWithURL:[NSURL URLWithString:model4.m_xiangKeImage1]];
            [self.m_v4 addSubview:fourImageV2];
            
            UILabel *labelTitle2 = [[UILabel alloc] initWithFrame:CGRectMake(80, 340, 100, 20)];
            labelTitle2.text = model4.m_xiangKeName1;
            [self.m_v4 addSubview:labelTitle2];
            
            UILabel *labelDesc2 = [[UILabel alloc] initWithFrame:CGRectMake(80, 365, 260, 20)];
            labelDesc2.alpha = 0.6;
            labelDesc2.font = [UIFont systemFontOfSize:16];
            labelDesc2.text = model4.m_xiangKeDesc1;
            [self.m_v4 addSubview:labelDesc2];
        }
        else if ( i == 3)
        {
            //尾部图片
            UIImageView * fourImageV3 = [[UIImageView alloc] initWithFrame:CGRectMake(10,440, 60, 60)];
            [fourImageV3 sd_setImageWithURL:[NSURL URLWithString:model4.m_xiangKeImage1]];
            [self.m_v4 addSubview:fourImageV3];
            
            UILabel *labelTitle3 = [[UILabel alloc] initWithFrame:CGRectMake(80, 450, 100, 20)];
            labelTitle3.text = model4.m_xiangKeName1;
            [self.m_v4 addSubview:labelTitle3];
            
            UILabel *labelDesc3 = [[UILabel alloc] initWithFrame:CGRectMake(80, 475, 260, 20)];
            labelDesc3.alpha = 0.6;
            labelDesc3.font = [UIFont systemFontOfSize:16];
            labelDesc3.text = model4.m_xiangKeDesc1;
            [self.m_v4 addSubview:labelDesc3];
        }
        else if ( i == 4)
        {
            //尾部图片
            UIImageView * fourImageV4 = [[UIImageView alloc] initWithFrame:CGRectMake(10,510, 60, 60)];
            [fourImageV4 sd_setImageWithURL:[NSURL URLWithString:model4.m_xiangKeImage1]];
            [self.m_v4 addSubview:fourImageV4];
            
            UILabel *labelTitle4 = [[UILabel alloc] initWithFrame:CGRectMake(80, 520, 100, 20)];
            labelTitle4.text = model4.m_xiangKeName1;
            [self.m_v4 addSubview:labelTitle4];
            
            UILabel *labelDesc4 = [[UILabel alloc] initWithFrame:CGRectMake(80, 545, 260, 20)];
            labelDesc4.alpha = 0.6;
            labelDesc4.font = [UIFont systemFontOfSize:16];
            labelDesc4.text = model4.m_xiangKeDesc1;
            [self.m_v4 addSubview:labelDesc4];
        }
        
        UIView *FGView = [[UIView alloc] initWithFrame:CGRectMake(0,i*180+210, screenWidth, 10)];
        FGView.backgroundColor = [UIColor grayColor];
        FGView.alpha = 0.3;
        [self.m_v4 addSubview:FGView];
    }
  
}




@end
