//
//  NewsCell.h
//  MeishiProject
//
//  Created by Yang on 15/11/8.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NewModel;

@class NewsCell;
@protocol NewsCellDelegate <NSObject>

@optional
- (void)newsCellDidClickPlay:(NewsCell *)cell;

@end


@interface NewsCell : UITableViewCell


@property (nonatomic,strong) NewModel *Model;

+ (instancetype)cellWithTabelView:(UITableView *)tableView;

@property (nonatomic, weak) id<NewsCellDelegate>delegate;


@end
