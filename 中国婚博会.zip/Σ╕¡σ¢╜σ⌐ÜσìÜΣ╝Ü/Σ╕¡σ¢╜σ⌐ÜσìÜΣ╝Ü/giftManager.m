//
//  giftManager.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import "giftManager.h"
#import "AFNetworking.h"
#import "tehuiModel.h"
#import "xianJinModel.h"
#import "shangpinleibie2Model.h"
#import "mouthModel.h"
NSString *giftManagerRefreshNotify = @"giftManagerRefreshNotify";
static giftManager *manager=nil;
@implementation giftManager
+(instancetype)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager=[[[self class]alloc]init];
        }
    });
    return manager;
}
-(void)loadInternetData{
    [self loadqingcangData];
    [self loadxianJinData];
    [self loadshangpinleibieData];
    [self loadmouthData];
}
-(void)loadqingcangData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:giftUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"banner"];
        for (NSDictionary *dic in array) {
            tehuiModel *model=[[tehuiModel alloc]init];
            model.imgurl=dic[@"img_url"];
            if (!_tehuiModels) {
                _tehuiModels=[NSMutableArray array];
            }
            [self.tehuiModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:giftManagerRefreshNotify object:@(10)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
        [alertView show];
        [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
    }];
}
-(void)loadxianJinData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:giftUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"coupon"];
        for (NSDictionary *dic in array) {
            xianJinModel *model=[[xianJinModel alloc]init];
            model.imgurl=dic[@"img_url"];
            if (!_xianJinModels) {
                _xianJinModels=[NSMutableArray array];
            }
            [self.xianJinModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:giftManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadshangpinleibieData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:giftUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"shangpinleibie"];
        for (NSDictionary *dic in array) {
            shangpinleibie2Model *model=[[shangpinleibie2Model alloc]init];
            model.title=dic[@"title"];
            model.img_url=dic[@"img_url"];
            if (!_shangpinleibie2Models) {
                _shangpinleibie2Models=[NSMutableArray array];
            }
            [self.shangpinleibie2Models addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:giftManagerRefreshNotify object:@(2)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
-(void)loadmouthData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:giftUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"ranking"];
        for (NSDictionary *dic in array) {
            mouthModel *model=[[mouthModel alloc]init];
            model.store_name=dic[@"store_name"];
            model.average_price=dic[@"average_price"];
            model.logo=dic[@"logo"];
            if (!_mouthModels) {
                _mouthModels=[NSMutableArray array];
            }
            [self.mouthModels addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:giftManagerRefreshNotify object:@(4)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)     {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
