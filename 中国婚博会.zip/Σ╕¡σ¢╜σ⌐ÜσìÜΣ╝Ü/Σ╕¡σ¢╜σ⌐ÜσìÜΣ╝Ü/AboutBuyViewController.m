//
//  AboutBuyViewController.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/10.
//  Copyright © 2015年 a. All rights reserved.
//

#import "AboutBuyViewController.h"
#import "RightViewController.h"
#import "AboutBuyCell.h"
#import "InfoManager.h"
#import "GuizeCell.h"
#import "KxMenu.h"
#import "noticeViewController.h"
#import "personalViewController.h"
@interface AboutBuyViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation AboutBuyViewController{
    UIButton *_btn1;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    UIView *smallView=[[UIView alloc]initWithFrame:CGRectMake(0,0,ScreenWidth, 50)];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(110,0, 110,50)];
    label.text=@"关于结婚订购";
    label.textColor=[UIColor whiteColor];
    [smallView addSubview:label];
    
    UIBarButtonItem *leftBtn=[[UIBarButtonItem alloc]initWithTitle:@"<" style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    leftBtn.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=leftBtn;
    
    _btn1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _btn1.frame = CGRectMake(260,0, 100, 50);
    [_btn1 setImage:[UIImage imageNamed:@"a02"] forState:UIControlStateNormal];
    _btn1.tintColor=[UIColor whiteColor];
    [_btn1 addTarget:self action:@selector(showMenu:) forControlEvents:UIControlEventTouchUpInside];
    [smallView addSubview:_btn1];
    [self.navigationItem.titleView sizeToFit];
    self.navigationItem.titleView=smallView;

    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(notify:) name:InfoManagerRefreshNotify object:nil];
    [[InfoManager shareInstance]loadInternetData];
    [self registerCell];
}
- (void)notify:(NSNotification *)note
{
    NSInteger section = [note.object integerValue];
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationAutomatic];
}
-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)danji2{
    
}
-(void)registerCell{
    [self.tableView registerNib:[UINib nibWithNibName:@"AboutBuyCell" bundle:nil] forCellReuseIdentifier:@"AboutBuyCell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"GuizeCell" bundle:nil] forCellReuseIdentifier:@"GuizeCell"];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==0) {
        return 1;
    }
    return 6;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        AboutBuyCell *cell=[tableView dequeueReusableCellWithIdentifier:@"AboutBuyCell"];
        [cell configCellWithAboutBuyModels:[InfoManager shareInstance].AboutBuyModels];
        return cell;
    }
    else{
        GuizeCell *cell=[tableView dequeueReusableCellWithIdentifier:@"GuizeCell"];
        [cell configCellWithGuizeModels:[InfoManager shareInstance].GuizeModels cellForRowAtIndexPath:indexPath];
        return cell;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 200;
    }
    return 60;
}
- (void) viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    _btn1.frame = CGRectMake(260, 0, 100, 50);
}
- (void)showMenu:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      
      [KxMenuItem menuItem:@"首页"
                     image:[UIImage imageNamed:@"home_normal_icon"]
                    target:self
                    action:@selector(pushMenuItem:)],
      
      [KxMenuItem menuItem:@"我的通信"
                     image:[UIImage imageNamed:@"my_notice_icon"]
                    target:self
                    action:@selector(pushMenuItem2:)],
      
      [KxMenuItem menuItem:@"我的私信"
                     image:[UIImage imageNamed:@"my_personal_letter_icon"]
                    target:self
                    action:@selector(pushMenuItem3:)],
      ];
    
    KxMenuItem *first = menuItems[0];
    first.foreColor = [UIColor colorWithRed:47/255.0f green:112/255.0f blue:225/255.0f alpha:1.0];
    first.alignment = NSTextAlignmentCenter;
    
    [KxMenu showMenuInView:self.view
                  fromRect:sender.frame
                 menuItems:menuItems];
}
- (void) pushMenuItem:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void) pushMenuItem2:(id)sender
{
    noticeViewController *noCtl=[[noticeViewController alloc]init];
    [self.navigationController pushViewController:noCtl animated:YES];
}
- (void) pushMenuItem3:(id)sender
{
    personalViewController *personalCtl=[[personalViewController alloc]init];
    [self.navigationController pushViewController:personalCtl animated:YES];
}

@end
