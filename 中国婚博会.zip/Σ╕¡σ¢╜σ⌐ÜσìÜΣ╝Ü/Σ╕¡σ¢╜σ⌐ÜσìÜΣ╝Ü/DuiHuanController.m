//
//  DuiHuanController.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/11.
//  Copyright © 2015年 a. All rights reserved.
//

#import "DuiHuanController.h"
#import "MJRefresh.h"
#import "KxMenu.h"
#import "noticeViewController.h"
#import "personalViewController.h"
#import "welfaceManager.h"
#import "detailController.h"

#import "DuiHuanCell.h"
@interface DuiHuanController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation DuiHuanController{
    UIButton *_btn1;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    UIView *smallView=[[UIView alloc]initWithFrame:CGRectMake(0,0,ScreenWidth, 50)];
    [self.navigationController.navigationBar setBarTintColor:RGBColor(200, 58, 52)];
    
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(110,0, 100,50)];
    label.text=@"礼品兑换";
    label.textColor=[UIColor whiteColor];
    [smallView addSubview:label];
    
    UIBarButtonItem *leftBtn=[[UIBarButtonItem alloc]initWithTitle:@"<" style:UIBarButtonItemStyleDone target:self action:@selector(danji)];
    leftBtn.tintColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=leftBtn;
    
    _btn1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    _btn1.frame = CGRectMake(280,15, 30, 20);
    [_btn1 setImage:[UIImage imageNamed:@"home_enum_icon2"] forState:UIControlStateNormal];
    _btn1.tintColor=[UIColor whiteColor];
    [_btn1 addTarget:self action:@selector(showMenu:) forControlEvents:UIControlEventTouchUpInside];
    [smallView addSubview:_btn1];
    [self.navigationItem.titleView sizeToFit];
    self.navigationItem.titleView=smallView;
    
    [[welfaceManager shareInstance]loadInternetData];
    MJRefreshGifHeader *header=[MJRefreshGifHeader headerWithRefreshingBlock:^{
        [self.tableView reloadData];
        [self.tableView.header endRefreshing];
    }];
    
    NSArray *images=@[[UIImage imageNamed:@"pullto_center_icon"]];
    
    [header setImages:images forState:MJRefreshStateRefreshing];
    
    self.tableView.header=header;
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(notify:) name:welfaceManagerRefreshNotify object:nil];
    [self registerCell];
}
-(void)danji{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)notify:(NSNotification *)note
{
    NSInteger section = [note.object integerValue];
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.tableView.header endRefreshing];
}

-(void)registerCell{
    [self.tableView registerNib:[UINib nibWithNibName:@"DuiHuanCell" bundle:nil] forCellReuseIdentifier:@"DuiHuanCell"];
}
- (void)showMenu:(UIButton *)sender
{
    NSArray *menuItems =
    @[
      
      [KxMenuItem menuItem:@"首页"
                     image:[UIImage imageNamed:@"home_normal_icon"]
                    target:self
                    action:@selector(pushMenuItem:)],
      
      [KxMenuItem menuItem:@"我的通信"
                     image:[UIImage imageNamed:@"my_notice_icon"]
                    target:self
                    action:@selector(pushMenuItem2:)],
      
      [KxMenuItem menuItem:@"我的私信"
                     image:[UIImage imageNamed:@"my_personal_letter_icon"]
                    target:self
                    action:@selector(pushMenuItem3:)],
      ];
    
    KxMenuItem *first = menuItems[0];
    first.foreColor = [UIColor colorWithRed:47/255.0f green:112/255.0f blue:225/255.0f alpha:1.0];
    first.alignment = NSTextAlignmentCenter;
    
    [KxMenu showMenuInView:self.view
                  fromRect:sender.frame
                 menuItems:menuItems];
}
- (void) pushMenuItem:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void) pushMenuItem2:(id)sender
{
    noticeViewController *noCtl=[[noticeViewController alloc]init];
    [self.navigationController pushViewController:noCtl animated:YES];
}
- (void) pushMenuItem3:(id)sender
{
    personalViewController *personalCtl=[[personalViewController alloc]init];
    [self.navigationController pushViewController:personalCtl animated:YES];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [welfaceManager shareInstance].DuiHuanModels.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    DuiHuanCell *cell=[tableView dequeueReusableCellWithIdentifier:@"DuiHuanCell"];
    [cell configCellWithDuiHuanModels:[welfaceManager shareInstance].DuiHuanModels cellForRowAtIndexPath:indexPath];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 120;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    detailController *detailCtl=[[detailController alloc]init];
    [detailCtl setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:detailCtl animated:YES];
}
@end
