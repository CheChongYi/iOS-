//
//  enterSearchCell.h
//  MeishiProject
//
//  Created by Yang on 15/12/10.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>


@class enterSearchModel;

@interface enterSearchCell : UITableViewCell


@property (nonatomic, strong) enterSearchModel *m_model;

+ (instancetype)cellWithTabelView: (UITableView *)tabelView;


@end
