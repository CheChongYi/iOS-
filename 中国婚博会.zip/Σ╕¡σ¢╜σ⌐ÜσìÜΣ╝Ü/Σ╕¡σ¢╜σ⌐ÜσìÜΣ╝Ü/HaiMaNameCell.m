//
//  HaiMaNameCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/4.
//  Copyright © 2015年 a. All rights reserved.
//

#import "HaiMaNameCell.h"
#import "HaiMaNameModel.h"
@implementation HaiMaNameCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithHaiMaNameModels:(NSArray *)HaiMaNameModels{
    HaiMaNameModel *model=HaiMaNameModels[0];
    _titleLabel.text=model.product_name;
    _priceLabel.text=[NSString stringWithFormat:@"￥%@",model.mall_price];
}
@end
