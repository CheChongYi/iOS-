//
//  YXJCollectionViewCell.m
//  MeishiProject
//
//  Created by Yang on 15/12/16.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJCollectionViewCell.h"
#import "UIImageView+WebCache.h"
#import "FoodClassModel.h"


@interface YXJCollectionViewCell ()


@property (weak, nonatomic) IBOutlet UIImageView *image;

@end

@implementation YXJCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}


- (void)setCollectionModel:(FoodClassModel *)collectionModel
{
    _collectionModel = collectionModel;
    
    [self.image sd_setImageWithURL:[NSURL URLWithString:_collectionModel.banner_picture]];
}


@end
