//
//  YXJBakeModel.h
//  MeishiProject
//
//  Created by Yang on 15/11/16.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YXJBakeModel : NSObject


@property (nonatomic, copy) NSString *m_bakeTitle;

@property (nonatomic, copy) NSString *m_bakeDescription;

@property (nonatomic, copy) NSString *m_bakeImage;

@property (nonatomic, copy) NSString *m_bakeVideo;

@property (nonatomic, copy) NSString *m_bakeVideo1;

@property (nonatomic, copy) NSString *m_content;

@property (nonatomic, copy) NSString *m_cooking_time;

@property (nonatomic, copy) NSString *m_hard_level;

@property (nonatomic, copy) NSString *m_taste;

@property (nonatomic, copy) NSString *m_dishes_id;



@end
