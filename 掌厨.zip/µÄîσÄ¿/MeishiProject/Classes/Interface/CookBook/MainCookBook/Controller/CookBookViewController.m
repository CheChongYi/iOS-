//
//  CookBookViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/2.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "CookBookViewController.h"
#import "YXJNoviceEntryViewController.h"
#import "YXJSteamViewController.h"
#import "YXJOutdoorFoodViewController.h"
#import "YXJTwoPersonWorldViewController.h"
#import "YXJBreakfastViewController.h"
#import "YXJLunchViewController.h"
#import "YXJDinnerViewController.h"
#import "YXJOneTopViewController.h"
#import "YXJTwoTopViewController.h"
#import "YXJThreeTopViewController.h"
#import "YXJBakeViewController.h"
#import "YXJSpecialTopicViewController.h"
#import "YXJTwoSpecialViewController.h"
#import "YXJClickImage1Controller.h"
#import "YXJHotMoreViewController.h"
#import "YXJEnterMoreViewController.h"
#import "LoginViewController.h"
#import "Header.h"
#import "ScrollViewCell.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "CookBookModel.h"
#import "HotCell.h"
#import "specialModel.h"
#import "specialCell.h"
#import "rankingCell.h"
#import "rangKingModel.h"
#import "NewsCell.h"
#import "NewModel.h"
#import "SearchViewController.h"
#import "RootViewController.h"

@import MediaPlayer;


@interface CookBookViewController ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate, HotCellDelegate,rankingCellDelegate,NewsCellDelegate,ScrollViewCellDelegate,specialCellDelegate>
{
        UIScrollView *m_scrollView;
        UIPageControl *m_pageControl;
        NSTimer *_timer;
}


@property (nonatomic, strong) UITableView *m_tabelView;
@property (nonatomic, strong) NSMutableArray *m_topImageArray;
@property (nonatomic, strong) NSMutableArray *m_BtndataArray;
@property (nonatomic, strong) NSMutableArray *m_HotArray;
@property (nonatomic, strong) NSMutableArray *m_newsArray;
@property (nonatomic, strong) NSMutableArray *m_specialArray;
@property (nonatomic, strong) NSMutableArray *m_rangKingArray;


@end


@implementation CookBookViewController

//当另一个控制器返回时,不要隐藏导航栏
- (void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = NO;
}


- (void)viewDidLoad
{
    [super viewDidLoad];

    [self createSearch];
    [self createTableView];
    [self createScrollViewAndPageControl];
    [self createBtnReaquest1];
    [self createReaquest2];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(createScrollViewAndPageControl) name:@"passM_topImageArray" object:nil];
}


- (void)dealloc
{

    [[NSNotificationCenter defaultCenter] removeObserver:self];
}



- (void)createSearch
{
    UISearchBar *searchBar = [[UISearchBar alloc] init];
    searchBar.placeholder = @"输入菜名或食材搜索";
    self.navigationItem.titleView = searchBar;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button.frame = CGRectMake(0, 0, screenWidth, 64);
    [button addTarget:self action:@selector(Btn) forControlEvents:UIControlEventTouchDown];
    [searchBar addSubview:button];

    UIBarButtonItem *leftBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"shaoyishao.png"] style:UIBarButtonItemStyleDone target:self action:@selector(pushRootVC)];
    leftBtn.tintColor = [UIColor whiteColor];
    self.navigationItem.leftBarButtonItem = leftBtn;
    
    UIBarButtonItem *rightBtn = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"xiaoxi.png"]style:UIBarButtonItemStyleDone target:self action:@selector(presentLoginViewController)];
    rightBtn.tintColor = [UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = rightBtn;
}


#pragma mark - 点击二维码跳转界面
- (void)pushRootVC
{
    RootViewController *rootVC = [[RootViewController alloc] init];
    [rootVC setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:rootVC animated:YES];
}


#pragma mark - 点击搜索栏跳转到搜索界面
- (void)Btn
{
    SearchViewController *searchVC = [[SearchViewController alloc] init];
    [searchVC setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:searchVC animated:YES];
}


#pragma mark - 点击右上角信息跳转到登陆界面
- (void)presentLoginViewController
{
    LoginViewController *loginVC = [[LoginViewController alloc] init];
    [self presentViewController:loginVC animated:YES completion:nil];
}


- (void)createTableView
{
    if (nil == self.m_tabelView)
    {
        self.m_tabelView = [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStyleGrouped];
        self.m_tabelView.delegate = self;
        self.m_tabelView.dataSource = self;
        //把一个组的分割线隐身
        self.m_tabelView.separatorStyle = NO;
        [self.view addSubview:self.m_tabelView];
    }
    
}



- (void)createScrollViewAndPageControl
{
     //设置导航栏的颜色
    [self.navigationController.navigationBar setBarTintColor:RGBColor(255, 122, 68)];
    
    m_scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, 150)];
    //分页属性
    m_scrollView.pagingEnabled = YES;
    //手动滑动时候的区域
    m_scrollView.contentSize = CGSizeMake(screenWidth*3, 0);
    m_scrollView.delegate = self;
    
    m_pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(300, 100, 0, 50)];
    m_pageControl.numberOfPages = 3;
    //小圆点当前颜色
    m_pageControl.currentPageIndicatorTintColor = [UIColor orangeColor];
    //小圆点颜色
    m_pageControl.pageIndicatorTintColor = [UIColor whiteColor];
    [self.m_tabelView addSubview:m_pageControl];
    for (NSInteger i=0; i<self.m_topImageArray.count; i++)
    {
        UIImageView *img = [[UIImageView alloc]initWithFrame:CGRectMake(screenWidth*i, 0, screenWidth, 150)];
        CookBookModel *imageMod = self.m_topImageArray[i];
        [img sd_setImageWithURL:[NSURL URLWithString:imageMod.banner_picture]];
        img.tag = i;
        img.userInteractionEnabled = YES;
        [m_scrollView addSubview:img];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapClick:)];
        [img addGestureRecognizer:tap];
    }
    self.m_tabelView.tableHeaderView = m_scrollView;
    //如果定时器在运行
    if ([_timer isValid])
    {
        //关闭计时器
        [_timer invalidate];
        //将计时器的值重新赋为0
        _timer= nil;
    }
    _timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(changeRange) userInfo:nil repeats:YES];
}



- (void)changeRange
{
    
    static int count = 0;   //static作用只初始化一次,保留了上一次数据的结果
    count++;
    [m_scrollView setContentOffset:CGPointMake((count%3)*screenWidth, 0) animated:YES];
}




//#pragma mark - UIScrollViewDelegate 手势滑动结束减速时调用
//- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
//{
//     NSInteger i = m_scrollView.contentOffset.x / screenWidth;
//    [m_scrollView setContentOffset:CGPointMake(i * screenWidth, 0) animated:YES];
//}



- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    NSInteger page =m_scrollView.contentOffset.x / m_scrollView.frame.size.width;
    m_pageControl.currentPage = page;
}




- (void)tapClick:(UIGestureRecognizer *)tap
{
    NSInteger i = tap.view.tag;
    if (i == 0)
    {
        YXJOneTopViewController *oneVC = [[YXJOneTopViewController alloc] init];
        [oneVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:oneVC animated:YES];
    }
    else if (i == 1)
    {
        YXJTwoTopViewController *twoVC = [[YXJTwoTopViewController alloc] init];
        [twoVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:twoVC animated:YES];
    }
    else
    {
        YXJThreeTopViewController *threeVC = [[YXJThreeTopViewController alloc] init];
        [threeVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:threeVC animated:YES];
    }
    
}




#pragma mark - 重写Getter方法
- (NSMutableArray *)m_topImageArray
{
    if (_m_topImageArray == nil)
    {
        _m_topImageArray = [NSMutableArray array];
    }
    return _m_topImageArray;
}



- (NSMutableArray *)m_BtndataArray
{
    if (_m_BtndataArray == nil)
    {
        _m_BtndataArray = [NSMutableArray array];
    }
    
    return _m_BtndataArray;
}


- (NSMutableArray *)m_HotArray
{
    if (_m_HotArray == nil)
    {
        _m_HotArray = [NSMutableArray array];
    }
    return _m_HotArray;
}



- (NSMutableArray *)m_newsArray
{
    if (_m_newsArray == nil)
    {
        _m_newsArray = [NSMutableArray array];
    }
    return _m_newsArray;
}




- (NSMutableArray *)m_specialArray
{
    if (_m_specialArray == nil)
    {
        _m_specialArray = [NSMutableArray array];
    }
    return _m_specialArray;
}



- (NSMutableArray *)m_rangKingArray
{
    if (_m_rangKingArray == nil)
    {
        _m_rangKingArray = [NSMutableArray array];
    }
    return _m_rangKingArray;
}



- (void)createBtnReaquest1
{
    AFHTTPRequestOperationManager *manage = [AFHTTPRequestOperationManager manager];
    manage.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manage GET:BtnUrl parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSData *data = [NSData dataWithData:responseObject];
        NSDictionary *dic1 = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSDictionary *dic2 = dic1[@"data"];
        NSArray *Arr = dic2[@"banner"];
        for (NSDictionary *Dic in Arr)
        {   //头部滑动视图数据
            CookBookModel *imageModel = [[CookBookModel alloc]init];
            imageModel.banner_picture = Dic[@"banner_picture"];
            [self.m_topImageArray addObject:imageModel];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:@"passM_topImageArray" object:nil];
        
        NSArray *arr = dic2[@"navigate"];
        for (NSDictionary *dic3 in arr)
        {   //8个美食栏数据
            CookBookModel *cookModel = [[CookBookModel alloc]init];
            cookModel.text = dic3[@"text"];
            cookModel.image = dic3[@"image"];
            [self.m_BtndataArray addObject: cookModel];
        }
        [self.m_tabelView reloadData];
      
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}




- (void)createReaquest2
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:BtnUrl parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSData *data = [NSData dataWithData:responseObject];
        NSDictionary *Dic1 = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSDictionary *dic2 = Dic1[@"data"];
        NSDictionary *newDic = dic2[@"latest"];
        NSArray *newArr = newDic[@"data"];
        for (NSDictionary *newDic1 in newArr)
        {   //新品数据
            NewModel *newModel = [[NewModel alloc]init];
            newModel.newsTitle = newDic1[@"title"];
            newModel.newsDescription = newDic1[@"description"];
            newModel.newsPlay = newDic1[@"play"];
            newModel.newsImage = newDic1[@"image"];
            newModel.newsVideo = newDic1[@"video"];
            newModel.newsVideo1 = newDic1[@"video1"];
            newModel.newsDishes_id = newDic1[@"dishes_id"];
            newModel.newsContent = newDic1[@"content"];
            [self.m_newsArray addObject:newModel];
        }
        NSArray *arr = dic2[@"data"];
        
        NSDictionary *specialDic = [arr objectAtIndex:1];
        NSArray *specialArr = specialDic[@"data"];
        for (NSDictionary *specialDic in specialArr)
        {   //专题数据
            specialModel *specialMod = [[specialModel alloc] init];
            specialMod.m_specialTitle = specialDic[@"title"];
            specialMod.m_specialID = specialDic[@"dishes_id"];
            [self.m_specialArray addObject:specialMod];
        }
        NSDictionary *rangKingDic = [arr objectAtIndex:2];
        NSArray *rangkingArr = rangKingDic[@"data"];
        for (NSDictionary *rangKingDic2 in rangkingArr)
        {    //排行榜数据
            rangKingModel *rangKingMod = [[rangKingModel alloc] init];
            rangKingMod.m_rangKingImage = rangKingDic2[@"image"];
            rangKingMod.m_rangKingTitle = rangKingDic2[@"title"];
            rangKingMod.m_rangKingContent = rangKingDic2[@"content"];
            rangKingMod.m_rangKingVideo = rangKingDic2[@"video"];
            rangKingMod.m_rangKingVideo1 = rangKingDic2[@"video1"];
            rangKingMod.m_rangKingID = rangKingDic2[@"dishes_id"];
            [self.m_rangKingArray addObject:rangKingMod];
        }
        for (NSDictionary *dic3 in arr)
        {
        NSArray *arr1 = dic3[@"data"];
        for (NSDictionary *dic4 in arr1)
            {   //热门数据
                CookBookModel *model3 = [[CookBookModel alloc]init];
                model3.hotVideo = dic4[@"video"];
                model3.hotVideo1 = dic4[@"video1"];
                model3.hotImage = dic4[@"image"];
                model3.hotTitle = dic4[@"title"];
                model3.hotDescription = dic4[@"description"];
                model3.hotPlay = dic4[@"play"];
                model3.favorite = dic4[@"favorite"];
                model3.dishes_id = dic4[@"dishes_id"];
                model3.m_content = dic4[@"content"];
                [self.m_HotArray addObject:model3];
            }
            [self.m_tabelView reloadData];
        }
        
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error){
        
    }];
}




#pragma mark - UITableViewDelegate 根据组返回头部视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 1)
    {
        UIView *hotView = [[UIView alloc]initWithFrame:CGRectMake(0, 20, screenWidth, 20)];
        hotView.backgroundColor = [UIColor whiteColor];
        
        UIView *upView = [[UIView alloc]initWithFrame:CGRectMake(20, 16, 5, 20)];
        upView.backgroundColor = [UIColor orangeColor];
        [hotView addSubview:upView];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(35, 1, 100, 50)];
        label.text = @"热门推荐";
        label.font = [UIFont systemFontOfSize:20];
        label.textColor = [UIColor orangeColor];
        [hotView addSubview:label];
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.frame = CGRectMake(280, 12, 50, 30);
        [button setTitle:@"更多" forState:UIControlStateNormal];
        button.titleLabel.font = [UIFont systemFontOfSize:17];
        button.tintColor = [UIColor grayColor];
        [button addTarget:self action:@selector(enterYXJHotViewController) forControlEvents:UIControlEventTouchUpInside];
        [hotView addSubview:button];
        
        UIButton *button1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        button1.frame = CGRectMake(320, 15, 40, 25);
        [button1 setBackgroundImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
        [hotView addSubview:button1];
        
        
        return hotView;
    }
    else if (section == 2)
    {
        UIView *hotView = [[UIView alloc]initWithFrame:CGRectMake(0, 20, screenWidth, 20)];
        hotView.backgroundColor = [UIColor whiteColor];
        
        UIView *upView = [[UIView alloc]initWithFrame:CGRectMake(20, 15, 5, 20)];
        upView.backgroundColor = [UIColor orangeColor];
        [hotView addSubview:upView];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(35, 0, 100, 50)];
        label.text = @"专题";
        label.font = [UIFont systemFontOfSize:20];
        label.textColor = [UIColor orangeColor];
        [hotView addSubview:label];
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.frame = CGRectMake(280, 12, 50, 30);
        [button setTitle:@"更多" forState:UIControlStateNormal];
        button.titleLabel.font = [UIFont systemFontOfSize:17];
        button.tintColor = [UIColor grayColor];
        [button addTarget:self action:@selector(enterYXJMoreViewController) forControlEvents:UIControlEventTouchUpInside];
        [hotView addSubview:button];
        
        UIButton *button2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        button2.frame = CGRectMake(320, 15, 40, 25);
        [button2 setBackgroundImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
        [hotView addSubview:button2];
        
        return hotView;
        
    }
    else if (section == 3)
    {
        
        UIView *hotView = [[UIView alloc]initWithFrame:CGRectMake(0, 20, screenWidth, 20)];
        hotView.backgroundColor = [UIColor whiteColor];
        
        UIView *upView = [[UIView alloc]initWithFrame:CGRectMake(20, 15, 5, 20)];
        upView.backgroundColor = [UIColor orangeColor];
        [hotView addSubview:upView];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(35, 0, 100, 50)];
        label.text = @"排行榜";
        label.font = [UIFont systemFontOfSize:20];
        label.textColor = [UIColor orangeColor];
        [hotView addSubview:label];
        
//        UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//        button.frame = CGRectMake(280, 12, 50, 30);
//        [button setTitle:@"更多" forState:UIControlStateNormal];
//        button.titleLabel.font = [UIFont systemFontOfSize:17];
//        button.tintColor = [UIColor grayColor];
//        [hotView addSubview:button];
        
//        UIButton *button3 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//        button3.frame = CGRectMake(320, 15, 40, 25);
//        [button3 setBackgroundImage:[UIImage imageNamed:@"arrow"] forState:UIControlStateNormal];
//        [hotView addSubview:button3];
        
        return hotView;
        
    }
    else if (section == 4)
    {
        
        UIView *hotView = [[UIView alloc]initWithFrame:CGRectMake(0, 20, screenWidth, 20)];
        hotView.backgroundColor = [UIColor whiteColor];
        
        UIView *upView = [[UIView alloc]initWithFrame:CGRectMake(20, 15, 5, 20)];
        upView.backgroundColor = [UIColor orangeColor];
        [hotView addSubview:upView];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(35, 0, 100, 50)];
        label.text = @"新品推荐";
        label.font = [UIFont systemFontOfSize:20];
        label.textColor = [UIColor orangeColor];
        [hotView addSubview:label];
        
        return hotView;
        
    }

    return nil;
}



- (void)enterYXJHotViewController
{
    YXJHotMoreViewController *hotMoreVC = [[YXJHotMoreViewController alloc] init];
    [hotMoreVC setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:hotMoreVC animated:YES];
}



- (void)enterYXJMoreViewController
{
    YXJEnterMoreViewController *moreVC = [[YXJEnterMoreViewController alloc] init];
    [moreVC setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:moreVC animated:YES];
}



#pragma mark - UITableViewDelegate  返回行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        return 180;
    }
    else if (indexPath.section == 1)
    {
        return 200;
    }
    else if (indexPath.section == 2)
    {
        return 400;
    } else if (indexPath.section == 3)
    {
        return 200;
    }
    return 150;
}



//根据组返回头部高度(下标0开始)
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        return 1;
    }
    else if (section == 1)
    {
        return 50;
    }
    else if (section == 2)
    {
        return 50;
    }
    else if (section == 3)
    {
        return 50;
    }
    else if (section == 4)
    {
        return 50;
    }
    return 1;


}



//返回尾部高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 15;
}


#pragma mark - UITableViewDataSource
//返回组数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 5;
}


//从下标0开始计算
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0)
    {
        return 1;
    }
    else if (section == 1)
    {
        return 2;
    }
    else if (section == 2)
    {
        return 1;
    }
    else if (section == 3)
    {
        return 1;
    }
    return self.m_newsArray.count;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        ScrollViewCell *cell = [ScrollViewCell scrollViewCellWithTabelView:tableView];
        cell.BtnArray = self.m_BtndataArray;
        cell.delegate = self;
        return cell;
       
    }
    else if (indexPath.section == 1)
    {
         HotCell *cell = [HotCell cellWithTabelView:tableView];
        if (_m_HotArray != nil)
        {
            CookBookModel *model = self.m_HotArray[indexPath.row];
            cell.hotModel = model;  //hotModel属性,它的类必须是CookBookModel *类

        }
        cell.tag = indexPath.row;
        cell.delegate = self;
        return cell;
        
    }
    else if (indexPath.section == 2)
    {
        specialCell *cell = [specialCell cellWithTabelView:tableView];
        if (_m_HotArray != 0)
        {
            cell.specialCellArray = self.m_HotArray;
        }
        cell.delegate = self;
        return cell;
    }
    else if (indexPath.section == 3)
    {
        rankingCell *cell = [rankingCell cellWithTabelView:tableView];
        if (_m_HotArray != nil)
        {
            cell.rangkingArray = self.m_HotArray;
        }
        cell.delegate = self;
        return cell;
    }
    else
    {
        NewsCell *cell = [NewsCell cellWithTabelView:tableView];
        if (_m_newsArray != nil)
        {
            NewModel *newModel2 = self.m_newsArray[indexPath.row];
            cell.Model = newModel2;
        }
        cell.delegate = self;
         return cell;
    }
    
    
    return nil;
}




#pragma mark - UITableViewDelegate 新品点击图片跳转
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 4)
    {
        YXJClickImage1Controller *newsToClickVC = [[YXJClickImage1Controller alloc] init];
        [self.navigationController pushViewController:newsToClickVC animated:YES];
        NewModel *newsmod = self.m_newsArray[indexPath.row];
        newsToClickVC.m_headImageString = newsmod.newsImage;
        newsToClickVC.m_title = newsmod.newsTitle;
        newsToClickVC.m_content = newsmod.newsContent;
        newsToClickVC.m_video = newsmod.newsVideo;
        newsToClickVC.m_video1 = newsmod.newsVideo1;
        newsToClickVC.m_dishesId = newsmod.newsDishes_id;
    }
}




#pragma mark - HotCellDelegate  热门点击视频播放
- (void)hotCellDidClickPlay:(HotCell *)cell
{
    NSURL *url = [NSURL URLWithString:cell.hotModel.hotVideo];
    MPMoviePlayerViewController *player = [[MPMoviePlayerViewController alloc] initWithContentURL:url];
    [self presentViewController:player animated:YES completion:nil];
}



#pragma mark - HotCellDelegate  热门点击图片跳转
- (void)hotCellDidClickImage:(HotCell *)cell
{
    NSInteger index = cell.tag;  //////111111/////////
    CookBookModel *model = self.m_HotArray[index]; //////////111111/////////
    YXJClickImage1Controller *clickImage = [[YXJClickImage1Controller alloc] init];
    [clickImage setHidesBottomBarWhenPushed:YES];
    clickImage.m_video = model.hotVideo;
    clickImage.m_video1 = model.hotVideo1;
    clickImage.m_dishesId = model.dishes_id;  ///////////111111////////
    clickImage.m_headImageString = model.hotImage;
    clickImage.m_title = model.hotTitle;
    clickImage.m_content = model.m_content;
    [self.navigationController pushViewController:clickImage animated:YES];
}



#pragma mark - rangkingDelegate  排行榜点击视频播放
- (void)rangkingDidPlayVideo:(CookBookModel *)model
{
    NSURL *url = [NSURL URLWithString:model.hotVideo];
    MPMoviePlayerViewController *player = [[MPMoviePlayerViewController alloc]initWithContentURL:url];
    [self presentViewController:player animated:YES completion:nil];
    
}



#pragma mark - rangKingCellDelegate  排行榜点击图片跳转
- (void)rankingCellDidClickImage:(NSInteger)index
{
   
    YXJClickImage1Controller *rangKingToclickImage = [[YXJClickImage1Controller alloc] init];
    [self.navigationController pushViewController:rangKingToclickImage animated:YES];
    rangKingModel *model1 = self.m_rangKingArray[index];
    rangKingToclickImage.m_headImageString = model1.m_rangKingImage;
    rangKingToclickImage.m_title = model1.m_rangKingTitle;
    rangKingToclickImage.m_content = model1.m_rangKingContent;
    rangKingToclickImage.m_video = model1.m_rangKingVideo;
    rangKingToclickImage.m_video1 = model1.m_rangKingVideo1;
    rangKingToclickImage.m_dishesId = model1.m_rangKingID;
}




#pragma mark - NewsCellDelegate  新品点击视频播放
- (void)newsCellDidClickPlay:(NewsCell *)cell
{
    NSURL *url = [NSURL URLWithString:cell.Model.newsVideo];
    MPMoviePlayerViewController *player = [[MPMoviePlayerViewController alloc]initWithContentURL:url];
    [self presentViewController:player animated:YES completion:nil];
}



#pragma mark - ScrollViewCellDelegate 美食菜单跳转
-(void)scrollViewCell:(ScrollViewCell *)cell didClickIndex:(NSInteger)index
{
    if (index == 0)
    {
        YXJNoviceEntryViewController *NoviceEntryVC = [[YXJNoviceEntryViewController alloc] init];
        //push一个控制器，隐藏tabbar
        [NoviceEntryVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:NoviceEntryVC animated:YES];
    }
     else if (index == 1)
    {
        YXJBakeViewController *bakeVC = [[YXJBakeViewController alloc] init];
        //push一个控制器，隐藏tabbar
        [bakeVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:bakeVC animated:YES];
    }
    else if (index == 2)
    {
        YXJSteamViewController *steamVC = [[YXJSteamViewController alloc] init];
        [steamVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:steamVC animated:YES];
    }
    else if (index == 3)
    {
        YXJOutdoorFoodViewController *outDoorVC =[[YXJOutdoorFoodViewController alloc] init];
        [outDoorVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:outDoorVC animated:YES];
    }
    else if (index == 4)
    {
        YXJBreakfastViewController *BreakfastVC =[[YXJBreakfastViewController alloc] init];
        [BreakfastVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:BreakfastVC animated:YES];
    }
    else if (index == 5)
    {
        YXJLunchViewController *LunchVC =[[YXJLunchViewController alloc] init];
        [LunchVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:LunchVC animated:YES];
    }
    else if (index == 6)
    {
        YXJDinnerViewController *DinnerVC =[[YXJDinnerViewController alloc] init];
        [DinnerVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:DinnerVC animated:YES];
    }
    else if (index == 7)
    {
        YXJTwoPersonWorldViewController *twoPersonVC =[[YXJTwoPersonWorldViewController alloc] init];
        [twoPersonVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:twoPersonVC animated:YES];
    }

    
}



#pragma mark - specialCellDelegate  专题跳转
- (void)specialCell:(specialCell *)cell didClickIndex:(NSInteger)index
{
    YXJTwoSpecialViewController *twoVC = [[YXJTwoSpecialViewController alloc] init];
    [twoVC setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:twoVC animated:YES];
    specialModel *model = self.m_specialArray[index];
    twoVC.ID = model.m_specialID;
    twoVC.topTitle = model.m_specialTitle;
}


@end
