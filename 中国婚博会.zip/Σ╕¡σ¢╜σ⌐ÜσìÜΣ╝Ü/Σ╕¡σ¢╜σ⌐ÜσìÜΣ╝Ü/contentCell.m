//
//  contentCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/9.
//  Copyright © 2015年 a. All rights reserved.
//

#import "contentCell.h"
#import "MingRenModel.h"
@implementation contentCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithcontentModels:(NSArray *)contentModels{
    MingRenModel *model=contentModels[0];
    _titleLabel.text=model.summary;
    [_webView loadHTMLString:model.use_notice baseURL:nil];
}
@end
