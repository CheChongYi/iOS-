//
//  YXJModel.m
//  MeishiProject
//
//  Created by Yang on 15/11/20.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "YXJModel.h"

@implementation YXJModel

@end
