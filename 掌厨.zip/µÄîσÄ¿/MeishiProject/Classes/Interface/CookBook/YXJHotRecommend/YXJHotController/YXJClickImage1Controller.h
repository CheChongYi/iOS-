//
//  YXJClickImage1Controller.h
//  MeishiProject
//
//  Created by Yang on 15/11/26.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface YXJClickImage1Controller : UIViewController


@property (nonatomic, copy) NSString *m_headImageString;

@property (nonatomic, copy) NSString *m_title;

@property (nonatomic, copy) NSString *m_content;

@property (nonatomic, strong) NSString *m_video;

@property (nonatomic, strong) NSString *m_video1;

@property (nonatomic, copy) NSString *m_cooking_time;

@property (nonatomic, copy) NSString *m_hard_level;

@property (nonatomic, copy) NSString *m_taste;

@property (nonatomic, copy) NSString * m_dishesId;


@end
