//
//  HaiMaLogoModel.h
//  中国婚博会
//
//  Created by mac2013 on 15/12/4.
//  Copyright © 2015年 a. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HaiMaLogoModel : NSObject
@property(nonatomic,strong)NSString *store_name;
@property(nonatomic,strong)NSString *logo;
@property(nonatomic,strong)NSString *address;
@property(nonatomic,strong)NSString *tel;
@property(nonatomic,strong)NSNumber *example_num;
@property(nonatomic,strong)NSNumber *branch_num;
@property(nonatomic,strong)NSNumber *product_num;
@property(nonatomic,strong)NSNumber *album_num;
@end
