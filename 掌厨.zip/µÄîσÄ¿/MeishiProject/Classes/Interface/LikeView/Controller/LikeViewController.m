//
//  LikeViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/2.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "LikeViewController.h"
#import "YXJClickImage1Controller.h"
#import "Header.h"
#import "LikeCell.h"
#import "AFNetworking.h"
#import "LIkeModel.h"
#import "LoginViewController.h"
@import MediaPlayer;



@interface LikeViewController ()<UITableViewDataSource,UITableViewDelegate,LikeCellDelegate>
{
    UIActivityIndicatorView *_m_activity;
}

@property (nonatomic, strong) UITableView *m_tabelView;
@property (nonatomic, strong) NSMutableArray *m_likeArray;

@end

@implementation LikeViewController


//加载数据的时候显示菊花(视图将要出现)
- (void)viewWillAppear:(BOOL)animated
{
    _m_activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    _m_activity.center = CGPointMake(screenWidth/2, screenHeight/2);
    _m_activity.color = [UIColor blackColor];
    [self.view addSubview:_m_activity];
    [_m_activity startAnimating];
    
    self.navigationController.navigationBarHidden = NO;
}

//视图已经出现,停止菊花效果
- (void)viewDidAppear:(BOOL)animated
{
    [_m_activity stopAnimating];
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self createTableView];
    [self createLikeReaquest];

    //设置导航栏颜色
    [self.navigationController.navigationBar setBarTintColor:RGBColor(255, 122, 68)];
    //设置导航栏标题的字体大小和颜色
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
}



- (void)createTableView
{
    self.m_tabelView = [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    self.m_tabelView.delegate = self;
    self.m_tabelView.dataSource = self;
    //取消TableViewd的行线 
    self.m_tabelView.separatorStyle = NO;
    [self.view addSubview:self.m_tabelView];
}



- (void)createBtn
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 50)];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button.frame = CGRectMake(40, 0, screenWidth-80, 40);
    button.backgroundColor = [UIColor orangeColor];
    [button setTitle:@"点击下, 让美食更懂你" forState:UIControlStateNormal];
    [button setTintColor:[UIColor whiteColor]];
    button.titleLabel.font = [UIFont systemFontOfSize:20];
    [button addTarget:self action:@selector(presentLoginViewController) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:button];
    self.m_tabelView.tableFooterView = view;
}



- (void)presentLoginViewController
{
    LoginViewController *loginVC = [[LoginViewController alloc]init];
    [self presentViewController:loginVC animated:YES completion:nil];
}


- (NSMutableArray *)m_likeArray
{
    if (_m_likeArray == nil)
    {
        _m_likeArray = [NSMutableArray array];
    }
    return _m_likeArray;
}



- (void)createLikeReaquest
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager GET:LikeUrl parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        NSData *data = [NSData dataWithData:responseObject];
        NSDictionary *dic1 = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSDictionary *dic2 = dic1[@"data"];
        NSArray *arr = dic2[@"data_recomment"];
        for (NSDictionary *dic3 in arr)
        {
            LIkeModel *likeModel = [[LIkeModel alloc]init];
            likeModel.liketitle = dic3[@"title"];
            likeModel.likedescription = dic3[@"description"];
            likeModel.likeimage = dic3[@"image"];
            likeModel.likevideo = dic3[@"video"];
            likeModel.likeDishes_id = dic3[@"dishes_id"];
            likeModel.likeContent = dic3[@"content"];
            likeModel.likevideo1 = dic3[@"video1"];
            likeModel.likeHard_level = dic3[@"hard_level"];
            likeModel.likeCooking_time = dic3[@"cooking_time"];
            likeModel.likeTaste = dic3[@"taste"];
            [self.m_likeArray addObject:likeModel];
        }
        [self.m_tabelView reloadData];
        //跳转到登陆界面
        [self createBtn];
    } failure:^(AFHTTPRequestOperation * _Nonnull operation, NSError * _Nonnull error) {
        
    }];
}





#pragma mark - UITableViewDelegate (push到YXJClickImage1Controller及传模型数据)
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    YXJClickImage1Controller *likeToclickImageCtr = [[YXJClickImage1Controller alloc] init];
    [self.navigationController pushViewController:likeToclickImageCtr animated:YES];
    LIkeModel *model = self.m_likeArray[indexPath.row];
    likeToclickImageCtr.m_headImageString = model.likeimage;
    likeToclickImageCtr.m_title = model.liketitle;
    likeToclickImageCtr.m_content = model.likeContent;
    likeToclickImageCtr.m_dishesId = model.likeDishes_id;
    likeToclickImageCtr.m_cooking_time = model.likeCooking_time;
    likeToclickImageCtr.m_hard_level = model.likeHard_level;
    likeToclickImageCtr.m_taste = model.likeTaste;
    likeToclickImageCtr.m_video = model.likevideo;
    likeToclickImageCtr.m_video1 = model.likevideo1;
}


#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 200;
}


#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.m_likeArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    LikeCell *cell = [LikeCell cellWithTabelView:tableView];
    LIkeModel *model = self.m_likeArray[indexPath.row];
    cell.likeModel2 =model;
    cell.delegate = self;
    return cell;
}


- (void)likeCellDidClickPlay:(LikeCell *)cell
{
    NSURL *url = [NSURL URLWithString:cell.likeModel2.likevideo];
    MPMoviePlayerViewController *moviePlay = [[MPMoviePlayerViewController alloc]initWithContentURL:url];
    [self presentViewController:moviePlay animated:YES completion:nil];
}


@end
