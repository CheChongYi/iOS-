//
//  MeViewController.m
//  MeishiProject
//
//  Created by Yang on 15/11/2.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import "MeViewController.h"
#import "LoginViewController.h"
#import "Header.h"



@interface MeViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSArray *_m_arr1;
}
@property (nonatomic, strong) UITableView *tableView;



@end

@implementation MeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self createTableView];
     //设置导航栏颜色
    [self.navigationController.navigationBar setBarTintColor:RGBColor(255, 122, 68)];
    //设置导航栏标题的字体大小和颜色
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:20],
       NSForegroundColorAttributeName:[UIColor whiteColor]}];
    _m_arr1 =@[@[@"我的收藏",@"我的缓存"],@[@"我的口味偏好",@""]];
}


- (void)createTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStyleGrouped];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];
    UIImageView *image1 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, screenWidth, 200)];
    image1.image = [UIImage imageNamed:@"w10.jpg"];
    //设置tabbelView的头视图
    self.tableView.tableHeaderView = image1;
    
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(150,50, 80, 80)];
    image.image = [UIImage imageNamed:@"userHeadImage"];
    [self.tableView addSubview:image];
    
    UIImageView *image2 = [[UIImageView alloc]initWithFrame:CGRectMake(60,160, 250, 20)];
    image2.image = [UIImage imageNamed:@"0.png"];
    [self.tableView addSubview:image2];
    
}



#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    LoginViewController *loginVC = [[LoginViewController alloc]init];
    switch (indexPath.section)
    {
        case 0:
        case 1:
        [self presentViewController:loginVC animated:YES completion:nil];
        break;
    }
}



#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0)
    {
        return _m_arr1.count;
    }
    return 2;
        
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    NSArray *Arr = _m_arr1[indexPath.section];
    cell.textLabel.text = Arr[indexPath.row];
    //设置cell的箭头
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    //点击cell不会变灰色
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
}


@end
