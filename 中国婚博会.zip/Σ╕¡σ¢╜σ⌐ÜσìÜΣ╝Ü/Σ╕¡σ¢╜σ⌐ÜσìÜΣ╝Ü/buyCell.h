//
//  buyCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/7.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface buyCell : UITableViewCell
-(void)configCellWithbuyModels:(NSArray *)buyModels;
@end
