//
//  gongsiCell.m
//  中国婚博会
//
//  Created by mac2013 on 15/12/1.
//  Copyright © 2015年 a. All rights reserved.
//

#import "gongsiCell.h"
#import "gongsiModel.h"
#import "UIImageView+WebCache.h"
@implementation gongsiCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)configCellWithgongsiModels:(NSArray *)gongsiModels cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    for (int i=0; i<4; i++) {
        gongsiModel *model=gongsiModels[indexPath.row];
        [_iconView sd_setImageWithURL:[NSURL URLWithString:model.logo]];
        _titleLable.text=model.store_name;
        _priceLabel.text=model.average_price;
    }
}
@end
