//
//  CashManager.m
//  中国婚博会
//
//  Created by mac2013 on 15/11/8.
//  Copyright © 2015年 a. All rights reserved.
//

#import "CashManager.h"
#import "AFNetworking.h"
#import "hotelModel.h"
#import "storeModel.h"
NSString *CashManagerRefreshNotify=@"CashManagerRefreshNotify";
static CashManager *manager=nil;
@implementation CashManager
+(instancetype)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager=[[[self class]alloc]init];
        }
    });
    return manager;
}
-(void)loadInternetData{
    [self loadhotelData];
    [self loadstoreData];
}
-(void)loadhotelData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:TalkimgURL parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"banner"];
        for (NSDictionary *dic in array) {
            hotelModel *model=[[hotelModel alloc]init];
            model.imgurl=dic[@"img_url"];
            NSLog(@"%@",model.imgurl);
            if (!_hotelModels) {
                _hotelModels=[NSMutableArray array];
            }
            [self.hotelModels addObject:model];
            NSLog(@"%@",_hotelModels);
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:CashManagerRefreshNotify object:@(0)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:nil message:@"网络错误,请检查网络" delegate:self cancelButtonTitle:nil otherButtonTitles:nil, nil];
        [alertView show];
        [self performSelector:@selector(dimissAlert:) withObject:alertView afterDelay:2.0];
    }];
}

-(void)loadstoreData{
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager GET:storeUrl parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic=responseObject[@"data"];
        NSArray *array=dic[@"list"];
        for (NSDictionary *dic in array) {
            storeModel *model=[[storeModel alloc]init];
           NSDictionary *dics=dic[@"store"];
            model.title=dics[@"store_name"];
            model.price=dic[@"price"];
            model.total=dic[@"total_num"];
            model.apply=dic[@"apply_num"];
            model.imgurl=dic[@"img_id"];
            if (!_Ad2Models) {
                _Ad2Models=[NSMutableArray array];
            }
            [self.Ad2Models addObject:model];
        }
        [[NSNotificationCenter defaultCenter]postNotificationName:CashManagerRefreshNotify object:@(1)];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}
- (void) dimissAlert:(UIAlertView *)alert {
    if(alert)     {
        [alert dismissWithClickedButtonIndex:[alert cancelButtonIndex] animated:YES];
    }
}
@end
