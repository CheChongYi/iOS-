//
//  cashViewController.h
//  中国婚博会
//
//  Created by Admin on 15/11/5.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MXPullDownMenu.h"

@interface cashViewController : UIViewController<MXPullDownMenuDelegate>
@end
