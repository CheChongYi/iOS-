//
//  AboutBuyCell.h
//  中国婚博会
//
//  Created by mac2013 on 15/11/10.
//  Copyright © 2015年 a. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutBuyCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UILabel *banbenLabel;
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
-(void)configCellWithAboutBuyModels:(NSArray *)AboutBuyModels;
@end
