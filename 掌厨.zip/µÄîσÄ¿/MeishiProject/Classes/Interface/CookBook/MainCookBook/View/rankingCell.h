//
//  rankingCell.h
//  MeishiProject
//
//  Created by Yang on 15/11/12.
//  Copyright © 2015年 NSObject. All rights reserved.
//

#import <UIKit/UIKit.h>


@class CookBookModel;
//点击视频播放的协议
@protocol rankingCellDelegate <NSObject>

@optional
- (void)rangkingDidPlayVideo:(CookBookModel *)model;

- (void)rankingCellDidClickImage:(NSInteger)index;


@end


@interface rankingCell : UITableViewCell



@property (nonatomic, strong) NSMutableArray *rangkingArray;

+ (instancetype)cellWithTabelView: (UITableView *)TableView;


@property (nonatomic, weak) id<rankingCellDelegate>delegate;


@end
